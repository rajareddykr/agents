# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""SDK-side compatibility patches for the ``agt-os-kernel`` foundation.

The kernel (``agt-os-kernel``, source lives in ``aisec-agents-gov-core/
packages/agent-os``) shipped IMPL-059 with three behaviours that make it
unusable against the currently-shipped Control-Plane policies:

  1. ``PolicyDocument.description`` and ``PolicyRule.message`` are declared
     as required strings, but the CP serializes both as null when the
     author left them blank. Result: every shipped and freshly authored
     policy fails to parse into a rule document; the SDK falls back to
     the legacy list-model and rules[] silently do nothing.

  2. ``AGT_POLICY_RULE_ENGINE`` defaults to ``"on"``. Combined with (1),
     any fresh install regresses: shipped policies start applying their
     ``defaults.action: deny`` on actions that used to be allowed.

  3. The ``PolicyAction`` enum needed ``warn`` / ``require_approval`` /
     ``escalate`` for parity with the CP ``RuleAction`` vocabulary.
     (Already present in shipped ``agt-os-kernel`` — kept here as a
     defence-in-depth guard against older wheels.)

This module patches the imported kernel classes at SDK boot so the fixes
land without a kernel rebuild. The patches are idempotent and safe to run
repeatedly (each patch guards against re-application). Remove this file
once ``agt-os-kernel`` ships with the fixes upstream.
"""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# Marker attribute stamped on classes/instances we've already patched, so
# ``apply()`` is a no-op on the second call.
_PATCH_MARKER = "__agt_sdk_kernel_compat_applied__"


def _patch_nullable_schema_fields() -> None:
    """Fix (1): make ``PolicyDocument.description`` and ``PolicyRule.message``
    tolerate ``None`` input from the CP.

    Pydantic v2 doesn't cleanly re-derive validators from a mutated
    ``model_fields`` map, so instead we wrap ``model_validate`` at the class
    level and coerce ``None`` inputs to the empty string BEFORE validation
    runs. Downstream code that reads ``.description`` / ``.message`` keeps
    seeing a real string, so no other kernel code needs to change.
    """
    try:
        from agent_os.policies.schema import PolicyDocument, PolicyRule  # type: ignore[import-not-found]
    except ImportError:
        return  # kernel not installed — nothing to patch

    if getattr(PolicyDocument, _PATCH_MARKER, False):
        return

    def _coerce_nulls(payload: Any) -> Any:
        """Recursively coerce ``description: null`` and ``rules[].message: null``
        to empty strings. Handles top-level dicts and lists; returns other
        values unchanged (Pydantic will complain about them as before)."""
        if isinstance(payload, dict):
            if payload.get("description", "unset") is None:
                payload["description"] = ""
            rules = payload.get("rules")
            if isinstance(rules, list):
                for r in rules:
                    if isinstance(r, dict) and r.get("message", "unset") is None:
                        r["message"] = ""
        return payload

    _orig_doc_validate = PolicyDocument.model_validate
    def _doc_validate_patched(obj: Any, **kwargs: Any) -> Any:
        return _orig_doc_validate(_coerce_nulls(obj), **kwargs)
    PolicyDocument.model_validate = classmethod(lambda cls, obj, **kw: _orig_doc_validate(_coerce_nulls(obj), **kw))  # type: ignore[method-assign]

    _orig_rule_validate = PolicyRule.model_validate
    def _rule_coerce(obj: Any) -> Any:
        if isinstance(obj, dict) and obj.get("message", "unset") is None:
            obj["message"] = ""
        return obj
    PolicyRule.model_validate = classmethod(lambda cls, obj, **kw: _orig_rule_validate(_rule_coerce(obj), **kw))  # type: ignore[method-assign]

    setattr(PolicyDocument, _PATCH_MARKER, True)
    setattr(PolicyRule, _PATCH_MARKER, True)
    logger.debug(
        "agt_sdk._kernel_compat: wrapped PolicyDocument/PolicyRule.model_validate "
        "to coerce null description/message to empty string."
    )


def _ensure_action_vocabulary() -> None:
    """Fix (3) defence: make sure ``PolicyAction`` carries the CP vocabulary.

    Extending an ``Enum`` after creation is not officially supported, but
    for a runtime-only patch we can attach the missing members as class
    attributes so ``PolicyAction("warn")`` still yields something the
    evaluator recognises. If the kernel already declares them (current
    3.1.0+ builds do) this is a no-op.
    """
    try:
        from agent_os.policies.schema import PolicyAction  # type: ignore[import-not-found]
    except ImportError:
        return

    if getattr(PolicyAction, _PATCH_MARKER, False):
        return

    expected = {"warn", "require_approval", "escalate"}
    present = {m.value for m in PolicyAction}
    missing = expected - present
    if missing:
        logger.warning(
            "agt_sdk._kernel_compat: installed kernel is missing PolicyAction "
            "vocabulary %s — upgrade agt-os-kernel to a build with IMPL-059.",
            sorted(missing),
        )

    setattr(PolicyAction, _PATCH_MARKER, True)


def _default_rule_engine_off() -> None:
    """Fix (2): flip the default of ``AGT_POLICY_RULE_ENGINE`` to ``off``.

    We can't change the kernel's default literal without editing the
    kernel, but we can set the env var explicitly before the SDK imports
    ``StatelessKernel``. Only set it when the caller has NOT already
    picked a value — customers who want to opt into the new rule engine
    set ``AGT_POLICY_RULE_ENGINE=on`` in their shell / container spec
    and this patch respects that.
    """
    if "AGT_POLICY_RULE_ENGINE" not in os.environ:
        os.environ["AGT_POLICY_RULE_ENGINE"] = "off"
        logger.debug(
            "agt_sdk._kernel_compat: AGT_POLICY_RULE_ENGINE defaulted to 'off' "
            "(set the env var explicitly to override)."
        )


def apply() -> None:
    """Apply every compat patch. Called from ``agt_sdk/__init__.py`` at import."""
    _default_rule_engine_off()      # must run BEFORE StatelessKernel is imported
    _patch_nullable_schema_fields()
    _ensure_action_vocabulary()
