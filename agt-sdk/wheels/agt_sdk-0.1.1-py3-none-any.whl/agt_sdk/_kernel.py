# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""AutoKernel — process-wide singleton wrapping ``StatelessKernel``.

Customers never instantiate this directly. The framework adapters
(`agt_sdk.langgraph.GovernedToolNode`, `agt_sdk.langchain.GovernanceMiddleware`,
``@governed`` decorator) call ``AutoKernel.instance()``.

What ``instance()`` does on first call (delegated to ``Lifecycle.start``
since IMPL-035 cleanup 1):

  1. Reads env via :class:`SdkConfig.from_env`.
  2. Builds a ``StatelessKernel``.
  3. Calls ``register_with_cp`` (background thread, non-blocking).
  4. Calls ``set_policy_server(policy_server_url)`` — starts background refresh.
  5. Sets up SDK-internal decision push.
  6. Calls ``kernel.start()`` — kicks off the policy refresh and audit drain.
  7. Starts the heartbeat thread.
  8. IMPL-032: opt-in mesh wiring.

Subsequent calls return the cached singleton.

If ``SdkConfig.enabled`` is False (no ``AGT_CP_URL`` or governance disabled),
``instance()`` returns a no-op kernel that allows everything and records
nothing.

Cleanup history:
- IMPL-035 cleanup 1 (2026-05-14): split into _kernel.py (this file —
  public surface + hot-path delegation) + _lifecycle.py (cold-path
  orchestration) + _pipeline.py (hot-path 4-stage tool-call evaluation).
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Any

# Re-imported at module scope so tests can monkeypatch ``agt_sdk._kernel._bootstrap_exchange``;
# _lifecycle.py looks up the symbol through this module at call time.
from agt_sdk._bootstrap import (
    BootstrapAlreadyConsumed,  # noqa: F401  re-export for test convenience
    BootstrapError,            # noqa: F401  re-export for test convenience
    BootstrapResult,
    IdentityAttachError,       # noqa: F401  re-export for test convenience
    KeyRecoveryFailed,         # noqa: F401  re-export for test convenience
    attach_identity as _attach_identity,  # noqa: F401  IMPL-067 — monkeypatch point, same convention as _bootstrap_exchange
    exchange as _bootstrap_exchange,  # noqa: F401  re-export so tests can monkeypatch agt_sdk._kernel._bootstrap_exchange
)
from agt_sdk._config import SdkConfig
from agt_sdk._heartbeat import HeartbeatThread
from agt_sdk._ingest import DecisionIngest
from agt_sdk._lifecycle import Lifecycle
from agt_sdk._pipeline import CheckPipeline

logger = logging.getLogger("agt_sdk.kernel")


@dataclass
class _MeshWiring:
    """IMPL-032 / IMPL-032.5: opt-in mesh objects exposed by AutoKernel.

    Populated by ``Lifecycle._maybe_wire_mesh`` when the ``[mesh]``
    install extra is present and a bootstrap exchange has succeeded.
    Stays ``None`` in governance-only mode.

    IMPL-032 fields (``identity`` + ``handshake_publisher``) are always
    populated when this dataclass exists. IMPL-032.5 added the three
    behavioural engines and their CP publishers — these stay ``None``
    if the engines fail to construct, in which case handshake-only
    mode is preserved.
    """
    identity: Any                 # agentmesh.identity.AgentIdentity
    handshake_publisher: Any      # agentmesh.trust.publisher.CPHandshakePublisher
    # IMPL-040 Phase 5 — wire-1.0 §11 registry client (CP-backed peer
    # identity lookup). When non-None, framework adapters can pass it
    # into ``TrustBridge(registry=...)`` so A2A handshakes verify
    # against the CP. ``None`` if ``agt-registry-client`` isn't
    # installed — A2A peers stay unverified (handshake-only mode).
    mesh_registry: Any = None     # agt_registry_client.HTTPRegistryStore
    # IMPL-032.5 — per-agent behavioural engines + their CP publishers.
    reward_engine: Any = None     # agentmesh.reward.engine.RewardEngine
    risk_scorer: Any = None       # agentmesh.identity.risk.RiskScorer
    network_engine: Any = None    # agentmesh.reward.trust_decay.NetworkTrustEngine
    trust_publisher: Any = None   # agentmesh.reward.publisher.CPTrustPublisher
    risk_publisher: Any = None    # agentmesh.identity.risk_publisher.CPRiskPublisher
    drift_publisher: Any = None   # agentmesh.reward.drift_publisher.CPDriftPublisher


@dataclass
class CheckResult:
    """Result of an in-process governance check.

    Returned by :meth:`AutoKernel.check`. Contains everything an adapter
    needs to either let the call through or build a block message.
    """
    allowed: bool
    reason: str | None = None
    matched_rule: str | None = None
    policy_name: str | None = None
    latency_ms: float = 0.0
    source: str = ""        # "injection" | "baseline" | "policy" | "noop"


class AutoKernel:
    """Singleton wrapper around ``agent_os.stateless.StatelessKernel``.

    Use :meth:`instance` to get the process-wide instance. Adapters and
    decorators all share this single instance.
    """

    _instance: "AutoKernel | None" = None
    _lock = threading.Lock()

    def __init__(self, config: SdkConfig) -> None:
        self._cfg = config
        self._kernel: Any = None        # late-bound to avoid hard import when disabled
        self._heartbeat: HeartbeatThread | None = None
        self._ingest: DecisionIngest | None = None
        self._bootstrap: BootstrapResult | None = None      # set when AGT_BOOTSTRAP_TOKEN is consumed
        self._mesh: _MeshWiring | None = None               # IMPL-032: set when [mesh] extra is installed
        self._started = False
        self._extra_policies: dict[str, dict[str, Any]] = {}
        # IMPL-035 cleanup 1: split orchestration + pipeline into friend classes.
        self._lifecycle = Lifecycle(self)
        self._pipeline = CheckPipeline(self)
        logging.getLogger("agt_sdk").setLevel(self._cfg.log_level)

    # ── Public ───────────────────────────────────────────────────────────────

    @classmethod
    def instance(cls) -> "AutoKernel":
        """Return the process-wide singleton, building and starting it if needed."""
        if cls._instance is not None:
            return cls._instance
        with cls._lock:
            if cls._instance is None:
                cfg = SdkConfig.from_env()
                inst = cls(cfg)
                inst._lifecycle.start()
                cls._instance = inst
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Tear down the singleton. Test-only — do not call in production."""
        with cls._lock:
            if cls._instance is not None:
                try:
                    if cls._instance._kernel is not None:
                        cls._instance._kernel.stop()
                except Exception:
                    pass
                if cls._instance._heartbeat is not None:
                    cls._instance._heartbeat.stop()
                if cls._instance._ingest is not None:
                    cls._instance._ingest.stop()
                # IMPL-032.5: stop the drift sampler-loop before nulling _mesh.
                # ``_stopped = True`` is the synchronous escape hatch when no
                # event loop is running (spec Resolution Q4); the task cancel
                # is best-effort and silent.
                mesh = cls._instance._mesh
                if mesh is not None:
                    pub = getattr(mesh, "drift_publisher", None)
                    if pub is not None:
                        try:
                            pub._stopped = True
                            task = getattr(pub, "_sampler_task", None)
                            if task is not None and not task.done():
                                task.cancel()
                        except Exception:
                            pass
                cls._instance._mesh = None      # IMPL-032: clear mesh wiring
            cls._instance = None

    @property
    def config(self) -> SdkConfig:
        return self._cfg

    @property
    def enabled(self) -> bool:
        return self._cfg.enabled

    @property
    def cp_handshake_publisher(self) -> Any:
        """IMPL-032: the mesh ``CPHandshakePublisher`` when mesh wiring is active.

        Framework adapters that build an ``agentmesh.integrations.a2a``
        negotiator pass this in as the ``cp_handshake_publisher`` kwarg so
        verified handshakes flow to the CP automatically.

        Returns ``None`` in governance-only mode (mesh extra not installed
        or bootstrap exchange did not run).
        """
        return self._mesh.handshake_publisher if self._mesh else None

    @property
    def mesh_engines(self) -> "_MeshWiring | None":
        """IMPL-032.5: the populated ``_MeshWiring`` when mesh wiring is active.

        Read-only — customers wanting richer signal mappings construct
        their own ``RewardEngine`` / ``RiskScorer`` / ``NetworkTrustEngine``
        in app code and feed them independently. Per spec Resolution Q1,
        swappable engines are deferred to a future ML-reward spec.

        Returns ``None`` in governance-only mode.
        """
        return self._mesh

    @property
    def mesh_registry(self) -> Any:
        """IMPL-040 Phase 5: the wire-1.0 §11 registry client.

        Framework adapters that build an ``agentmesh.trust.TrustBridge``
        (or directly construct ``TrustHandshake``) pass this in as
        ``registry=...`` so peer-DID lookups go through the CP-backed
        registry with the §6 resilience contract (cache, breaker,
        stale-while-revalidate, negative cache).

        Returns ``None`` in governance-only mode, or if
        ``agt-registry-client`` is not installed even when the rest of
        the mesh wiring activated (rare — both come from the same
        ``[mesh]`` extra).
        """
        return self._mesh.mesh_registry if self._mesh else None

    async def a2a_gate(self, peer_name: str, *, min_trust: int | None = None) -> Any:
        """IMPL-065 — may this agent delegate to ``peer_name``? Returns a verdict.

        The escape hatch behind ``@peer_verified``, for peers not known at import
        time: fan-out to N children, capability-based selection, a name read from
        config. Both surfaces run the same gate, so they cannot drift.

        Returns an ``A2AVerdict``. Prefer the decorator where the peer is static —
        it raises, so the check cannot be skipped by forgetting to read this.
        """
        from agt_sdk._a2a import run_gate
        return await run_gate(self, peer_name, min_trust=min_trust)

    def add_policies(self, policies: dict[str, dict[str, Any]]) -> None:
        """Merge extra policies on top of whatever CP returned. Adapter-driven."""
        self._extra_policies.update(policies)
        if self._kernel is not None:
            self._kernel.policies.update(policies)

    def diagnostics(self) -> dict[str, Any]:
        """Return a snapshot of the kernel's runtime state for troubleshooting."""
        d: dict[str, Any] = {
            "enabled": self._cfg.enabled,
            "agent_id": self._cfg.agent_id,
            "agent_name": self._cfg.agent_name,
            "cp_url": self._cfg.cp_url,
            "policy_url": self._cfg.policy_server_url,
            "audit_url": self._cfg.audit_url,
            "fail_mode": self._cfg.fail_mode,
            "heartbeat": "off" if self._cfg.heartbeat_seconds == 0 else f"on ({self._cfg.heartbeat_seconds}s)",
            "injection_scanner": "on" if self._cfg.injection_scanner else "off",
            "local_safety_baseline": "on" if self._cfg.local_safety_baseline else "off",
            "started": self._started,
            "bootstrap": "consumed" if self._bootstrap is not None
                else ("pending" if self._cfg.bootstrap_token else "not used"),
        }
        if self._bootstrap is not None:
            d["bootstrap_did"] = self._bootstrap.did
            d["bootstrap_cp_root"] = self._bootstrap.cp_root_did
            d["bootstrap_agent_row"] = self._bootstrap.agent_id
            if self._bootstrap.credential_expires_at:
                d["bootstrap_credential_expires_at"] = self._bootstrap.credential_expires_at.isoformat()
        if self._kernel is not None:
            try:
                d["policies_loaded"] = sorted((self._kernel.policies or {}).keys())
            except Exception:
                d["policies_loaded"] = "unknown"
        return d

    # ── Hot-path check (called by adapters per tool call) ───────────────────

    async def check(
        self,
        tool_name: str,
        tool_args: dict[str, Any] | None,
        policy_names: list[str] | None = None,
    ) -> CheckResult:
        """Evaluate one tool call. The single entry point for all adapters.

        Order of checks (any one can short-circuit):

          1. Master kill switch off  → allow (no recording).
          2. Prompt-injection scanner (if enabled).
          3. Local safety baseline (if enabled).
          4. Policy evaluation via the kernel.

        Returns a :class:`CheckResult`. Adapters convert this to whatever
        their framework expects (``ToolMessage`` for LangChain,
        ``AGTBlocked`` exception for the raw decorator, etc.).

        Body lives in ``CheckPipeline.run`` (IMPL-035 cleanup 1).
        """
        return await self._pipeline.run(tool_name, tool_args, policy_names)

    async def _maybe_refresh_policy(self) -> None:
        """Re-fetch the CP policy bundle when the local cache is older than the
        configured refresh interval.

        The upstream policy refresh runs in an async background loop started by
        ``kernel.start()``. Sync / per-call agents (no persistent event loop)
        never keep that loop alive, so a control-plane change pushed *after*
        boot — e.g. the kill-switch block-all bundle served once an agent is
        suspended — would never reach them and the kill would not enforce.

        Calling this on the check hot path guarantees delivery within one TTL
        window regardless of the agent's loop model. It is throttled to at most
        one fetch per TTL and swallows errors (falls back to cached policies).
        """
        kernel = self._kernel
        if kernel is None:
            return
        provider = getattr(kernel, "_remote_policy", None)
        if provider is None:
            return
        fetch = getattr(provider, "_fetch", None)
        if fetch is None:
            return
        try:
            import time as _time
            ttl = max(1, int(self._cfg.policy_refresh_seconds or 60))
            last = float(getattr(provider, "_fetched_at", 0.0) or 0.0)
            if (_time.monotonic() - last) < ttl:
                return
            await fetch()   # re-POST /policies/bundle/resolve + apply on_refresh
        except Exception as exc:  # never break a governed call on a refresh hiccup
            logger.debug("agt_sdk: policy hot-path refresh skipped: %s", exc)

    def _kill_switch_engaged(self) -> bool:
        """True when the applied CP bundle is the block-all kill-switch policy.

        Read from the policy provider's cache each check (no network). Lets the
        pipeline HARD-STOP a suspended agent regardless of whether the
        underlying policy engine enforces the catch-all deny rule.
        """
        kernel = self._kernel
        if kernel is None:
            return False
        provider = getattr(kernel, "_remote_policy", None)
        if provider is None:
            return False
        for p in (getattr(provider, "_cache", None) or []):
            if isinstance(p, dict):
                if p.get("id") == "kill-switch-block-all":
                    return True
                if str(p.get("name") or "").lower().startswith("kill switch"):
                    return True
        return False

    def flush(self, timeout_seconds: float = 5.0) -> int:
        """Flush queued governance decisions to the CP. Returns the count sent.

        Short-running agents (scripted harnesses) should call this before exit
        so decisions aren't lost when the process ends before the async ingest
        queue drains.
        """
        try:
            from agt_sdk import _tracing
            _tracing.flush()
        except Exception:
            pass
        if self._ingest is not None:
            try:
                return int(self._ingest.flush(timeout_seconds=timeout_seconds) or 0)
            except Exception:
                return 0
        return 0

    def _record(self, tool_name: str, args_repr: str, result: "CheckResult") -> None:
        """Push a decision to the CP via the SDK-internal ingest queue.

        IMPL-032.5: also fans the decision out to the per-agent mesh
        engines (RewardEngine / RiskScorer / NetworkTrustEngine) when
        mesh wiring is active. Engine recalculations drive the IMPL-028
        / IMPL-034 / IMPL-037 publishers attached as score-change
        observers, so the dashboard's trust / risk / drift panels
        populate from real tool-call traffic without an external
        exerciser.
        """
        if self._ingest is not None:
            outcome = "allow" if result.allowed else "block"
            try:
                self._ingest.record(
                    action=tool_name,
                    outcome=outcome,
                    reason=result.reason or "",
                    matched_rule=result.matched_rule,
                    policy_name=result.policy_name,
                    latency_ms=result.latency_ms,
                    context_snapshot={"tool": tool_name, "args_preview": args_repr[:200]},
                )
            except Exception as exc:
                logger.debug("decision record failed: %s", exc)

        # IMPL-032.5 — feed per-agent mesh engines.
        self._feed_mesh_engines(tool_name, result)

        # Opik observability (opt-in via AGT_TRACING) — emit a span through our
        # custom pointguard SDK. Never affects governance (fully guarded).
        try:
            from agt_sdk import _tracing
            _tracing.record_decision(
                self._cfg.agent_id, self._cfg.agent_name, tool_name, args_repr, result
            )
        except Exception:
            pass

    def _feed_mesh_engines(self, tool_name: str, result: "CheckResult") -> None:
        """IMPL-032.5: forward a tool-call decision to the per-agent mesh engines.

        Signal mapping defaults (spec § Signal mapping defaults (v1)):

        - Drift: every tool call → ``network_engine.record_action``.
        - Trust (policy_compliance): every tool call →
          ``reward_engine.record_policy_compliance``.
        - Trust (resource_efficiency): every tool call → latency-based
          ``record_signal`` with a 1000 ms cutoff (spec Resolution Q2).
        - Risk: only on deny / injection paths; allow is a no-op.

        All branches are fail-open (individual try/except). Customers
        wanting richer signal mappings access the engines via
        ``kernel.mesh_engines`` and feed them directly — these are
        defaults, not the only signal source.
        """
        mesh = self._mesh
        if mesh is None or mesh.network_engine is None:
            return
        try:
            did = str(mesh.identity.did)
        except Exception:
            return

        # Drift — every tool call is an action observation.
        try:
            mesh.network_engine.record_action(did, tool_name)
        except Exception:
            logger.debug("mesh network_engine.record_action failed", exc_info=True)

        # Trust — policy_compliance dimension (allow=1.0, deny=0.0 internally).
        try:
            mesh.reward_engine.record_policy_compliance(
                agent_did=did,
                compliant=result.allowed,
                policy_name=result.policy_name,
            )
        except Exception:
            logger.debug("mesh reward_engine.record_policy_compliance failed", exc_info=True)

        # Trust — resource_efficiency dimension from latency (Q2: 1000 ms cutoff).
        try:
            from agentmesh.reward.scoring import DimensionType
            latency = float(result.latency_ms or 0.0)
            efficiency = max(0.0, 1.0 - min(1.0, latency / 1000.0))
            mesh.reward_engine.record_signal(
                agent_did=did,
                dimension=DimensionType.RESOURCE_EFFICIENCY,
                value=efficiency,
                source="agt-sdk-latency",
            )
        except Exception:
            logger.debug("mesh reward_engine.record_signal (latency) failed", exc_info=True)

        # Risk — only on deny / injection paths; allow is intentionally a no-op
        # (absence of denies keeps risk low; we don't want to flood the scorer
        # with allow signals).
        if not result.allowed:
            try:
                from agentmesh.identity.risk import RiskSignal
                if result.source == "injection":
                    signal_type = "security.injection"
                    severity = "high"
                    value = 0.8
                else:
                    signal_type = f"policy.{result.policy_name or 'unknown'}.violation"
                    severity = "medium"
                    value = 0.5
                mesh.risk_scorer.add_signal(did, RiskSignal(
                    signal_type=signal_type,
                    severity=severity,
                    value=value,
                    source="agt-sdk-policy-deny",
                ))
            except Exception:
                logger.debug("mesh risk_scorer.add_signal failed", exc_info=True)

        # Force a recalc on both engines after every tool call.
        #
        # Why this is needed in the SDK (Pattern A) but not in a server
        # context: ``RewardEngine.record_signal`` only calls
        # ``_recalculate_score`` when value < 0.3 (critical signals), and
        # ``RiskScorer.add_signal`` only when severity == "critical".
        # Both engines were designed assuming an external ticker (the
        # mesh trust-engine service) bulk-recalculates every N seconds.
        # In Pattern A there is no such ticker — without an explicit
        # recalc per signal, ``on_score_change`` never fires, the
        # CPTrustPublisher / CPRiskPublisher callbacks wired by the
        # lifecycle never run, and the dashboard's trust + risk panels
        # stay null no matter how much traffic flows.
        #
        # Calling the public ``recalculate`` (RiskScorer) and the
        # internal ``_recalculate_score`` (RewardEngine — no public
        # equivalent) here drives the callback chain on every tool call.
        try:
            mesh.reward_engine._recalculate_score(did)
        except Exception:
            logger.debug("mesh reward_engine._recalculate_score failed", exc_info=True)
        if not result.allowed:
            try:
                mesh.risk_scorer.recalculate(did)
            except Exception:
                logger.debug("mesh risk_scorer.recalculate failed", exc_info=True)

    # ── Backward-compatible delegating shims (IMPL-035) ──────────────────────
    # Old code (and tests) called these as methods on AutoKernel; after the
    # split they live on Lifecycle. Keep one-line delegates so existing test
    # files (notably test_mesh_auto_wire.py) keep working without edits.

    def _lazy_start(self) -> None:
        self._lifecycle.start()

    def _maybe_wire_mesh(self) -> None:
        self._lifecycle._maybe_wire_mesh()

    def _maybe_run_bootstrap(self) -> bool:
        return self._lifecycle._maybe_run_bootstrap()

    def _kernel_start_safely(self) -> None:
        self._lifecycle._kernel_start_safely()
