# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Cold-path lifecycle orchestration for AutoKernel.

Extracted from ``_kernel.py`` (IMPL-035 cleanup 1). Owns the one-shot
startup sequence: bootstrap → kernel.start → audit sink → heartbeat →
mesh. Runs once per process at ``AutoKernel.instance()`` time.

Like ``CheckPipeline``, ``Lifecycle`` is a friend class that holds a
back-reference to its AutoKernel and mutates kernel state through it.
The split exists to keep the hot path (``check()``) readable; the cold
path's failure-mode plumbing stays here.
"""

from __future__ import annotations

import asyncio
import atexit
import dataclasses
import logging
import os
import sys
from typing import TYPE_CHECKING, Any

from agt_sdk._heartbeat import HeartbeatThread
from agt_sdk._ingest import DecisionIngest
from agt_sdk.exceptions import AGTConfigurationError
from agt_sdk._gateway_headers import gateway_headers

if TYPE_CHECKING:
    from agt_sdk._kernel import AutoKernel

logger = logging.getLogger("agt_sdk.lifecycle")


class Lifecycle:
    """One-shot startup orchestration for an ``AutoKernel``.

    Constructed once in ``AutoKernel.__init__``; ``start()`` is called
    exactly once from ``AutoKernel.instance()`` after the singleton
    lock is taken.
    """

    def __init__(self, kernel: "AutoKernel") -> None:
        self._k = kernel

    # ── Entry point ──────────────────────────────────────────────────────────

    def start(self) -> None:
        """Build the kernel and start background tasks. Called once."""
        k = self._k
        if k._started:
            return
        k._started = True

        if not k._cfg.enabled:
            logger.info(
                "agt_sdk: AGT_CP_URL not set or governance disabled — running in pass-through mode"
            )
            return

        # ── Enrolment (optional) ─────────────────────────────────────────────
        # On success, the resolved DID becomes the agent identity for the rest of
        # this process. Two flows, checked in this order because the deprecated
        # one wins while it is explicitly configured — silently ignoring a token
        # the operator set would be worse than telling them it is on its way out.
        if not self._maybe_run_bootstrap():
            # fail_mode=closed + bootstrap error → abort start. The kernel
            # stays None so check() short-circuits to fail-closed on every call.
            logger.error("agt_sdk: aborting startup due to bootstrap failure (fail_mode=closed)")
            return
        if not self._maybe_attach_identity():
            logger.error(
                "agt_sdk: aborting startup — the agent could not attach its "
                "identity. Starting anyway would run an ungoverned or "
                "wrongly-identified agent."
            )
            return

        try:
            from agent_os.stateless import StatelessKernel
        except ImportError as exc:
            logger.error(
                "agt_sdk: agent_os not installed (%s) — governance will fail %s. "
                "Install with: pip install agt-os-kernel",
                exc, k._cfg.fail_mode,
            )
            return

        # Build kernel with empty policy set; will be populated by RemotePolicyProvider
        # via set_policy_server, plus any extra policies merged by add_policies().
        k._kernel = StatelessKernel(policies=k._extra_policies)

        # ── Policies served only from CP (operator-managed) ────────────────
        # StatelessKernel.__init__ merges its bundled DEFAULT_POLICIES
        # ('read_only', 'no_pii', 'strict') into self.policies so they
        # always fire — even when no CP-side policy bundle exists. That
        # made the SDK "fail-safe" but split the source of truth: the
        # same policy name could exist with different rules in two
        # places (the SDK code AND the Policy Studio), and operators
        # editing in CP were silently shadowed by the bundled copies.
        #
        # We drop the bundled defaults right after construction so
        # `kernel.policies` carries only:
        #   - any extras the developer added via `kernel.add_policies(...)`
        #   - whatever CPRemotePolicyProvider warmup_sync() pulls below
        #
        # The SDK's Layer 1 baseline (`agt_sdk._baseline`) is independent
        # of `kernel.policies` and continues to block obviously dangerous
        # tool names (`delete_file`, `shell_exec`, …) regardless of CP
        # state — that's the always-on safety floor.
        #
        # If you actually want the bundled defaults back (e.g. running
        # the SDK against a CP that hasn't been seeded yet), seed them
        # via `scripts/seed-policies.sh`, which mirrors them into CP
        # under the same names. CP becomes the single source of truth.
        k._kernel.policies = dict(k._extra_policies or {})

        # Register with CP (best-effort, non-blocking).
        # The framework label is auto-detected from imported adapter
        # modules — see _detect_framework() — so the agent dev never has
        # to set an env var to get "langchain" / "crewai" in the dashboard.
        framework = _detect_framework()
        try:
            k._kernel.register_with_cp(
                url=k._cfg.cp_url,
                token=k._cfg.cp_token,
                agent_id=k._cfg.agent_id,
                agent_name=k._cfg.agent_name,
                description=k._cfg.agent_description,
                framework=framework,
                extra_headers=gateway_headers(k._cfg),   # PGAIAuthGateway
            )
        except Exception as exc:
            logger.warning("agt_sdk: register_with_cp failed: %s — falling back to direct HTTP registration", exc)
            self._register_direct(framework=framework)

        # Wire policy bundle fetch.
        #
        # We don't call kernel.set_policy_server() because that wires the
        # upstream agent_os.RemotePolicyProvider, which expects the bare
        # {policies, fetched_at} shape returned by agent-mesh policy-server.
        # The AGT control-plane wraps the same bundle in its ApiResponse
        # envelope ({success, data: {policies, ...}, ...}), so the upstream
        # provider's parser caches an empty list and the SDK silently runs
        # on bundled DEFAULT_POLICIES only.
        #
        # CPRemotePolicyProvider (in agt_sdk/_policy_provider.py) is a
        # subclass that overrides _fetch to peel the envelope. Setting the
        # private attrs directly mirrors what set_policy_server would do —
        # kernel.start() picks _remote_policy up from there. cp_token is
        # passed explicitly: by this point bootstrap (if it ran) has
        # swapped it to the scoped api_token from POST /agents/bootstrap
        # (IMPL-024.5), so this carries the correct short-lived credential.
        # Whether this agent MUST address the org-scoped policy endpoint.
        # True whenever we are in the multi-tenant deployment mode — i.e. the
        # agent bootstrapped (bootstrap mints an org-scoped api_token) or a
        # SaaS gateway key is present. In that mode a missing AGT_ORG_CODE is a
        # hard misconfiguration: the provider must fail closed rather than
        # silently fetch from the legacy unscoped /api/v1/policies/bundle.
        # Standalone deployments (no bootstrap, no gateway) leave this False,
        # so the legacy unscoped path stays available for them.
        require_org_scope = (k._bootstrap is not None) or bool(k._cfg.gateway_api_key)
        try:
            from agt_sdk._policy_provider import CPRemotePolicyProvider
            # IMPL-047 P0-1 — scoped bundle resolution context. agent_id +
            # agent_type come from env; sponsor_id is in the sponsorship JWT
            # payload returned by the bootstrap exchange. The provider POSTs
            # these to /policies/bundle/resolve so the CP returns just the
            # bundle that applies to this agent's profile.
            sponsor_id = ""
            if k._bootstrap is not None:
                try:
                    payload = k._bootstrap.decoded_credential()
                    sponsor_id = str(payload.get("sponsor_id") or "")
                except Exception:
                    sponsor_id = ""
            provider = CPRemotePolicyProvider(
                k._cfg.policy_server_url,
                ttl=k._cfg.policy_refresh_seconds,
                token=k._cfg.cp_token,
                on_refresh=k._kernel._apply_policy_bundle,
                org_code=k._cfg.org_code,
                agent_id=k._cfg.agent_id,
                agent_type=k._cfg.agent_type,
                sponsor_id=sponsor_id,
                gateway_api_key=k._cfg.gateway_api_key,         # PGAIAuthGateway
                require_org_scope=require_org_scope,
            )
            k._kernel._remote_policy = provider
            k._kernel._remote_policy_names = set()
            # Block on the first fetch so any agent — sync or async caller —
            # has CP-side policies in place before its first kernel.check().
            # See CPRemotePolicyProvider.warmup_sync for the async-context
            # race this addresses.
            provider.warmup_sync()
        except AGTConfigurationError:
            # Fail closed: an org-scoped agent without a valid org slug must
            # NOT run governance against the unscoped endpoint. Re-raise so
            # startup surfaces the misconfiguration loudly instead of quietly
            # degrading to bundled defaults.
            logger.error(
                "agt_sdk: refusing to start — org-scoped agent is missing a "
                "valid AGT_ORG_CODE; cannot fetch policy from the unscoped "
                "/api/v1/policies/bundle endpoint."
            )
            raise
        except Exception as exc:
            logger.warning("agt_sdk: policy provider wiring failed: %s", exc)

        # SDK-internal decision push.
        # We do not call kernel.set_audit_sink because the kernel's HTTPDecisionSink
        # uses ``Authorization: Bearer`` and posts to ``/api/v1/audit/log``. The CP's
        # ``agt_``-prefix tokens go in ``X-AGT-Token``, and the canonical decision
        # ingest endpoint is ``/api/v1/governance/decisions/ingest``. Until the kernel
        # is updated (IMPL-035 cleanup 3), the SDK pushes decisions directly with the
        # right auth + path.
        try:
            k._ingest = DecisionIngest(
                cp_url=k._cfg.cp_url,
                cp_token=k._cfg.cp_token,
                agent_id=k._cfg.agent_id,
                agent_name=k._cfg.agent_name,
                org_code=k._cfg.org_code,
                gateway_api_key=k._cfg.gateway_api_key,        # PGAIAuthGateway
            )
            k._ingest.start()

            # Atexit flush — short-running scripts otherwise lose queued decisions.
            def _flush_on_exit() -> None:
                if k._ingest is not None:
                    n = k._ingest.flush(timeout_seconds=5.0)
                    if n > 0:
                        logger.debug("flushed %d decisions on exit", n)
            atexit.register(_flush_on_exit)
        except Exception as exc:
            logger.warning("agt_sdk: decision ingest failed to start: %s", exc)

        # Kick off background tasks
        self._kernel_start_safely()

        # Heartbeat
        if k._cfg.heartbeat_seconds > 0:
            k._heartbeat = HeartbeatThread(
                cp_url=k._cfg.cp_url,
                cp_token=k._cfg.cp_token,
                agent_id=k._cfg.agent_id,
                interval_seconds=k._cfg.heartbeat_seconds,
                org_code=k._cfg.org_code,
                gateway_api_key=k._cfg.gateway_api_key,        # PGAIAuthGateway
            )
            k._heartbeat.start()

        # IMPL-032: opt-in mesh wiring (no-op if [mesh] extra not installed
        # or no bootstrap result). Sits after heartbeat so a wiring failure
        # never blocks core governance startup.
        self._maybe_wire_mesh()

        logger.info(
            "agt_sdk ready: agent_id=%s cp=%s policy=%s audit=%s fail_mode=%s mesh=%s",
            k._cfg.agent_id,
            k._cfg.cp_url,
            k._cfg.policy_server_url,
            k._cfg.audit_url,
            k._cfg.fail_mode,
            "on" if k._mesh else "off",
        )

    # ── Cold-path helpers (each was a method on AutoKernel pre-IMPL-035) ─────

    def _register_direct(self, framework: str) -> None:
        """Direct HTTP POST to /api/v1/orgs/{org_code}/agents when StatelessKernel lacks register_with_cp."""
        import json as _json
        import urllib.error
        import urllib.request

        from ._paths import api_v1_url

        k = self._k
        url = api_v1_url(k._cfg.cp_url, "/agents", k._cfg.org_code)
        payload = {
            "agent_id": k._cfg.agent_id,
            "name": k._cfg.agent_name,
            "description": k._cfg.agent_description or "",
            "framework": framework,
            "capabilities": list(k._cfg.capabilities),
            "agent_type": k._cfg.agent_type or "generic",
            "source": k._cfg.agent_source,
        }
        body = _json.dumps(payload).encode("utf-8")
        from agt_sdk._gateway_headers import gateway_headers
        headers = {
            "X-AGT-Token": k._cfg.cp_token,
            "Content-Type": "application/json",
            "Accept": "application/json",
            **gateway_headers(k._cfg),     # PGAIAuthGateway
        }
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:  # noqa: S310
                raw = _json.loads(resp.read())
                agent_id = (raw.get("data") or {}).get("agent_id", k._cfg.agent_id)
                logger.info("agt_sdk: agent registered agent_id=%s status=%s", agent_id, resp.status)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            logger.warning("agt_sdk: direct registration failed (CP unreachable?): %s", exc)
        except Exception as exc:
            logger.warning("agt_sdk: direct registration unexpected error: %s", exc)

    def _maybe_wire_mesh(self) -> None:
        """IMPL-032 / IMPL-032.5: opt-in mesh features.

        IMPL-032 (identity + handshake publisher) and IMPL-032.5 (the
        three behavioural engines + their CP publishers) both gate on
        the same conditions:

        - The ``[mesh]`` install extra has pulled ``agentmesh-platform`` in.
        - A bootstrap-token exchange has succeeded (``kernel._bootstrap`` set).

        Fail-open at every step. The engine-construction block has its
        own ``try`` so an engine failure leaves handshake-only mode
        intact (still useful for A2A negotiation) rather than dropping
        all mesh features.
        """
        k = self._k
        if k._bootstrap is None:
            return
        # IMPL-032 identity + handshake publisher imports — the minimum
        # required for any mesh activity. If these fail, fall through to
        # governance-only mode.
        try:
            from agentmesh.identity import AgentIdentity
            from agentmesh.trust.publisher import CPHandshakePublisher
        except ImportError:
            logger.debug(
                "agt_sdk: agt-mesh-platform not installed — mesh features disabled. "
                "Install with: pip install 'agt-sdk[mesh]'"
            )
            return

        # Sponsor email is informational at this layer — the real sponsor
        # binding lives in CP's agents.sponsor_id via the bootstrap exchange.
        # Use a deterministic placeholder satisfying AgentIdentity's "@" check.
        sponsor_placeholder = f"{k._cfg.agent_name}@agt.local"

        # Construct AgentIdentity from the *bootstrap-derived* DID + keys.
        # Critical: we must NOT call AgentIdentity.create(), which would
        # generate a fresh DID + keypair. CP only knows about the bootstrap
        # DID (it received the public key during exchange); a fresh mesh DID
        # would cause every publisher POST to 404 against the CP agent row.
        try:
            identity = _identity_from_bootstrap(
                AgentIdentity,
                bootstrap=k._bootstrap,
                name=k._cfg.agent_name,
                sponsor=sponsor_placeholder,
                description=k._cfg.agent_description,
            )
        except Exception as exc:
            logger.warning("agt_sdk: mesh identity reconstruction failed: %s", exc)
            return

        try:
            publisher = CPHandshakePublisher(
                cp_url=k._cfg.cp_url,
                api_token=k._cfg.cp_token,
                org_code=k._cfg.org_code,   # org-scope so POSTs hit /api/v1/orgs/{org}/... (not the 307 legacy path)
                extra_headers=gateway_headers(k._cfg),   # PGAIAuthGateway
            )
        except Exception as exc:
            logger.warning("agt_sdk: CPHandshakePublisher construction failed: %s", exc)
            return

        # IMPL-040 Phase 5 — resilient wire-1.0 §11 registry client.
        #
        # The registry is what makes A2A peer verification possible: framework
        # adapters that build a TrustBridge pull `kernel.mesh_registry` and
        # pass it as `registry=...`, which lets the upstream `TrustHandshake`
        # look up the peer's public key from the CP. Without the registry
        # every handshake comes up unverified (the bug IMPL-040 set out to fix).
        #
        # Best-effort: if `agt-registry-client` isn't installed (mesh extra
        # present but registry sub-package missing), keep handshake-only mode
        # and let adapters degrade to unverified peers rather than blocking
        # mesh wiring altogether.
        registry: Any = None
        # Parse the timeout defensively: a malformed value should fall back to
        # the default and keep peer verification working, not be swallowed by
        # the broader try/except below and silently disable the registry.
        timeout_raw = os.environ.get("AGT_REGISTRY_TIMEOUT_MS", "").strip()
        try:
            timeout_ms = int(timeout_raw) if timeout_raw else 100
        except ValueError:
            logger.warning(
                "agt_sdk: AGT_REGISTRY_TIMEOUT_MS=%r is not an integer; "
                "falling back to default 100 ms.",
                timeout_raw,
            )
            timeout_ms = 100
        try:
            from agt_registry_client import HTTPRegistryStore

            registry = HTTPRegistryStore(
                base_url=k._cfg.cp_url,
                api_token=k._cfg.cp_token,
                timeout_ms=timeout_ms,
                extra_headers=gateway_headers(k._cfg),   # PGAIAuthGateway
            )
        except ModuleNotFoundError:
            # Package not installed at all — operator chose handshake-only
            # mode or didn't pick up the [mesh] extra. Quiet debug log so
            # we don't pollute the standard log path for a chosen mode.
            logger.debug(
                "agt_sdk: agt-registry-client not installed — A2A peers will "
                "not be verified. Reinstall with: pip install "
                "'agt-sdk[mesh]'"
            )
        except ImportError as exc:
            # Package is present but the import failed — old/incompatible
            # version missing HTTPRegistryStore, a transitive dep failing
            # to load, etc. That's a real wiring problem, not a chosen
            # mode, so surface it as a warning with the exception text.
            logger.warning(
                "agt_sdk: agt-registry-client import failed; A2A peers will "
                "not be verified. Reinstall or upgrade with: pip install "
                "--upgrade 'agt-sdk[mesh]'. Error: %s",
                exc,
            )
        except Exception as exc:
            logger.warning(
                "agt_sdk: HTTPRegistryStore construction failed; A2A peers "
                "will not be verified: %s",
                exc,
            )

        # IMPL-040 Phase 6 §6.1 — schedule the periodic metrics drain so
        # the registry's resilience signals (cache hit rate, breaker
        # state, p99 latency, stale-serve counts) reach operators via
        # the standard logging tree. Best-effort: if there's no running
        # loop yet (sync-only app), the drainer can be started later by
        # whoever brings the loop up. The interval is operator-tunable
        # via ``AGT_REGISTRY_METRICS_INTERVAL_SECONDS`` (defaults to the
        # client's own default of 60 s); set to ``0`` to disable.
        if registry is not None:
            interval_raw = os.environ.get(
                "AGT_REGISTRY_METRICS_INTERVAL_SECONDS", ""
            ).strip()
            try:
                interval = float(interval_raw) if interval_raw else None
            except ValueError:
                logger.warning(
                    "agt_sdk: AGT_REGISTRY_METRICS_INTERVAL_SECONDS=%r is not "
                    "a number; falling back to the default interval.",
                    interval_raw,
                )
                interval = None
            if interval is None or interval > 0:
                try:
                    from agt_registry_client import (
                        METRICS_DEFAULT_INTERVAL_SECONDS,
                        start_metrics_logger,
                    )

                    start_metrics_logger(
                        registry,
                        interval_seconds=interval or METRICS_DEFAULT_INTERVAL_SECONDS,
                    )
                except Exception as exc:
                    logger.debug(
                        "agt_sdk: registry metrics logger not scheduled: %s",
                        exc,
                    )

        # Late import to avoid circular at module-load time.
        from agt_sdk._kernel import _MeshWiring

        # IMPL-032.5 — per-agent behavioural engines + their CP publishers.
        # Wrapped in its own try so engine-tier failure (import or
        # construction) preserves handshake-only mode rather than
        # reverting to governance-only. The engine imports are local so
        # an environment with `agentmesh-platform` installed but with
        # the reward/risk modules partially absent still gets handshake
        # publishing.
        reward_engine: Any = None
        risk_scorer: Any = None
        network_engine: Any = None
        trust_pub: Any = None
        risk_pub: Any = None
        drift_pub: Any = None
        try:
            from agentmesh.identity.risk import RiskScorer
            from agentmesh.identity.risk_publisher import CPRiskPublisher
            from agentmesh.reward.drift_publisher import (
                CPDriftPublisher,
                CPDriftPublisherConfig,
            )
            from agentmesh.reward.engine import RewardEngine
            from agentmesh.reward.publisher import CPTrustPublisher
            from agentmesh.reward.trust_decay import NetworkTrustEngine

            reward_engine = RewardEngine()
            risk_scorer = RiskScorer()
            network_engine = NetworkTrustEngine()

            trust_pub = CPTrustPublisher(k._cfg.cp_url, k._cfg.cp_token, org_code=k._cfg.org_code,
                                         extra_headers=gateway_headers(k._cfg))
            risk_pub = CPRiskPublisher(k._cfg.cp_url, k._cfg.cp_token, org_code=k._cfg.org_code,
                                        extra_headers=gateway_headers(k._cfg))
            # AGT_DRIFT_SAMPLE_INTERVAL_SECONDS lets demos and tight-loop
            # tests turn the 60-second default into a few seconds so drift
            # samples land in the dashboard within one demo session.
            drift_interval = float(
                os.environ.get("AGT_DRIFT_SAMPLE_INTERVAL_SECONDS", "60")
            )
            drift_pub = CPDriftPublisher(
                CPDriftPublisherConfig(
                    cp_base_url=k._cfg.cp_url,
                    api_token=k._cfg.cp_token,
                    sample_interval_seconds=drift_interval,
                    org_code=k._cfg.org_code,
                    extra_headers=gateway_headers(k._cfg),   # PGAIAuthGateway
                ),
                engine=network_engine,
            )

            # Each callback fires inside the engine's recalc; we schedule
            # the publisher coroutine on the running loop. If startup ran
            # before the loop exists, the publish is dropped silently —
            # the next in-loop recalc will land.
            reward_engine.on_score_change(
                lambda did, score: _schedule(trust_pub.publish_score(did, score))
            )
            risk_scorer.on_score_change(
                lambda did, score: _schedule(risk_pub.publish_score(did, score))
            )
            network_engine.on_regime_change(drift_pub.on_alert)

            # The drift sampler-loop needs a running event loop. Schedule
            # if one is up; otherwise leave unscheduled — customers running
            # async apps can pick it up via kernel.mesh_engines later.
            task = _schedule(drift_pub.sample_loop())
            if task is not None:
                drift_pub._sampler_task = task
        except Exception as exc:
            logger.warning(
                "agt_sdk: mesh engine construction failed; falling back to handshake-only mode: %s",
                exc,
            )
            reward_engine = risk_scorer = network_engine = None
            trust_pub = risk_pub = drift_pub = None

        k._mesh = _MeshWiring(
            identity=identity,
            handshake_publisher=publisher,
            mesh_registry=registry,
            reward_engine=reward_engine,
            risk_scorer=risk_scorer,
            network_engine=network_engine,
            trust_publisher=trust_pub,
            risk_publisher=risk_pub,
            drift_publisher=drift_pub,
        )
        engines_state = "on" if reward_engine is not None else "off"
        registry_state = "on" if registry is not None else "off"
        logger.info(
            "agt_sdk: mesh wiring active (did=%s, engines=%s, registry=%s)",
            identity.did, engines_state, registry_state,
        )

    def _kernel_start_safely(self) -> None:
        """Call ``kernel.start()``, handling sync vs. async signatures."""
        k = self._k
        try:
            res = k._kernel.start()
            if asyncio.iscoroutine(res):
                # Async start — run in the current loop if present, else schedule.
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(res)
                except RuntimeError:
                    # No running loop — fire and forget in a fresh one.
                    asyncio.run(res)
        except Exception as exc:
            logger.warning("agt_sdk: kernel.start() raised: %s", exc)

    def _maybe_run_bootstrap(self) -> bool:
        """If AGT_BOOTSTRAP_TOKEN is set, exchange it for a sponsorship credential.

        On success the resolved DID replaces ``kernel._cfg.agent_id`` for the
        rest of the process. The sponsorship credential is stored on
        ``kernel._bootstrap`` (currently informational; trust-engine
        enforcement lands in IMPL-026).

        Returns:
            ``True`` to continue startup, ``False`` to abort (only when a
            non-401 bootstrap error hits in ``fail_mode=closed``).
        """
        k = self._k
        if not k._cfg.bootstrap_token:
            return True

        # IMPL-067 — deprecated, and the warning has to name the replacement or
        # it is just noise. Single-use is the defect, not the token length: every
        # restart needed either a fresh operator action or a fresh DID, and a new
        # DID resets trust, drift history and policy bindings.
        logger.warning(
            "agt_sdk: AGT_BOOTSTRAP_TOKEN is DEPRECATED and will be removed. "
            "Replace it with AGT_AGENT_TOKEN (the durable credential from "
            "Register Agent) plus AGT_AGENT_PASSPHRASE — the agent then keeps "
            "the SAME DID across restarts instead of minting a new identity "
            "each time. Bootstrap tokens are single-use, so this one is already "
            "spent for any future restart."
        )
        if k._cfg.uses_agent_credential:
            logger.warning(
                "agt_sdk: both AGT_BOOTSTRAP_TOKEN and the IMPL-067 credential "
                "are set. Running the deprecated bootstrap flow because the "
                "token is explicitly configured — unset AGT_BOOTSTRAP_TOKEN to "
                "switch over."
            )

        # Late lookup so test-side ``monkeypatch.setattr(agt_sdk._kernel,
        # "_bootstrap_exchange", ...)`` continues to work after IMPL-035's split.
        from agt_sdk import _kernel as _kmod
        from agt_sdk._bootstrap import BootstrapAlreadyConsumed, BootstrapError

        # Use the operator-provided AGT_AGENT_TYPE if set; otherwise
        # auto-detect the framework from imported adapters. The CP's
        # bootstrap path stamps agent_type onto the row at creation
        # time, and the post-bootstrap upsert refuses to overwrite a
        # non-empty agent_type — so we have to get this right HERE,
        # not later in register_with_cp.
        agent_type = k._cfg.agent_type or _detect_framework()
        try:
            result = _kmod._bootstrap_exchange(
                cp_url=k._cfg.cp_url,
                bootstrap_token=k._cfg.bootstrap_token,
                name=k._cfg.agent_name,
                agent_type=agent_type,
                source=k._cfg.agent_source,
                capabilities=list(k._cfg.capabilities),       # IMPL-036
                description=k._cfg.agent_description,         # IMPL-036
                org_code=k._cfg.org_code,                     # IMPL-045
                gateway_api_key=k._cfg.gateway_api_key,       # PGAIAuthGateway
            )
        except BootstrapAlreadyConsumed as exc:
            logger.warning(
                "agt_sdk: AGT_BOOTSTRAP_TOKEN already consumed; "
                "falling back to AGT_AGENT_ID=%s. (%s)",
                k._cfg.agent_id, exc,
            )
            return True
        except BootstrapError as exc:
            if k._cfg.fail_mode == "closed":
                logger.error(
                    "agt_sdk: bootstrap exchange failed in fail_mode=closed: %s. "
                    "Aborting agent start.", exc,
                )
                return False
            logger.warning(
                "agt_sdk: bootstrap exchange failed (fail_mode=open); "
                "falling back to AGT_AGENT_ID=%s. (%s)",
                k._cfg.agent_id, exc,
            )
            return True

        # Success — replace the frozen config's agent_id with the returned DID.
        # IMPL-024.5: also swap in the scoped api_token returned by the CP if
        # the CP supplied one. This collapses two operator-issued credentials
        # (AGT_BOOTSTRAP_TOKEN + AGT_CP_TOKEN) into one (just AGT_BOOTSTRAP_TOKEN).
        # Older CPs that don't ship IMPL-024.5 return api_token=None, so the
        # existing AGT_CP_TOKEN path stays valid as a fallback.
        k._bootstrap = result
        replace_fields: dict[str, Any] = {"agent_id": result.did}
        if result.api_token:
            replace_fields["cp_token"] = result.api_token
            logger.info(
                "agt_sdk: bootstrap swapped in scoped api_token (name=boot:%s, expires=%s)",
                result.did[-12:],
                result.api_token_expires_at.isoformat() if result.api_token_expires_at else "n/a",
            )
        # IMPL-045 — if the CP echoed back the org slug, adopt it so the
        # rest of startup (policy provider, heartbeat, ingest, direct
        # register fallback) addresses the org-scoped URL directly. If
        # AGT_ORG_CODE was already set the two should match — log if not.
        if result.organization_slug:
            if k._cfg.org_code and k._cfg.org_code != result.organization_slug:
                logger.warning(
                    "agt_sdk: AGT_ORG_CODE=%r disagrees with bootstrap response "
                    "organization_slug=%r — adopting bootstrap value.",
                    k._cfg.org_code, result.organization_slug,
                )
            replace_fields["org_code"] = result.organization_slug
        k._cfg = dataclasses.replace(k._cfg, **replace_fields)
        logger.info(
            "agt_sdk: bootstrap successful  did=%s  cp_root=%s  agent_row=%s",
            result.did, result.cp_root_did, result.agent_id,
        )
        # Decoded credential payload (no signature check) — useful for ops logs.
        try:
            payload = result.decoded_credential()
            if payload:
                logger.info("agt_sdk: sponsorship credential payload:")
                for k_, v in sorted(payload.items()):
                    logger.info("              %s = %s", k_, v)
        except Exception:
            pass
        return True

    def _maybe_attach_identity(self) -> bool:
        """IMPL-067 — recover or generate this agent's key and attach its DID.

        Skipped entirely unless the agent credential or the passphrase is set, so
        existing deployments are untouched. When either is set, **both** are
        required: a half-configured agent must hit an actionable error here
        rather than fall through to the env-derived identity and quietly
        re-identify itself on every restart.

        Returns:
            ``True`` to continue startup, ``False`` to abort.
        """
        k = self._k
        cfg = k._cfg
        if not cfg.uses_agent_credential:
            return True
        if cfg.bootstrap_token:
            return True          # the deprecated flow already ran

        # Both-or-neither. Neither message says "invalid configuration" — each
        # says which variable is missing and what it is for, because the operator
        # reading it is holding a half-finished deployment config.
        if not cfg.agent_token:
            logger.error(
                "agt_sdk: AGT_AGENT_PASSPHRASE is set but AGT_AGENT_TOKEN is "
                "not. The passphrase only decrypts the key; the credential is "
                "what identifies the agent to the control plane. Get one from "
                "Register Agent in the UI — it is shown once."
            )
            return False
        if not cfg.agent_passphrase:
            logger.error(
                "agt_sdk: AGT_AGENT_TOKEN is set but AGT_AGENT_PASSPHRASE is "
                "not. Without the passphrase the private key cannot be escrowed, "
                "so this agent would mint a new DID on every restart and lose "
                "its trust and drift history each time. Refusing to start on "
                "those terms — set the organisation passphrase."
            )
            return False

        from agt_sdk import _kernel as _kmod
        from agt_sdk._bootstrap import IdentityAttachError, KeyRecoveryFailed

        agent_type = cfg.agent_type or _detect_framework()
        try:
            result = _kmod._attach_identity(
                cp_url=cfg.cp_url,
                credential=cfg.agent_token,
                org_code=cfg.org_code,
                agent_name=cfg.agent_name,
                passphrase=cfg.agent_passphrase,
                agent_type=agent_type,
                source=cfg.agent_source,
                capabilities=list(cfg.capabilities),
                description=cfg.agent_description,
                gateway_api_key=cfg.gateway_api_key,
            )
        except KeyRecoveryFailed as exc:
            # Fatal in BOTH fail modes, deliberately. fail_mode=open means "let
            # the agent run ungoverned rather than not at all" — it does not mean
            # "let the agent run as a different agent". Continuing here would
            # generate a fresh key, mint a new DID, and present a wrong
            # passphrase as a clean first boot.
            logger.error(
                "agt_sdk: %s  (fail_mode=%s is ignored for key recovery — "
                "continuing would silently replace this agent's identity)",
                exc, cfg.fail_mode,
            )
            return False
        except IdentityAttachError as exc:
            if cfg.fail_mode == "closed":
                logger.error(
                    "agt_sdk: identity attach failed in fail_mode=closed: %s. "
                    "Aborting agent start.", exc,
                )
                return False
            logger.warning(
                "agt_sdk: identity attach failed (fail_mode=open); falling back "
                "to AGT_AGENT_ID=%s. This agent is not governed under its "
                "registered identity. (%s)",
                cfg.agent_id, exc,
            )
            return True

        k._bootstrap = result
        # The agent credential IS this agent's CP credential — name-bound and
        # revocable per agent, which a shared operator token is not. It wins over
        # AGT_CP_TOKEN for this process's own calls.
        replace_fields: dict[str, Any] = {
            "agent_id": result.did,
            "cp_token": cfg.agent_token,
        }
        if result.organization_slug:
            if cfg.org_code and cfg.org_code != result.organization_slug:
                logger.warning(
                    "agt_sdk: AGT_ORG_CODE=%r disagrees with the control "
                    "plane's organization_slug=%r — adopting the CP value.",
                    cfg.org_code, result.organization_slug,
                )
            replace_fields["org_code"] = result.organization_slug
        k._cfg = dataclasses.replace(cfg, **replace_fields)

        logger.info(
            "agt_sdk: identity attached  did=%s  epoch=%d  new_epoch=%s  cp_root=%s",
            result.did, result.epoch_count, result.new_epoch, result.cp_root_did,
        )
        if not result.new_epoch:
            logger.info(
                "agt_sdk: same DID as the previous run — trust score, drift "
                "history and policy bindings all carry over."
            )
        return True


# Detection table for `_detect_framework`. Two tiers are checked in this
# strict priority order — the first sys.modules hit wins.
#
# Tier 1: SDK adapter modules. Most specific signal — the developer
#         explicitly imported the AGT wrapper for that framework.
# Tier 2: framework root packages. Fallback for when the adapter import
#         silently fails (e.g. version-mismatch ImportError) or the
#         agent calls kernel.check() directly without using the adapter
#         but is clearly a langchain/crewai/etc. agent.
#
# Order within each tier matters: more specific frameworks come first
# (langgraph before langchain; langchain before langchain_core) so a
# langgraph agent that pulls in langchain transitively still labels as
# "langgraph".
_FRAMEWORK_DETECTORS: tuple[tuple[str, str], ...] = (
    # Tier 1 — SDK adapter modules
    ("agt_sdk.langgraph",      "langgraph"),
    ("agt_sdk.langchain",      "langchain"),
    ("agt_sdk.crewai",         "crewai"),
    ("agt_sdk.autogen",        "autogen"),
    ("agt_sdk.openai_agents",  "openai-agents"),
    # Tier 2 — framework root packages
    ("langgraph",              "langgraph"),
    ("crewai",                 "crewai"),
    ("autogen",                "autogen"),
    ("autogen_agentchat",      "autogen"),
    ("langchain",              "langchain"),
    ("langchain_core",         "langchain"),
)


def _detect_framework() -> str:
    """Return the framework label for this process by scanning sys.modules.

    Two-tier detection (see ``_FRAMEWORK_DETECTORS``):

    Tier 1 — agent code has imported the SDK adapter
    (``agt_sdk.langchain``, ``agt_sdk.crewai``, …). Definitive signal.

    Tier 2 — the underlying framework's own package
    (``langchain``, ``langchain_core``, ``crewai``, …) is loaded. Used
    when the adapter import was attempted but failed (e.g. version
    mismatch — ``agt_sdk.langchain`` requires a specific middleware
    API), or when the agent calls ``kernel.check`` directly without
    the adapter but is otherwise running inside a known framework.

    Falls back to ``"unknown"`` when nothing in ``sys.modules`` matches
    a known framework — matches the dashboard's existing label for
    shadow / un-attributable agents rather than misleadingly tagging
    raw-kernel callers as the SDK package itself.
    """
    for module_name, label in _FRAMEWORK_DETECTORS:
        if module_name in sys.modules:
            return label
    return "unknown"


def _schedule(coro: Any) -> Any:
    """IMPL-032.5: schedule a coroutine on the running loop, fail-open.

    Returns the asyncio Task if a loop is running, or ``None`` (and
    silently closes the coroutine) when no loop exists. Used for the
    score-change callbacks where we want fire-and-forget semantics —
    if no loop is up at SDK-startup time, the next in-loop recalc will
    drive a fresh publish.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        try:
            coro.close()
        except Exception:
            pass
        return None
    try:
        return loop.create_task(coro)
    except Exception:
        try:
            coro.close()
        except Exception:
            pass
        return None


def _identity_from_bootstrap(
    AgentIdentity: Any,         # the mesh class — passed in to avoid a top-level import
    *,
    bootstrap: Any,             # BootstrapResult
    name: str,
    sponsor: str,
    description: str = "",
) -> Any:
    """Reconstruct an ``AgentIdentity`` from a successful bootstrap exchange.

    The agent-mesh ``AgentIdentity.create`` factory generates its own
    Ed25519 keypair + DID — which is exactly what we want to AVOID after a
    bootstrap exchange, because CP already has a registered agent row keyed
    by the bootstrap-generated DID + public key. Re-creating the identity
    with a new DID would orphan every signal publish under a DID the CP
    doesn't know.

    This helper instead constructs the mesh ``AgentIdentity`` directly
    from the bootstrap material:

    - ``did``               — the DID the agent registered as
    - ``public_key``        — base64-encoded raw bytes (derived from the JWK)
    - ``verification_key_id`` — sha256 fingerprint, same shape ``AgentIdentity.create`` uses
    - ``_private_key``      — the in-process Ed25519PrivateKey

    The private key is in-process only. CP holds the public half (received
    during the bootstrap POST); the private half is never serialized,
    transmitted, or written to disk.
    """
    import base64
    import hashlib
    # AgentIdentity.did is typed as AgentDID (a Pydantic BaseModel), not str —
    # Pydantic v2 won't auto-coerce a plain string. Safe to import inline:
    # the only caller (_maybe_wire_mesh) has already gated on the agentmesh
    # import succeeding, so this won't fail when [mesh] is missing.
    from agentmesh.identity import AgentDID

    if bootstrap is None or bootstrap.private_key is None:
        raise RuntimeError("bootstrap result missing private_key — cannot reconstruct identity")

    # ``public_key_jwk['x']`` is the public key's raw bytes, base64url-encoded
    # without padding (RFC 7517 OKP form). AgentIdentity.public_key expects
    # standard base64 of the raw bytes — convert by decoding url-safe then
    # re-encoding standard.
    jwk_x: str = bootstrap.public_key_jwk["x"]
    padding = "=" * (-len(jwk_x) % 4)
    raw_pub_bytes = base64.urlsafe_b64decode(jwk_x + padding)
    public_key_b64 = base64.b64encode(raw_pub_bytes).decode()
    key_id = f"key-{hashlib.sha256(raw_pub_bytes).hexdigest()[:16]}"

    identity = AgentIdentity(
        did=AgentDID.from_string(bootstrap.did),
        name=name,
        description=description or None,
        public_key=public_key_b64,
        verification_key_id=key_id,
        sponsor_email=sponsor,
        capabilities=[],
    )
    # Same private slot the factory uses — kept off the schema so Pydantic
    # doesn't try to serialize it.
    identity._private_key = bootstrap.private_key
    return identity
