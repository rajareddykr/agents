# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Agent enrolment — two flows, one of them on its way out.

**IMPL-067, the current model** (:func:`attach_identity`). An operator registers
the agent once in the UI and receives a long-lived credential. The agent presents
that same credential on every start:

    first start    generate keypair → attach public key → escrow private key
    every restart  recover key from escrow → SAME DID → attach, no new epoch

Nothing is re-minted per restart. The agent holds a durable credential
(``AGT_AGENT_TOKEN``) and an organisation-wide passphrase
(``AGT_AGENT_PASSPHRASE``); the credential authenticates, the passphrase
decrypts, and neither alone yields a private key.

**IMPL-023 bootstrap tokens, deprecated** (:func:`exchange`, below). Single-use
and short-lived, so every restart needed a new operator action or a new DID.
Still honoured, with a warning. IMPL-067 Phase 4 deletes it and leaves this
module holding only key generation, attach and escrow restore.

Bootstrap-token background (deprecated)
---------------------------------------
A bootstrap token is a single-use, short-lived credential issued by an
operator (or CI/CD pipeline) that carries the operator's ``sponsor_id``.
When the agent process starts, the SDK exchanges the bootstrap token for:

  * an Ed25519 keypair (generated locally; private key never leaves the process)
  * a ``did:mesh:<...>`` agent DID derived from the public key
  * a CP-signed *sponsorship credential* (JWT) that proves the agent was
    sponsored by the operator
  * a stable agent row UUID in the CP registry

After the exchange the SDK uses the returned DID as the agent identity for
all subsequent calls (register, heartbeat, decisions). Long-lived calls
continue to authenticate with ``AGT_CP_TOKEN`` (`X-AGT-Token` header).
The bootstrap token is **consumed** by the exchange — re-use returns
HTTP 401.

Environment
-----------
* ``AGT_BOOTSTRAP_TOKEN`` — when set, the SDK runs the exchange at startup.
* ``AGT_AGENT_TYPE`` — optional; recorded on the agent row.
* ``AGT_AGENT_SOURCE`` — optional; defaults to ``"agt_sdk"``.

Idempotence + restart
---------------------
Bootstrap tokens are single-use. On agent restart you have two choices:

  1. Issue a fresh bootstrap token (operator-driven provisioning).
  2. Capture the DID from the first run, then on subsequent runs unset
     ``AGT_BOOTSTRAP_TOKEN`` and set ``AGT_AGENT_ID=did:mesh:<...>``
     instead. The SDK uses the long-lived ``AGT_CP_TOKEN`` for ongoing
     calls — no further bootstrap needed.

If ``AGT_BOOTSTRAP_TOKEN`` is left set on a restart and the token has
already been consumed, the SDK logs a warning and falls back to the
env-derived identity (``AGT_AGENT_ID`` or hostname-script default).

Dependencies
------------
This module imports ``cryptography`` lazily — if it is not installed,
calling :func:`exchange` raises :class:`BootstrapError` with a clear
install hint. Customers who do not use bootstrap tokens do not need
``cryptography``.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ._paths import api_v1_url

logger = logging.getLogger("agt_sdk.bootstrap")


# ── Result + errors ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class BootstrapResult:
    """Outcome of a successful bootstrap-token exchange.

    Attributes:
        did:                    Agent DID, e.g. ``did:mesh:abc123…``.
        public_key_jwk:         The agent's public key as an Ed25519 JWK.
        sponsorship_credential: CP-signed JWT proving sponsorship. Carries
                                ``sponsor_id`` in the payload (currently
                                dormant — IMPL-026 will enforce on the
                                trust-engine side).
        cp_root_did:            DID of the CP that signed the credential.
        credential_expires_at:  Parsed credential expiry timestamp (or
                                ``None`` if the CP didn't supply one).
        agent_id:               UUID of the upserted agent row in CP.
    """
    did: str
    public_key_jwk: dict
    sponsorship_credential: str
    cp_root_did: str
    credential_expires_at: datetime | None
    agent_id: str
    # IMPL-024.5 — scoped API token minted by the CP on bootstrap consume.
    # When present, the SDK uses this as its cp_token for the rest of the
    # process (register / heartbeat / decision-ingest), so agents need only
    # one operator-issued credential (AGT_BOOTSTRAP_TOKEN). None on older
    # CPs that haven't shipped the IMPL-024.5 backend yet.
    api_token: str | None = None
    api_token_expires_at: datetime | None = None

    # IMPL-045 — org slug echoed back by the CP. When present, the SDK adopts
    # it as ``cfg.org_code`` for the rest of the process so subsequent
    # heartbeat / ingest / policy-bundle calls address the right tenant URL
    # without the operator needing to also set ``AGT_ORG_CODE``. ``None`` on
    # older CPs that haven't shipped the IMPL-045 backend yet.
    organization_slug: str | None = None

    # IMPL-024.5 + IMPL-032.5 — the Ed25519 private key generated for this
    # exchange. Kept on the result (in-process only, never serialized) so
    # ``Lifecycle._maybe_wire_mesh`` can construct an ``AgentIdentity``
    # bound to the *same* DID the CP registered, instead of generating a
    # fresh one whose DID the CP doesn't know.
    #
    # ``repr=False`` keeps the key out of dataclass logging; ``compare=False``
    # excludes it from equality so two BootstrapResults with otherwise
    # identical fields compare equal regardless of the key object.
    # Typed as ``Any`` to avoid hard-importing ``cryptography`` at module load.
    private_key: Any = field(default=None, repr=False, compare=False)

    # IMPL-067 — set by ``attach_identity``; left at the defaults by the
    # bootstrap exchange, which has no epoch concept to report.
    #
    # ``new_epoch=False`` on a restart is the whole feature, observable in one
    # field: the agent recovered its key, presented the DID it already had, and
    # the CP matched the epoch it already has instead of opening another.
    epoch_count: int = 0
    new_epoch: bool = True

    def decoded_credential(self) -> dict:
        """Decode the credential JWT payload (no signature check — logs only)."""
        parts = self.sponsorship_credential.split(".")
        if len(parts) != 3:
            return {}
        try:
            pad = "=" * (-len(parts[1]) % 4)
            return json.loads(base64.urlsafe_b64decode(parts[1] + pad))
        except Exception:
            return {}


class BootstrapError(Exception):
    """Bootstrap exchange failed for a non-recoverable reason."""


class BootstrapAlreadyConsumed(BootstrapError):
    """The bootstrap token has already been consumed by a previous run.

    Common on agent restart when ``AGT_BOOTSTRAP_TOKEN`` was left in the
    environment. The SDK catches this and falls back to env-derived
    identity, so it is not fatal.
    """


class IdentityAttachError(BootstrapError):
    """The IMPL-067 identity attach failed. Honours ``AGT_FAIL_MODE``."""


class KeyRecoveryFailed(IdentityAttachError):
    """An escrowed key exists but could not be recovered.

    **Always fatal, regardless of fail_mode** — and that is the whole point.
    Falling through here would generate a fresh keypair, which mints a new DID
    and presents a wrong passphrase or a brief CP outage as a clean first boot.
    The agent would come up looking healthy, having silently replaced itself and
    abandoned its trust score, drift history and policy bindings.

    :class:`IdentityAttachError` is recoverable-ish and respects fail_mode; this
    subclass is deliberately not.
    """


# ── Public API ───────────────────────────────────────────────────────────────


def exchange(
    cp_url: str,
    bootstrap_token: str,
    *,
    name: str = "",
    agent_type: str = "",
    source: str = "agt_sdk",
    capabilities: list[str] | None = None,
    description: str = "",
    timeout: float = 10.0,
    org_code: str = "",
    gateway_api_key: str = "",
) -> BootstrapResult:
    """Exchange a bootstrap token for an agent identity + sponsorship credential.

    Single-use: a successful exchange consumes the token. Re-using the
    same token raises :class:`BootstrapAlreadyConsumed`.

    Args:
        cp_url:           Control plane base URL.
        bootstrap_token:  Operator-issued bootstrap token (sent in the
                          ``X-AGT-Bootstrap-Token`` header).
        name:             Display name for the agent row (optional).
        agent_type:       Overrides the type recorded on the bootstrap
                          token (optional).
        source:           Registration source label. Defaults to
                          ``"agt_sdk"``.
        capabilities:     IMPL-036 — list of capability strings (recommended
                          form ``verb:resource``; no regex enforced). Empty
                          or None values are not sent.
        description:      IMPL-036 — human-readable agent description shown
                          on the dashboard.
        timeout:          HTTP timeout in seconds.
        org_code:         REQUIRED (IMPL-060). The CP bootstrap consume is
                          org-scoped: ``POST /api/v1/orgs/{org_code}/agents/bootstrap``.
                          The bootstrap token stays the credential and remains the
                          single source of tenancy — ``org_code`` is routing
                          metadata that lets the call ride an auth gateway
                          forwarding only ``/api/v1/orgs/**``, and the CP validates
                          it against the token's own org (403 on mismatch). Raises
                          :class:`BootstrapError` if empty. The CP still echoes the
                          agent's org_slug via ``BootstrapConsumeOut.organization_slug``;
                          ``_lifecycle._maybe_run_bootstrap`` adopts it into
                          ``SdkConfig.org_code`` for all subsequent org-scoped calls.

    Returns:
        :class:`BootstrapResult` with the resolved DID, sponsorship
        credential, and agent row UUID.

    Raises:
        BootstrapAlreadyConsumed: Token has already been consumed.
        BootstrapError:           Network / non-401 error, or the
                                  ``cryptography`` package is missing.
    """
    private_key, public_jwk, did = _generate_keypair()

    body: dict[str, Any] = {"did": did, "public_key": public_jwk}
    if name:
        body["name"] = name
    if agent_type:
        body["agent_type"] = agent_type
    if source:
        body["source"] = source
    if capabilities:
        body["capabilities"] = capabilities
    if description:
        body["description"] = description

    # IMPL-060 — bootstrap CONSUME is org-scoped on the CP
    # (``POST /api/v1/orgs/{org_code}/agents/bootstrap``). ``org_code`` is
    # required: the operator who minted the token knows the org, and it is
    # supplied via ``AGT_ORG_CODE``. Org-scoping lets the call ride an auth
    # gateway that forwards only ``/api/v1/orgs/**``; the bootstrap token is
    # carried in the gateway-forwarded ``X-AGT-Bootstrap-Token`` header, NOT in
    # ``Authorization`` (which such gateways validate as a platform JWT and
    # reject). The token stays the credential; ``{org_code}`` is routing
    # metadata, validated against the token's own org in-handler.
    if not org_code:
        raise BootstrapError(
            "agt_sdk: AGT_ORG_CODE is required to consume a bootstrap token "
            "(the CP bootstrap endpoint is org-scoped: "
            "POST /api/v1/orgs/{org_code}/agents/bootstrap)."
        )
    url = f"{cp_url.rstrip('/')}/api/v1/orgs/{org_code}/agents/bootstrap"
    headers = {
        "X-AGT-Bootstrap-Token": bootstrap_token,
        "Content-Type":          "application/json",
        "Accept":                "application/json",
    }
    # PGAIAuthGateway header — when the deployment routes the SDK through
    # the gateway, every outbound request must carry this key. Empty when
    # the SDK talks to the CP directly.
    if gateway_api_key:
        from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
        headers[GATEWAY_API_KEY_HEADER] = gateway_api_key
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:    # noqa: S310
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", errors="replace")[:400]
        except Exception:
            detail = "<no body>"
        if exc.code == 401:
            raise BootstrapAlreadyConsumed(
                f"Bootstrap token rejected (HTTP 401): {detail}"
            ) from exc
        raise BootstrapError(
            f"Bootstrap exchange failed (HTTP {exc.code}): {detail}"
        ) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise BootstrapError(f"Bootstrap exchange failed: {exc}") from exc

    data = payload.get("data", {}) if isinstance(payload, dict) else {}
    cred = data.get("sponsorship_credential", "")
    cp_root = data.get("cp_root_did", "")
    expires_raw = data.get("expires_at", "") or ""
    agent_id = data.get("agent_id", "")
    # IMPL-024.5 — optional scoped api_token for the single-credential flow.
    api_token = data.get("api_token") or None
    api_token_expires_raw = data.get("api_token_expires_at", "") or ""
    # IMPL-045 — CP echoes back the org slug. Accept either key name to be
    # forgiving across versions; None on pre-IMPL-045 CPs.
    organization_slug = (
        data.get("organization_slug")
        or data.get("org_code")
        or None
    )

    expires_at: datetime | None = None
    if expires_raw:
        try:
            expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
        except ValueError:
            expires_at = None

    api_token_expires_at: datetime | None = None
    if api_token_expires_raw:
        try:
            api_token_expires_at = datetime.fromisoformat(
                api_token_expires_raw.replace("Z", "+00:00")
            )
        except ValueError:
            api_token_expires_at = None

    return BootstrapResult(
        did=did,
        public_key_jwk=public_jwk,
        sponsorship_credential=cred,
        cp_root_did=cp_root,
        credential_expires_at=expires_at,
        agent_id=agent_id,
        api_token=api_token,
        api_token_expires_at=api_token_expires_at,
        organization_slug=organization_slug,
        # In-process only: handed off to AgentIdentity for local crypto.
        # Never serialized, never sent to CP. CP got the public half above.
        private_key=private_key,
    )


# ── IMPL-067 — the durable agent credential ─────────────────────────────────
#
# The flow that replaces everything above. An operator registers the agent once
# and gets a long-lived credential; the agent presents it on every start.
#
#   first start    generate keypair → attach public key → escrow private key
#   every restart  recover key from escrow → SAME DID → attach again, no-op
#
# The agent asks nobody for its DID. A DID is ``sha256(public_key)[:24]``, so
# recovering the key recomputes it — and that recomputation is simultaneously
# proof that the recovered key is the one the DID was minted from.


def attach_identity(
    cp_url: str,
    credential: str,
    *,
    org_code: str,
    agent_name: str,
    passphrase: str,
    agent_type: str = "",
    source: str = "agt_sdk",
    capabilities: list[str] | None = None,
    description: str = "",
    timeout: float = 10.0,
    gateway_api_key: str = "",
) -> BootstrapResult:
    """Attach this agent's DID to its registered name, recovering the key first.

    Idempotent by construction: a restart that recovers its key presents the DID
    it already had, and the CP matches the existing epoch rather than opening a
    new one. ``BootstrapResult.new_epoch`` reports which happened — ``False`` on
    a successful restart is the observable proof this feature works.

    Args:
        cp_url:      Control plane base URL.
        credential:  ``AGT_AGENT_TOKEN`` — the durable agent credential, sent as
                     ``X-AGT-Token``. The CP resolves it to *which* agent is
                     calling via its binding row, which is why no request here
                     carries a name for the caller to lie about.
        org_code:    ``AGT_ORG_CODE``. Required — every route is org-scoped, and
                     it is also half of the escrow derivation handle.
        agent_name:  ``AGT_AGENT_NAME``. Must match the registered name: it is
                     the other half of the handle, so a mismatch decrypts
                     nothing. Used locally only; never sent as the caller's
                     identity.
        passphrase:  ``AGT_AGENT_PASSPHRASE``. Never transmitted.

    Returns:
        :class:`BootstrapResult`, the same shape the bootstrap exchange returns,
        so ``_lifecycle._maybe_wire_mesh`` needs no knowledge of which flow ran.

    Raises:
        KeyRecoveryFailed: an escrowed key exists but will not decrypt, or the
                           CP was unreachable. Always fatal — see the class.
        IdentityAttachError: attach itself failed. Honours fail_mode.
    """
    if not org_code:
        raise IdentityAttachError(
            "agt_sdk: AGT_ORG_CODE is required — the identity and escrow routes "
            "are org-scoped, and the org code is half the key-derivation handle."
        )
    if not agent_name:
        raise IdentityAttachError(
            "agt_sdk: AGT_AGENT_NAME is required and must match the name the "
            "agent was registered under — it is half the key-derivation handle, "
            "so a different name silently decrypts nothing."
        )

    backup = _key_backup(cp_url, credential, passphrase, gateway_api_key=gateway_api_key)

    # Refuse BEFORE minting. Without the escrow crypto there is nowhere to put a
    # private key, so every restart recovers nothing, generates a fresh keypair
    # and mints a NEW DID — resetting trust to the baseline, orphaning the 30-day
    # decision history and silently dropping the agent's policy binding, which
    # targets the DID it no longer has. That is the exact outcome
    # `_maybe_attach_identity` already refuses to start on when
    # AGT_AGENT_PASSPHRASE is missing; the cause differs, the consequence does
    # not. This branch was fail-open only because the extra is *optional* — but
    # it is optional for agents that never enrol, and reaching here means this
    # one is enrolling.
    if backup is None:
        raise KeyRecoveryFailed(
            f"agt_sdk: key escrow is unavailable, so this agent cannot keep an "
            f"identity across a restart — it would mint a new DID every start "
            f"and lose its trust score, drift history and policy bindings each "
            f"time. Refusing to start on those terms. {_ESCROW_MISSING_HINT}"
        )

    # ── recover, or generate ────────────────────────────────────────────────
    private_key = None
    blob = _escrow_fetch(
        cp_url, org_code=org_code, credential=credential,
        timeout=timeout, gateway_api_key=gateway_api_key,
    )
    if blob is not None:
        try:
            private_key = backup.decrypt(blob, org_code, agent_name)
        except Exception as exc:                           # noqa: BLE001
            raise KeyRecoveryFailed(
                f"agt_sdk: the escrowed key for {org_code}|{agent_name} could "
                f"not be decrypted ({type(exc).__name__}). Check "
                f"AGT_AGENT_PASSPHRASE and AGT_AGENT_NAME. Refusing to start "
                f"with a new identity, which would silently replace this agent."
            ) from exc

    first_boot = private_key is None
    if first_boot:
        private_key, public_jwk, did = _generate_keypair()
    else:
        public_jwk, did = _public_jwk_and_did(private_key)
        logger.info(
            "agt_sdk: key recovered from escrow — did=%s, same identity, no new epoch",
            did,
        )

    # ── attach ──────────────────────────────────────────────────────────────
    # No ``name`` field. The CP reads the name off the credential's binding, so
    # the request has no way to claim a different agent (IMPL-067 §2.4). Do not
    # add one for symmetry with the bootstrap body above.
    body: dict[str, Any] = {"did": did, "public_key": public_jwk}
    if agent_type:
        body["agent_type"] = agent_type
    if source:
        body["source"] = source
    if capabilities:
        body["capabilities"] = capabilities
    if description:
        body["description"] = description

    url = f"{cp_url.rstrip('/')}/api/v1/orgs/{org_code}/agents/identity"
    try:
        payload = _post_json(
            url, body, credential=credential,
            timeout=timeout, gateway_api_key=gateway_api_key,
        )
    except urllib.error.HTTPError as exc:
        detail = _read_detail(exc)
        raise IdentityAttachError(
            f"agt_sdk: identity attach failed (HTTP {exc.code}): {detail}"
            + (
                " — a 401/403 here usually means AGT_AGENT_TOKEN is not an agent "
                "credential (an operator or service token has no binding row, and "
                "absence of a binding is a denial), or it has been revoked."
                if exc.code in (401, 403) else ""
            )
        ) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise IdentityAttachError(f"agt_sdk: identity attach failed: {exc}") from exc

    data = payload.get("data", {}) if isinstance(payload, dict) else {}
    new_epoch = bool(data.get("new_epoch", first_boot))

    # A restart that had to generate a key is the failure this feature exists to
    # prevent, and it is invisible unless said out loud: the agent works, and
    # only its history is gone.
    if new_epoch and not first_boot:
        logger.warning(
            "agt_sdk: attach opened a NEW epoch despite recovering a key — the "
            "control plane had not seen did=%s before. Trust and drift history "
            "start over.", did,
        )

    # ── escrow, on first boot only ──────────────────────────────────────────
    # Deliberately after a successful attach: escrowing a key the CP never
    # accepted would leave a blob for an identity that does not exist, and the
    # next start would recover it and attach then — with the same result, one
    # restart later. Attach-then-escrow keeps the two in step.
    # `backup` is guaranteed non-None here — the unavailable case refuses above,
    # before a key is ever minted.
    if first_boot:
        _escrow_store(
            cp_url, backup, private_key,
            org_code=org_code, agent_name=agent_name, credential=credential,
            key_id=did, timeout=timeout, gateway_api_key=gateway_api_key,
        )

    expires_at = _parse_ts(data.get("expires_at", "") or "")
    return BootstrapResult(
        did=did,
        public_key_jwk=public_jwk,
        sponsorship_credential=data.get("sponsorship_credential", ""),
        cp_root_did=data.get("cp_root_did", ""),
        credential_expires_at=expires_at,
        agent_id=data.get("agent_id", ""),
        # The credential does not rotate here — the operator holds it and rotates
        # it in the UI. Leaving api_token None keeps ``_lifecycle`` from swapping
        # in something shorter-lived than what the operator deployed.
        api_token=None,
        organization_slug=data.get("organization_slug") or None,
        private_key=private_key,
        epoch_count=int(data.get("epoch_count") or 0),
        new_epoch=new_epoch,
    )


_ESCROW_MISSING_HINT = (
    "agt-mesh-platform is not installed, so the escrow crypto is unavailable — "
    "install with: pip install 'agt-sdk[mesh]'"
)


def _key_backup(
    cp_url: str, credential: str, passphrase: str, *, gateway_api_key: str = "",
) -> Any:
    """The escrow crypto helper, or ``None`` when agent-mesh is not installed.

    Imported lazily and by name so the mesh plane stays an optional extra (and
    so this module keeps importing on an agent that never enrols this way).

    Only the **crypto** is borrowed — ``encrypt`` / ``decrypt``, and with them
    the HKDF derivation, the AES-GCM AAD and the ``org|name`` handle. Transport
    is done here with ``urllib`` instead of the service's own ``httpx`` calls,
    which are ``async``: ``Lifecycle.start`` is synchronous and may itself be
    running inside somebody's event loop, where ``asyncio.run`` raises. Two
    copies of the *crypto* would be a real hazard; two copies of a PUT are not.

    Raises:
        IdentityAttachError: the passphrase is missing or too weak. The service
                             validates length in its constructor, and that
                             refusal is worth surfacing rather than swallowing.
    """
    try:
        from agentmesh.identity.key_backup import KeyBackupService
    except ImportError:
        return None
    try:
        return KeyBackupService(
            cp_url=cp_url,
            api_token=credential,
            agent_passphrase=passphrase,
            extra_headers=_gateway_header(gateway_api_key),
        )
    except ValueError as exc:
        raise IdentityAttachError(f"agt_sdk: {exc}") from exc


def _escrow_fetch(
    cp_url: str, *, org_code: str, credential: str,
    timeout: float, gateway_api_key: str,
) -> str | None:
    """This agent's ciphertext, or ``None`` when nothing is escrowed yet.

    The request carries no name and no DID — the CP resolves the caller through
    its credential binding and returns that agent's blob. There is no parameter
    with which to ask for somebody else's.

    A 404 is first boot. Anything else raises :class:`KeyRecoveryFailed`:
    returning ``None`` on a transport error would generate a new identity every
    time the CP blipped.
    """
    url = f"{cp_url.rstrip('/')}/api/v1/orgs/{org_code}/agent-internal/keys"
    req = urllib.request.Request(url, headers=_agent_headers(credential, gateway_api_key), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:    # noqa: S310
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            logger.info("agt_sdk: nothing escrowed for org=%s — first boot", org_code)
            return None
        # This is the first call the credential makes, so it is where a bad one
        # surfaces — and "could not fetch the escrowed key" sends the operator to
        # check their passphrase when the credential is what is wrong. Three real
        # causes land here (revoked, unrecognised, unbound) and all three read as
        # an escrow problem unless said otherwise. Observed in the 2026-07-30 live
        # run against a real CP; the unit tests could not catch it because they
        # assert on control flow, not on who the message sends to.
        #
        # Still fatal, and still KeyRecoveryFailed: revoking a credential is how
        # an operator stops an agent, so falling back to AGT_AGENT_ID under
        # fail_mode=open would let a revoked agent keep running ungoverned. The
        # class's contract here is "fail_mode cannot reach this", which is exactly
        # what a revocation needs.
        if exc.code in (401, 403):
            raise KeyRecoveryFailed(
                f"agt_sdk: the control plane rejected AGT_AGENT_TOKEN (HTTP "
                f"{exc.code}): {_read_detail(exc)}. This is the credential, not "
                f"the passphrase — it has been revoked or rotated, or it is not "
                f"an agent credential at all (an operator or service token has no "
                f"binding row, and absence of a binding is a denial). Get a "
                f"current one from Register Agent, or rotate."
            ) from exc
        raise KeyRecoveryFailed(
            f"agt_sdk: could not fetch the escrowed key (HTTP {exc.code}): "
            f"{_read_detail(exc)}. Refusing to start with a new identity."
        ) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise KeyRecoveryFailed(
            f"agt_sdk: could not reach the control plane for key escrow ({exc}). "
            f"Refusing to start with a new identity; retry once it is reachable."
        ) from exc

    data = payload.get("data") or payload if isinstance(payload, dict) else {}
    blob = data.get("ciphertext_b64") if isinstance(data, dict) else None
    if not blob:
        # A 200 with no ciphertext is a contract violation, not an empty escrow.
        # Treating it as first boot would mint a new DID on a CP bug.
        raise KeyRecoveryFailed(
            "agt_sdk: the control plane returned an escrow record with no "
            "ciphertext. Refusing to start with a new identity."
        )
    return str(blob)


def _escrow_store(
    cp_url: str, backup: Any, private_key: Any, *,
    org_code: str, agent_name: str, credential: str, key_id: str,
    timeout: float, gateway_api_key: str,
) -> bool:
    """Store the ciphertext. **Fail-open** — never blocks the agent.

    A failed backup costs the *next* restart a new DID; a failed startup costs
    the agent entirely. The first is recoverable, so this warns and returns False
    rather than raising. That asymmetry is the opposite of :func:`_escrow_fetch`'s
    on purpose.
    """
    url = f"{cp_url.rstrip('/')}/api/v1/orgs/{org_code}/agent-internal/keys"
    try:
        body = {
            "name":           agent_name,
            "ciphertext_b64": backup.encrypt(private_key, org_code, agent_name),
            "key_id":         key_id,
            "kdf":            _kdf_label(),
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={**_agent_headers(credential, gateway_api_key),
                     "Content-Type": "application/json"},
            method="PUT",
        )
        with urllib.request.urlopen(req, timeout=timeout):            # noqa: S310
            pass
    except Exception as exc:                                          # noqa: BLE001
        detail = _read_detail(exc) if isinstance(exc, urllib.error.HTTPError) else str(exc)
        logger.warning(
            "agt_sdk: key escrow BACKUP FAILED for %s|%s (%s). The agent "
            "continues, but its next restart will mint a NEW DID unless this "
            "succeeds first.", org_code, agent_name, detail,
        )
        return False
    logger.info(
        "agt_sdk: key escrowed for %s|%s key_id=%s — this identity now survives "
        "a restart", org_code, agent_name, key_id,
    )
    return True


def _kdf_label() -> str:
    """The KDF label the CP records alongside the blob.

    Read from agent-mesh rather than restated, so a future KDF change cannot
    leave the SDK labelling new ciphertext with the old scheme.
    """
    try:
        from agentmesh.identity.key_backup import KDF_LABEL
        return str(KDF_LABEL)
    except ImportError:                                               # pragma: no cover
        return "hkdf-sha256-v1"


# ── Internal helpers ────────────────────────────────────────────────────────


def _gateway_header(gateway_api_key: str) -> dict[str, str]:
    """The PGAIAuthGateway key header, or ``{}`` for direct-CP deployments.

    Omitting it is how five mesh call sites once 401'd behind the gateway.
    """
    if not gateway_api_key:
        return {}
    from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
    return {GATEWAY_API_KEY_HEADER: gateway_api_key}


def _agent_headers(credential: str, gateway_api_key: str) -> dict[str, str]:
    return {
        "X-AGT-Token": credential,
        "Accept":      "application/json",
        **_gateway_header(gateway_api_key),
    }


def _post_json(
    url: str, body: dict, *, credential: str, timeout: float, gateway_api_key: str,
) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={**_agent_headers(credential, gateway_api_key),
                 "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:        # noqa: S310
        return json.loads(resp.read().decode("utf-8"))


def _read_detail(exc: Any) -> str:
    try:
        return exc.read().decode("utf-8", errors="replace")[:400]
    except Exception:
        return "<no body>"


def _parse_ts(raw: str) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def _public_jwk_and_did(private_key: Any) -> tuple[dict, str]:
    """Recompute the public JWK and DID from a recovered private key.

    Same derivation as :func:`_generate_keypair`, so a recovered key yields
    byte-identical values to the ones the CP first saw.
    """
    from cryptography.hazmat.primitives import serialization

    pub_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return (
        {"kty": "OKP", "crv": "Ed25519", "x": _b64url(pub_bytes)},
        "did:mesh:" + hashlib.sha256(pub_bytes).hexdigest()[:24],
    )


def _generate_keypair() -> tuple[Any, dict, str]:
    """Generate Ed25519 keypair and derive a ``did:mesh`` DID."""
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519
    except ImportError as exc:
        raise BootstrapError(
            "agt_sdk bootstrap requires the 'cryptography' package. "
            "Install with: pip install 'agt-sdk[bootstrap]'  "
            "or pip install cryptography>=42"
        ) from exc

    priv = ed25519.Ed25519PrivateKey.generate()
    pub_bytes = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pub_jwk = {"kty": "OKP", "crv": "Ed25519", "x": _b64url(pub_bytes)}
    did = "did:mesh:" + hashlib.sha256(pub_bytes).hexdigest()[:24]
    return priv, pub_jwk, did


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")
