# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Bootstrap-token consumer (IMPL-023 / IMPL-024 — Provenance Sponsor Model).

Purpose
-------
A bootstrap token is a single-use, short-lived credential issued by an
operator (or CI/CD pipeline) that carries the operator's ``sponsor_id``.
When the agent process starts, the SDK exchanges the bootstrap token for:

  * an Ed25519 keypair (generated locally; private key never leaves the process)
  * a ``did:mesh:<...>`` agent DID derived from the public key
  * a CP-signed *sponsorship credential* (JWT) that proves the agent was
    sponsored by the operator
  * a stable agent row UUID in the CP registry

After the exchange the SDK uses the returned DID as the agent identity for
all subsequent calls (register, heartbeat, decisions). Long-lived calls
continue to authenticate with ``AGT_CP_TOKEN`` (`X-AGT-Token` header).
The bootstrap token is **consumed** by the exchange — re-use returns
HTTP 401.

Environment
-----------
* ``AGT_BOOTSTRAP_TOKEN`` — when set, the SDK runs the exchange at startup.
* ``AGT_AGENT_TYPE`` — optional; recorded on the agent row.
* ``AGT_AGENT_SOURCE`` — optional; defaults to ``"agt_sdk"``.

Idempotence + restart
---------------------
Bootstrap tokens are single-use. On agent restart you have two choices:

  1. Issue a fresh bootstrap token (operator-driven provisioning).
  2. Capture the DID from the first run, then on subsequent runs unset
     ``AGT_BOOTSTRAP_TOKEN`` and set ``AGT_AGENT_ID=did:mesh:<...>``
     instead. The SDK uses the long-lived ``AGT_CP_TOKEN`` for ongoing
     calls — no further bootstrap needed.

If ``AGT_BOOTSTRAP_TOKEN`` is left set on a restart and the token has
already been consumed, the SDK logs a warning and falls back to the
env-derived identity (``AGT_AGENT_ID`` or hostname-script default).

Dependencies
------------
This module imports ``cryptography`` lazily — if it is not installed,
calling :func:`exchange` raises :class:`BootstrapError` with a clear
install hint. Customers who do not use bootstrap tokens do not need
``cryptography``.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ._paths import api_v1_url

logger = logging.getLogger("agt_sdk.bootstrap")


# ── Result + errors ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class BootstrapResult:
    """Outcome of a successful bootstrap-token exchange.

    Attributes:
        did:                    Agent DID, e.g. ``did:mesh:abc123…``.
        public_key_jwk:         The agent's public key as an Ed25519 JWK.
        sponsorship_credential: CP-signed JWT proving sponsorship. Carries
                                ``sponsor_id`` in the payload (currently
                                dormant — IMPL-026 will enforce on the
                                trust-engine side).
        cp_root_did:            DID of the CP that signed the credential.
        credential_expires_at:  Parsed credential expiry timestamp (or
                                ``None`` if the CP didn't supply one).
        agent_id:               UUID of the upserted agent row in CP.
    """
    did: str
    public_key_jwk: dict
    sponsorship_credential: str
    cp_root_did: str
    credential_expires_at: datetime | None
    agent_id: str
    # IMPL-024.5 — scoped API token minted by the CP on bootstrap consume.
    # When present, the SDK uses this as its cp_token for the rest of the
    # process (register / heartbeat / decision-ingest), so agents need only
    # one operator-issued credential (AGT_BOOTSTRAP_TOKEN). None on older
    # CPs that haven't shipped the IMPL-024.5 backend yet.
    api_token: str | None = None
    api_token_expires_at: datetime | None = None

    # IMPL-045 — org slug echoed back by the CP. When present, the SDK adopts
    # it as ``cfg.org_code`` for the rest of the process so subsequent
    # heartbeat / ingest / policy-bundle calls address the right tenant URL
    # without the operator needing to also set ``AGT_ORG_CODE``. ``None`` on
    # older CPs that haven't shipped the IMPL-045 backend yet.
    organization_slug: str | None = None

    # IMPL-024.5 + IMPL-032.5 — the Ed25519 private key generated for this
    # exchange. Kept on the result (in-process only, never serialized) so
    # ``Lifecycle._maybe_wire_mesh`` can construct an ``AgentIdentity``
    # bound to the *same* DID the CP registered, instead of generating a
    # fresh one whose DID the CP doesn't know.
    #
    # ``repr=False`` keeps the key out of dataclass logging; ``compare=False``
    # excludes it from equality so two BootstrapResults with otherwise
    # identical fields compare equal regardless of the key object.
    # Typed as ``Any`` to avoid hard-importing ``cryptography`` at module load.
    private_key: Any = field(default=None, repr=False, compare=False)

    def decoded_credential(self) -> dict:
        """Decode the credential JWT payload (no signature check — logs only)."""
        parts = self.sponsorship_credential.split(".")
        if len(parts) != 3:
            return {}
        try:
            pad = "=" * (-len(parts[1]) % 4)
            return json.loads(base64.urlsafe_b64decode(parts[1] + pad))
        except Exception:
            return {}


class BootstrapError(Exception):
    """Bootstrap exchange failed for a non-recoverable reason."""


class BootstrapAlreadyConsumed(BootstrapError):
    """The bootstrap token has already been consumed by a previous run.

    Common on agent restart when ``AGT_BOOTSTRAP_TOKEN`` was left in the
    environment. The SDK catches this and falls back to env-derived
    identity, so it is not fatal.
    """


# ── Public API ───────────────────────────────────────────────────────────────


def exchange(
    cp_url: str,
    bootstrap_token: str,
    *,
    name: str = "",
    agent_type: str = "",
    source: str = "agt_sdk",
    capabilities: list[str] | None = None,
    description: str = "",
    timeout: float = 10.0,
    org_code: str = "",
    gateway_api_key: str = "",
) -> BootstrapResult:
    """Exchange a bootstrap token for an agent identity + sponsorship credential.

    Single-use: a successful exchange consumes the token. Re-using the
    same token raises :class:`BootstrapAlreadyConsumed`.

    Args:
        cp_url:           Control plane base URL.
        bootstrap_token:  Operator-issued bootstrap token (sent in the
                          ``X-AGT-Bootstrap-Token`` header).
        name:             Display name for the agent row (optional).
        agent_type:       Overrides the type recorded on the bootstrap
                          token (optional).
        source:           Registration source label. Defaults to
                          ``"agt_sdk"``.
        capabilities:     IMPL-036 — list of capability strings (recommended
                          form ``verb:resource``; no regex enforced). Empty
                          or None values are not sent.
        description:      IMPL-036 — human-readable agent description shown
                          on the dashboard.
        timeout:          HTTP timeout in seconds.
        org_code:         REQUIRED (IMPL-060). The CP bootstrap consume is
                          org-scoped: ``POST /api/v1/orgs/{org_code}/agents/bootstrap``.
                          The bootstrap token stays the credential and remains the
                          single source of tenancy — ``org_code`` is routing
                          metadata that lets the call ride an auth gateway
                          forwarding only ``/api/v1/orgs/**``, and the CP validates
                          it against the token's own org (403 on mismatch). Raises
                          :class:`BootstrapError` if empty. The CP still echoes the
                          agent's org_slug via ``BootstrapConsumeOut.organization_slug``;
                          ``_lifecycle._maybe_run_bootstrap`` adopts it into
                          ``SdkConfig.org_code`` for all subsequent org-scoped calls.

    Returns:
        :class:`BootstrapResult` with the resolved DID, sponsorship
        credential, and agent row UUID.

    Raises:
        BootstrapAlreadyConsumed: Token has already been consumed.
        BootstrapError:           Network / non-401 error, or the
                                  ``cryptography`` package is missing.
    """
    private_key, public_jwk, did = _generate_keypair()

    body: dict[str, Any] = {"did": did, "public_key": public_jwk}
    if name:
        body["name"] = name
    if agent_type:
        body["agent_type"] = agent_type
    if source:
        body["source"] = source
    if capabilities:
        body["capabilities"] = capabilities
    if description:
        body["description"] = description

    # IMPL-060 — bootstrap CONSUME is org-scoped on the CP
    # (``POST /api/v1/orgs/{org_code}/agents/bootstrap``). ``org_code`` is
    # required: the operator who minted the token knows the org, and it is
    # supplied via ``AGT_ORG_CODE``. Org-scoping lets the call ride an auth
    # gateway that forwards only ``/api/v1/orgs/**``; the bootstrap token is
    # carried in the gateway-forwarded ``X-AGT-Bootstrap-Token`` header, NOT in
    # ``Authorization`` (which such gateways validate as a platform JWT and
    # reject). The token stays the credential; ``{org_code}`` is routing
    # metadata, validated against the token's own org in-handler.
    if not org_code:
        raise BootstrapError(
            "agt_sdk: AGT_ORG_CODE is required to consume a bootstrap token "
            "(the CP bootstrap endpoint is org-scoped: "
            "POST /api/v1/orgs/{org_code}/agents/bootstrap)."
        )
    url = f"{cp_url.rstrip('/')}/api/v1/orgs/{org_code}/agents/bootstrap"
    headers = {
        "X-AGT-Bootstrap-Token": bootstrap_token,
        "Content-Type":          "application/json",
        "Accept":                "application/json",
    }
    # PGAIAuthGateway header — when the deployment routes the SDK through
    # the gateway, every outbound request must carry this key. Empty when
    # the SDK talks to the CP directly.
    if gateway_api_key:
        from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
        headers[GATEWAY_API_KEY_HEADER] = gateway_api_key
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:    # noqa: S310
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", errors="replace")[:400]
        except Exception:
            detail = "<no body>"
        if exc.code == 401:
            raise BootstrapAlreadyConsumed(
                f"Bootstrap token rejected (HTTP 401): {detail}"
            ) from exc
        raise BootstrapError(
            f"Bootstrap exchange failed (HTTP {exc.code}): {detail}"
        ) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise BootstrapError(f"Bootstrap exchange failed: {exc}") from exc

    data = payload.get("data", {}) if isinstance(payload, dict) else {}
    cred = data.get("sponsorship_credential", "")
    cp_root = data.get("cp_root_did", "")
    expires_raw = data.get("expires_at", "") or ""
    agent_id = data.get("agent_id", "")
    # IMPL-024.5 — optional scoped api_token for the single-credential flow.
    api_token = data.get("api_token") or None
    api_token_expires_raw = data.get("api_token_expires_at", "") or ""
    # IMPL-045 — CP echoes back the org slug. Accept either key name to be
    # forgiving across versions; None on pre-IMPL-045 CPs.
    organization_slug = (
        data.get("organization_slug")
        or data.get("org_code")
        or None
    )

    expires_at: datetime | None = None
    if expires_raw:
        try:
            expires_at = datetime.fromisoformat(expires_raw.replace("Z", "+00:00"))
        except ValueError:
            expires_at = None

    api_token_expires_at: datetime | None = None
    if api_token_expires_raw:
        try:
            api_token_expires_at = datetime.fromisoformat(
                api_token_expires_raw.replace("Z", "+00:00")
            )
        except ValueError:
            api_token_expires_at = None

    return BootstrapResult(
        did=did,
        public_key_jwk=public_jwk,
        sponsorship_credential=cred,
        cp_root_did=cp_root,
        credential_expires_at=expires_at,
        agent_id=agent_id,
        api_token=api_token,
        api_token_expires_at=api_token_expires_at,
        organization_slug=organization_slug,
        # In-process only: handed off to AgentIdentity for local crypto.
        # Never serialized, never sent to CP. CP got the public half above.
        private_key=private_key,
    )


# ── Internal helpers ────────────────────────────────────────────────────────


def _generate_keypair() -> tuple[Any, dict, str]:
    """Generate Ed25519 keypair and derive a ``did:mesh`` DID."""
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519
    except ImportError as exc:
        raise BootstrapError(
            "agt_sdk bootstrap requires the 'cryptography' package. "
            "Install with: pip install 'agt-sdk[bootstrap]'  "
            "or pip install cryptography>=42"
        ) from exc

    priv = ed25519.Ed25519PrivateKey.generate()
    pub_bytes = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    pub_jwk = {"kty": "OKP", "crv": "Ed25519", "x": _b64url(pub_bytes)}
    did = "did:mesh:" + hashlib.sha256(pub_bytes).hexdigest()[:24]
    return priv, pub_jwk, did


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")
