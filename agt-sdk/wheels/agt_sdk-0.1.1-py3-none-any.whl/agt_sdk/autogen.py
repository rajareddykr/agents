# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""AutoGen adapter.

Supports both AutoGen surfaces a customer might be using:

* **AutoGen 0.2** (`pyautogen`)
  - Tools are registered via ``register_function`` and stored as plain
    callables in ``agent._function_map``. We wrap each callable.

* **AutoGen 0.4 / agentchat** (newer ``autogen-core`` + ``autogen-agentchat``)
  - Tools are objects with ``run_json`` / ``run`` async methods (or
    plain functions wrapped by ``FunctionTool``). We wrap those methods.

One-line integration:

    from agt_sdk.autogen import wrap

    wrap(my_agent)            # AutoGen 0.2 ConversableAgent / AssistantAgent
    wrap(my_tool)             # single AutoGen 0.4 BaseTool / FunctionTool
    wrap([t1, t2])            # bare tool list

Idempotent. Returns the input unchanged when ``AGT_GOVERNANCE_ENABLED=false``
or when no ``AGT_CP_URL`` is set.

Note: ``governed`` is the deprecated alias for ``wrap`` (renamed in
IMPL-035 cleanup 4). Both work identically in this release; the old
name emits ``DeprecationWarning`` and will be removed in v0.3.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
from typing import Any

from agt_sdk._async import run_async as _run_async
from agt_sdk._kernel import AutoKernel


# ── Public API ───────────────────────────────────────────────────────────────


def wrap(obj: Any) -> Any:
    """Wrap an AutoGen agent or tool so every tool invocation is governed.

    Args:
        obj: An AutoGen 0.2 ``ConversableAgent`` (or any object with a
            ``_function_map`` dict), an AutoGen 0.4 tool (with ``run_json``
            or ``run``), or a list/tuple of either.

    Returns:
        The same ``obj`` (modified in place when governance is enabled).
    """
    kernel = AutoKernel.instance()
    if not kernel.enabled:
        return obj

    # List/tuple of agents or tools
    if isinstance(obj, (list, tuple)):
        for item in obj:
            wrap(item)
        return obj

    # AutoGen 0.2 — ConversableAgent has _function_map
    fn_map = getattr(obj, "_function_map", None)
    if isinstance(fn_map, dict):
        _wrap_function_map(fn_map, kernel)

    # AutoGen 0.4 — agent has a tools attribute
    tools = getattr(obj, "tools", None)
    if isinstance(tools, (list, tuple)):
        for t in tools:
            _wrap_autogen_tool(t, kernel)

    # Single AutoGen 0.4 tool
    if hasattr(obj, "run_json") or (hasattr(obj, "run") and not fn_map and not tools):
        _wrap_autogen_tool(obj, kernel)

    return obj


def governed(obj: Any) -> Any:
    """Deprecated alias for :func:`wrap`. Will be removed in v0.3."""
    import warnings
    warnings.warn(
        "agt_sdk.autogen.governed is renamed to agt_sdk.autogen.wrap. "
        "The old name will be removed in v0.3.",
        DeprecationWarning,
        stacklevel=2,
    )
    return wrap(obj)


# ── Internal — wrapping helpers ─────────────────────────────────────────────


def _wrap_function_map(fn_map: dict[str, Any], kernel: AutoKernel) -> None:
    """Wrap each callable in an AutoGen 0.2 ``_function_map`` dict in place."""
    for name in list(fn_map.keys()):
        orig = fn_map[name]
        if not callable(orig) or getattr(orig, "_agt_wrapped", False):
            continue
        fn_map[name] = _wrap_callable(name, orig, kernel)


def _wrap_callable(name: str, fn: Any, kernel: AutoKernel) -> Any:
    """Return a governance-checking wrapper around *fn* (sync or async)."""
    is_coro = asyncio.iscoroutinefunction(fn)
    sig = None
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        pass

    def _build_args(args: tuple, kwargs: dict) -> dict:
        if sig is None:
            out = dict(kwargs)
            if args:
                out["_positional"] = list(args)
            return out
        try:
            bound = sig.bind_partial(*args, **kwargs)
            return dict(bound.arguments)
        except TypeError:
            out = dict(kwargs)
            if args:
                out["_positional"] = list(args)
            return out

    if is_coro:
        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            res = await kernel.check(name, _build_args(args, kwargs))
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return await fn(*args, **kwargs)
        async_wrapper._agt_wrapped = True       # type: ignore[attr-defined]
        return async_wrapper

    @functools.wraps(fn)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        res = _run_async(kernel.check(name, _build_args(args, kwargs)))
        if not res.allowed:
            return f"[BLOCKED by AGT governance]: {res.reason}"
        return fn(*args, **kwargs)
    sync_wrapper._agt_wrapped = True            # type: ignore[attr-defined]
    return sync_wrapper


def _wrap_autogen_tool(tool: Any, kernel: AutoKernel) -> None:
    """Wrap an AutoGen 0.4 tool's ``run_json`` / ``run`` async methods."""
    if getattr(tool, "_agt_wrapped", False):
        return

    name = getattr(tool, "name", None) or tool.__class__.__name__

    orig_run_json = getattr(tool, "run_json", None)
    orig_run = getattr(tool, "run", None)

    def _args_dict(args: Any) -> dict:
        if isinstance(args, dict):
            return args
        if isinstance(args, str):
            try:
                import json
                parsed = json.loads(args)
                return parsed if isinstance(parsed, dict) else {"_raw": args}
            except Exception:
                return {"_raw": args}
        return {"_args": args}

    if callable(orig_run_json):
        async def wrapped_run_json(args: Any, *rest: Any, **kwargs: Any) -> Any:
            res = await kernel.check(name, _args_dict(args))
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return await orig_run_json(args, *rest, **kwargs)
        try:
            tool.run_json = wrapped_run_json    # type: ignore[attr-defined]
        except Exception:
            pass

    if callable(orig_run) and not callable(orig_run_json):
        if asyncio.iscoroutinefunction(orig_run):
            async def wrapped_run_async(*args: Any, **kwargs: Any) -> Any:
                first_arg = args[0] if args else kwargs
                res = await kernel.check(name, _args_dict(first_arg))
                if not res.allowed:
                    return f"[BLOCKED by AGT governance]: {res.reason}"
                return await orig_run(*args, **kwargs)
            try:
                tool.run = wrapped_run_async    # type: ignore[attr-defined]
            except Exception:
                pass
        else:
            def wrapped_run_sync(*args: Any, **kwargs: Any) -> Any:
                first_arg = args[0] if args else kwargs
                res = _run_async(kernel.check(name, _args_dict(first_arg)))
                if not res.allowed:
                    return f"[BLOCKED by AGT governance]: {res.reason}"
                return orig_run(*args, **kwargs)
            try:
                tool.run = wrapped_run_sync     # type: ignore[attr-defined]
            except Exception:
                pass

    try:
        tool._agt_wrapped = True                # type: ignore[attr-defined]
    except Exception:
        pass
