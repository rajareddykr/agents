# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Local safety baseline.

A hardcoded set of always-block rules that apply even when the control plane
is unreachable. This is the SDK's "fail-open but not fail-blind" behaviour:
when the policy bundle can't be fetched, we still refuse to run obviously
dangerous tool names.

Customer can disable via ``AGT_LOCAL_SAFETY_BASELINE=off``.

The baseline matches *tool names*, not arbitrary content. A customer who
genuinely needs a ``delete_file`` tool can:

  1. Disable the baseline (``AGT_LOCAL_SAFETY_BASELINE=off``), or
  2. Rename the tool (e.g. ``purge_record``), or
  3. Define a CP-side policy that explicitly allow-lists their tool.
"""

from __future__ import annotations

# Tool names that are blocked by the local baseline.
# Lowercase comparison; matched against the tool name reported by the framework.
BASELINE_BLOCKED_TOOLS: frozenset[str] = frozenset({
    "delete_file",
    "shell_exec",
    "run_command",
    "bash",
    "sh",
    "eval",
    "exec",
    "system",
    "subprocess_run",
    "os_system",
})

# Pattern fragments (case-insensitive substring) that block any tool whose
# input contains them. These are deliberately conservative — only patterns
# that have no benign use in normal agent traffic.
BASELINE_BLOCKED_PATTERNS: tuple[str, ...] = (
    "rm -rf /",
    "drop database",
    "drop table",
    ":(){:|:&};:",   # fork bomb
)


def baseline_check(tool_name: str, tool_args_repr: str) -> tuple[bool, str | None]:
    """Run the local safety baseline.

    Args:
        tool_name:       Tool name as reported by the framework.
        tool_args_repr:  ``str`` or ``json.dumps(...)`` of the tool arguments.

    Returns:
        ``(allowed, reason)`` — ``allowed=False`` means block.
    """
    name = (tool_name or "").strip().lower()
    if name in BASELINE_BLOCKED_TOOLS:
        return False, (
            f"Tool '{tool_name}' is blocked by the SDK local safety baseline. "
            "Disable with AGT_LOCAL_SAFETY_BASELINE=off or rename the tool."
        )

    args_lower = (tool_args_repr or "").lower()
    for pat in BASELINE_BLOCKED_PATTERNS:
        if pat in args_lower:
            return False, (
                f"Pattern '{pat}' detected in arguments to '{tool_name}' — "
                "blocked by the SDK local safety baseline."
            )

    return True, None
