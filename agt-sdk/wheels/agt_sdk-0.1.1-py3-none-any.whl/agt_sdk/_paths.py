# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""URL composition for SDK → CP requests (IMPL-045).

Every SDK module that builds a control-plane URL routes through
``api_v1_url`` here. When ``org_code`` is set (``AGT_ORG_CODE`` env or
restamped from the bootstrap response), paths come out as
``{base}/api/v1/orgs/{org_code}{suffix}``. When it's empty we keep the
legacy ``{base}/api/v1{suffix}`` form and emit a one-time warning — the
CP answers those with a 307 to the org-scoped path during the grace
window, but redirect-following is not portable across our two HTTP
clients (urllib follows 307; ``httpx.AsyncClient`` does not by default),
so direct composition is the supported mode.
"""

from __future__ import annotations

import logging
import re
import threading

logger = logging.getLogger("agt_sdk.paths")

# CP org slugs are validated server-side; mirror the basic shape here so
# a bogus AGT_ORG_CODE produces a clear log instead of a silent 404.
# DNS-label rules: lowercase alphanumerics + dashes, no leading/trailing
# dash, max 63 characters.
_SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")

_warned_lock = threading.Lock()
_warned: set[str] = set()


def _warn_once(key: str, message: str) -> None:
    with _warned_lock:
        if key in _warned:
            return
        _warned.add(key)
    logger.warning(message)


def is_valid_org_code(org_code: str) -> bool:
    """Cheap shape check for an org slug. Empty string is *not* valid."""
    return bool(org_code) and bool(_SLUG_RE.match(org_code))


def api_v1_url(base_url: str, suffix: str, org_code: str) -> str:
    """Compose a fully-qualified CP URL for the v1 API.

    Args:
        base_url:  Control-plane base, e.g. ``https://cp.example.com``.
        suffix:    Path **below** ``/api/v1`` — must start with ``/``,
                   e.g. ``/agents/bootstrap`` or ``/policies/bundle``.
        org_code:  Org slug. When non-empty and well-formed the path is
                   org-scoped; otherwise the legacy unscoped form is
                   returned (with a one-time warning).

    Returns:
        ``{base}/api/v1[/orgs/{org_code}]{suffix}``.
    """
    if not suffix.startswith("/"):
        raise ValueError(f"suffix must start with '/': {suffix!r}")

    base = base_url.rstrip("/")
    if org_code:
        if not is_valid_org_code(org_code):
            _warn_once(
                f"badcode:{org_code}",
                f"agt_sdk: AGT_ORG_CODE={org_code!r} is not a valid org slug "
                "(expected lowercase alphanumerics + dashes); falling back to "
                "legacy unscoped /api/v1 paths.",
            )
        else:
            return f"{base}/api/v1/orgs/{org_code}{suffix}"

    _warn_once(
        f"unscoped:{suffix}",
        "agt_sdk: AGT_ORG_CODE is not set; using legacy /api/v1 paths and "
        "relying on the CP's 307 grace redirect. Set AGT_ORG_CODE to your "
        "org slug to address the org-scoped endpoint directly.",
    )
    return f"{base}/api/v1{suffix}"


def _reset_warnings_for_tests() -> None:
    """Test-only: clear the one-time warning memo so tests can re-trigger."""
    with _warned_lock:
        _warned.clear()
