# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""OpenAI Agents SDK adapter.

Targets the official ``openai-agents`` Python package
(https://openai.github.io/openai-agents-python/), which uses
``@function_tool``-decorated callables exposed as ``FunctionTool``
objects with an async ``on_invoke_tool(ctx, args_json) -> str`` entry
point.

One-line integration:

    from agt_sdk.openai_agents import wrap

    wrap(my_agent)            # Agent — wraps every tool in agent.tools
    wrap(my_tool)             # FunctionTool — wraps in place
    wrap([t1, t2])            # list of tools

Idempotent. Returns the input unchanged when ``AGT_GOVERNANCE_ENABLED=false``
or when no ``AGT_CP_URL`` is set.

The wrapper preserves the SDK's contract: blocked calls return a string
to the LLM (`"[BLOCKED by AGT governance]: ..."`) rather than raising,
so the agent loop can react in-prompt.

Note: ``governed`` is the deprecated alias for ``wrap`` (renamed in
IMPL-035 cleanup 4). Both work identically in this release; the old
name emits ``DeprecationWarning`` and will be removed in v0.3.
"""

from __future__ import annotations

import json
from typing import Any

from agt_sdk._kernel import AutoKernel


# ── Public API ───────────────────────────────────────────────────────────────


def wrap(obj: Any) -> Any:
    """Wrap an OpenAI Agents SDK ``Agent`` or ``FunctionTool``.

    Walks ``agent.tools`` and replaces each tool's ``on_invoke_tool``
    callable with a governance-checking version. Idempotent.

    Args:
        obj: An OpenAI ``Agent``, a ``FunctionTool``, or a list/tuple of tools.

    Returns:
        The same ``obj`` (modified in place when governance is enabled).
    """
    kernel = AutoKernel.instance()
    if not kernel.enabled:
        return obj

    # List/tuple of tools
    if isinstance(obj, (list, tuple)):
        for t in obj:
            _wrap_tool_inplace(t, kernel)
        return obj

    # Agent: walk its tools
    tools = getattr(obj, "tools", None)
    if isinstance(tools, (list, tuple)):
        for t in tools:
            _wrap_tool_inplace(t, kernel)
        return obj

    # Single tool object
    if hasattr(obj, "on_invoke_tool"):
        _wrap_tool_inplace(obj, kernel)

    return obj


def governed(obj: Any) -> Any:
    """Deprecated alias for :func:`wrap`. Will be removed in v0.3."""
    import warnings
    warnings.warn(
        "agt_sdk.openai_agents.governed is renamed to agt_sdk.openai_agents.wrap. "
        "The old name will be removed in v0.3.",
        DeprecationWarning,
        stacklevel=2,
    )
    return wrap(obj)


# ── Internal — wrap a FunctionTool's on_invoke_tool ─────────────────────────


def _wrap_tool_inplace(tool: Any, kernel: AutoKernel) -> None:
    """Replace ``tool.on_invoke_tool`` with a governance-checking wrapper.

    The OpenAI Agents SDK contract is::

        async on_invoke_tool(context_wrapper, arguments_json: str) -> str

    The arguments are a JSON string serialised from the LLM's tool-call
    arguments. We parse them, run the governance check, and either
    pass through to the original callable or return a block string.
    """
    if getattr(tool, "_agt_wrapped", False):
        return

    name = getattr(tool, "name", None) or tool.__class__.__name__
    orig = getattr(tool, "on_invoke_tool", None)
    if not callable(orig):
        return

    async def wrapped(ctx: Any, args: Any = "") -> str:
        # args is typically a JSON string per the SDK contract, but be defensive.
        if isinstance(args, str):
            try:
                parsed = json.loads(args) if args else {}
                tool_args = parsed if isinstance(parsed, dict) else {"_raw": args}
            except Exception:
                tool_args = {"_raw": args}
        elif isinstance(args, dict):
            tool_args = args
        else:
            tool_args = {"_args": args}

        res = await kernel.check(name, tool_args)
        if not res.allowed:
            return f"[BLOCKED by AGT governance]: {res.reason}"
        return await orig(ctx, args)

    try:
        tool.on_invoke_tool = wrapped               # type: ignore[attr-defined]
    except Exception:
        try:
            object.__setattr__(tool, "on_invoke_tool", wrapped)
        except Exception:
            return

    try:
        tool._agt_wrapped = True                    # type: ignore[attr-defined]
    except Exception:
        try:
            object.__setattr__(tool, "_agt_wrapped", True)
        except Exception:
            pass
