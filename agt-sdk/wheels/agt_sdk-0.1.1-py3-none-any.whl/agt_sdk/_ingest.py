# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""SDK-internal decision push to the control-plane.

Posts to ``{cp_url}/api/v1/governance/decisions/ingest`` (the canonical
SDK→CP decision-ingest endpoint, IMPL-001 / IMPL-004) using the
``X-AGT-Token`` header.

Note on naming: this module is **not** the same as
``agent_os.audit.http_sink.HTTPDecisionSink`` (upstream, parameterized
by IMPL-035 cleanup 3). That class targets the agentmesh
audit-collector at ``/api/v1/audit/log`` with the event-wrapped
``{event_type, agent_did, data}`` shape. The CP decision-ingest
endpoint expects a *flat* schema (``agent_id``, ``policy_id``,
``trust_impact``, ``context_snapshot``, …) — see
``app/schemas/governance.py:DecisionIngest``. The two are distinct
SDK→consumer paths with different wire shapes, so they don't collapse
into one class.

Internals (IMPL-035 cleanup 2 — modernized 2026-05-14):
- urllib + ``threading.Thread`` → ``httpx.AsyncClient`` + ``asyncio.Task``
  inside a single owned event-loop thread.
- Public API (``start`` / ``stop`` / ``record`` / ``flush``) is sync and
  unchanged — the kernel's ``_record(...)`` is the sole caller and
  cannot be made async without an SDK ergonomics break.
- One background thread (was: one). Connection pooling courtesy of
  ``httpx.AsyncClient``.
- ``record(...)`` schedules a put onto the loop's ``asyncio.Queue`` via
  ``asyncio.run_coroutine_threadsafe``; full queue silently drops the
  oldest entry. Same best-effort semantics as before.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Any

import httpx

from ._paths import api_v1_url

logger = logging.getLogger("agt_sdk.ingest")


class DecisionIngest:
    """Background-thread decision pusher.

    Posts to ``{cp_url}/api/v1/orgs/{org_code}/governance/decisions/ingest``
    (or the legacy unscoped path when no org code is set — CP grace
    307-redirects, but httpx won't follow without ``follow_redirects=True``,
    so set ``AGT_ORG_CODE`` for direct addressing). Uses ``X-AGT-Token``.
    """

    def __init__(
        self,
        cp_url: str,
        cp_token: str,
        agent_id: str,
        agent_name: str,
        max_queue: int = 2000,
        org_code: str = "",
        gateway_api_key: str = "",
    ) -> None:
        self._url = api_v1_url(cp_url, "/governance/decisions/ingest", org_code)
        self._headers = {
            "X-AGT-Token":  cp_token,
            "Content-Type": "application/json",
            "Accept":       "application/json",
        }
        # PGAIAuthGateway header — API key. Uses the single source of truth
        # so _ingest stays in sync with the other outbound call sites. Set on
        # the long-lived ``httpx.AsyncClient`` default headers so every queued
        # decision push carries it.
        if gateway_api_key:
            from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
            self._headers[GATEWAY_API_KEY_HEADER] = gateway_api_key
        self._agent_id = agent_id
        self._agent_name = agent_name
        self._max_queue = max_queue

        # Owned event loop + the thread that runs it. Created in `start()`.
        self._loop: asyncio.AbstractEventLoop | None = None
        self._queue: asyncio.Queue[dict[str, Any]] | None = None
        self._thread: threading.Thread | None = None
        self._stop_event: threading.Event = threading.Event()
        self._ready_event: threading.Event = threading.Event()
        self._client: httpx.AsyncClient | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._loop_runner,
            daemon=True,
            name=f"agt-sdk-ingest-{self._agent_id}",
        )
        self._thread.start()
        # Block briefly until the loop + queue + client are ready so callers
        # can immediately call record() without racing.
        self._ready_event.wait(timeout=5.0)
        logger.debug("decision ingest started for %s", self._agent_id)

    def stop(self) -> None:
        self._stop_event.set()
        loop = self._loop
        if loop is not None and loop.is_running():
            loop.call_soon_threadsafe(loop.stop)

    # ── Sync API (called from sync kernel._record) ─────────────────────────

    def record(
        self,
        action: str,
        outcome: str,
        reason: str = "",
        matched_rule: str | None = None,
        policy_name: str | None = None,
        latency_ms: float = 0.0,
        context_snapshot: dict[str, Any] | None = None,
    ) -> None:
        """Enqueue a decision. Never blocks. Drops oldest on overflow."""
        payload = {
            "agent_id":     self._agent_id,
            "agent_name":   self._agent_name,
            "action":       action,
            "outcome":      outcome,                 # allow | block | audit | deny
            "policy_id":    "pol-default",
            "policy_name":  policy_name or "default",
            "matched_rule": matched_rule,
            "reason":       reason,
            "latency_ms":   latency_ms,
            "adapter":      "agt-sdk",
            "context_snapshot": context_snapshot or {},
        }
        loop, q = self._loop, self._queue
        if loop is None or q is None:
            return  # not started yet
        # Threadsafe enqueue. If full, drop oldest first.
        def _put() -> None:
            assert q is not None
            try:
                q.put_nowait(payload)
            except asyncio.QueueFull:
                try:
                    q.get_nowait()
                    q.put_nowait(payload)
                except Exception:
                    pass
        loop.call_soon_threadsafe(_put)

    def flush(self, timeout_seconds: float = 5.0) -> int:
        """Synchronously drain any queued decisions. Returns count flushed.

        Called from atexit so the process doesn't exit faster than the
        background drain can run.
        """
        loop = self._loop
        if loop is None or self._queue is None or self._client is None:
            return 0
        fut = asyncio.run_coroutine_threadsafe(self._flush_now(), loop)
        try:
            return fut.result(timeout=timeout_seconds)
        except Exception:
            return 0

    # ── Background loop ────────────────────────────────────────────────────

    def _loop_runner(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._main())
        finally:
            try:
                self._loop.close()
            except Exception:
                pass

    async def _main(self) -> None:
        self._queue = asyncio.Queue(maxsize=self._max_queue)
        async with httpx.AsyncClient(timeout=3.0, headers=self._headers) as client:
            self._client = client
            self._ready_event.set()
            # Drain loop: pull from queue, post.
            while not self._stop_event.is_set():
                try:
                    payload = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                await self._post(payload)

    async def _post(self, payload: dict[str, Any]) -> None:
        if self._client is None:
            return
        try:
            r = await self._client.post(self._url, json=payload)
            logger.debug(
                "decision posted %s/%s -> %s",
                payload.get("action"), payload.get("outcome"), r.status_code,
            )
        except httpx.HTTPError as exc:
            logger.debug("decision post failed %s: %s", payload.get("action"), exc)
        except Exception as exc:    # pragma: no cover - defensive
            logger.debug("decision post unexpected %s: %s", payload.get("action"), exc)

    async def _flush_now(self) -> int:
        """Drain everything currently in the queue, POSTing each item."""
        if self._queue is None:
            return 0
        count = 0
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            try:
                payload = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            await self._post(payload)
            count += 1
        return count
