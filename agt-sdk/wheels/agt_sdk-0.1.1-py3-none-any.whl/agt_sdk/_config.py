# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Configuration loader.

Reads SDK env vars exactly once on import and exposes them as a frozen
``SdkConfig`` dataclass. All other modules in the SDK read configuration
from here; nothing else touches ``os.environ``.

Defaults are chosen so that:

  * Setting only ``AGT_CP_URL`` and ``AGT_CP_TOKEN`` works for single-host
    deployments — policy server and audit collector both default to
    ``AGT_CP_URL``.
  * Setting all three URLs works for split deployments without code change.
  * Missing ``AGT_CP_URL`` puts the SDK into pass-through (no-op) mode —
    same code runs in dev (no governance) and prod (governance on).
"""

from __future__ import annotations

import logging
import os
import socket
import sys
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("agt_sdk.config")


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        logger.warning("env var %s=%r is not an integer; falling back to %d", name, raw, default)
        return default


def _default_agent_id() -> str:
    """Stable, readable agent_id when AGT_AGENT_ID is not set.

    Format: ``<hostname>-<script-basename>``. Falls back to a UUID if either
    component is unavailable.
    """
    try:
        hostname = socket.gethostname() or "unknown-host"
    except Exception:
        hostname = "unknown-host"

    script = ""
    try:
        argv0 = sys.argv[0] if sys.argv else ""
        if argv0:
            script = Path(argv0).stem
    except Exception:
        pass

    if not script:
        import uuid
        return f"{hostname}-{uuid.uuid4().hex[:8]}"
    return f"{hostname}-{script}"


@dataclass(frozen=True)
class SdkConfig:
    """Frozen snapshot of SDK configuration. Built once via ``from_env()``."""

    enabled: bool                      # AGT_GOVERNANCE_ENABLED & AGT_CP_URL set
    cp_url: str
    cp_token: str
    policy_server_url: str
    audit_url: str
    agent_id: str
    agent_name: str
    agent_description: str
    capabilities: tuple[str, ...]      # IMPL-036 — AGT_AGENT_CAPABILITIES (comma-separated). Tuple to keep dataclass frozen-hashable.
    agent_type: str                    # propagated to bootstrap exchange
    agent_source: str                  # registration source label
    bootstrap_token: str               # AGT_BOOTSTRAP_TOKEN — single-use
    fail_mode: str                     # "open" | "closed"
    heartbeat_seconds: int             # 0 = disabled
    policy_refresh_seconds: int
    injection_scanner: bool
    local_safety_baseline: bool
    log_level: str
    extra: dict[str, str] = field(default_factory=dict)
    # IMPL-045 — placed last with a default so callers that pre-date the field
    # (e.g. ``test_mesh_auto_wire`` constructing ``SdkConfig`` directly) keep
    # working without an explicit ``org_code=``. ``from_env`` always supplies
    # it via the ``AGT_ORG_CODE`` env var.
    org_code: str = ""
    # PGAIAuthGateway integration — when set, the SDK adds an
    # ``X-appsoc-api-key`` header to every outbound HTTP request so the
    # gateway will let the request through to the control plane. Defaults
    # to empty so direct (non-gatewayed) deployments are unaffected.
    gateway_api_key: str = ""

    @classmethod
    def from_env(cls) -> "SdkConfig":
        cp_url = os.environ.get("AGT_CP_URL", "").rstrip("/").strip()
        cp_token = os.environ.get("AGT_CP_TOKEN", "").strip()
        bootstrap_token_check = os.environ.get("AGT_BOOTSTRAP_TOKEN", "").strip()
        # Three ways to authenticate — any one is sufficient:
        #   1. AGT_CP_TOKEN         → sent as X-AGT-Token to the backend directly.
        #   2. AGT_BOOTSTRAP_TOKEN  → swapped for a scoped api_token at startup
        #                             (IMPL-024.5, in Lifecycle._maybe_run_bootstrap).
        #   3. AGT_GATEWAY_API_KEY  → SaaS deployments only; the AppSOC gateway
        #                             validates it via X-appsoc-api-key and
        #                             injects X-Auth-Info downstream, so the
        #                             backend never needs an X-AGT-Token.
        # Only warn when *none* of the three is present.
        _gateway_key_check = os.environ.get("AGT_GATEWAY_API_KEY", "").strip()
        if cp_url and not cp_token and not bootstrap_token_check and not _gateway_key_check:
            logger.warning(
                "agt_sdk: AGT_CP_URL is set but none of AGT_CP_TOKEN, "
                "AGT_BOOTSTRAP_TOKEN, or AGT_GATEWAY_API_KEY — register / "
                "heartbeat / audit calls will fail at the CP. Supply one."
            )
        elif bootstrap_token_check and not cp_token:
            logger.info(
                "agt_sdk: AGT_CP_TOKEN unset but AGT_BOOTSTRAP_TOKEN present — "
                "the bootstrap exchange will mint a scoped api_token for the "
                "rest of this process (IMPL-024.5)."
            )

        master_enabled = _bool("AGT_GOVERNANCE_ENABLED", True)
        enabled = master_enabled and bool(cp_url)

        # Per design rule: AGT_POLICY_SERVER_URL and AGT_AUDIT_URL default to AGT_CP_URL.
        # This makes single-host deployments work with two env vars and split deployments
        # work with all three — same SDK code, different deploy.
        policy_url = os.environ.get("AGT_POLICY_SERVER_URL", "").rstrip("/").strip() or cp_url
        audit_url = os.environ.get("AGT_AUDIT_URL", "").rstrip("/").strip() or cp_url

        agent_id = os.environ.get("AGT_AGENT_ID", "").strip() or _default_agent_id()
        agent_name = os.environ.get("AGT_AGENT_NAME", "").strip() or agent_id
        description = os.environ.get("AGT_AGENT_DESCRIPTION", "").strip()
        # IMPL-036 — comma-separated capability strings.
        # `read:data, ,execute:sql,` → ("read:data", "execute:sql"). Empty or
        # all-whitespace yields an empty tuple (server uses column default).
        raw_caps = os.environ.get("AGT_AGENT_CAPABILITIES", "")
        capabilities = tuple(c.strip() for c in raw_caps.split(",") if c.strip())
        agent_type = os.environ.get("AGT_AGENT_TYPE", "").strip()
        agent_source = os.environ.get("AGT_AGENT_SOURCE", "").strip() or "agt_sdk"
        bootstrap_token = os.environ.get("AGT_BOOTSTRAP_TOKEN", "").strip()
        # IMPL-045 — operator-supplied org slug (one new env var per ergonomics rule).
        # Lower-cased to match the CP, which stores slugs lower.
        org_code = os.environ.get("AGT_ORG_CODE", "").strip().lower()

        # PGAIAuthGateway-managed key. When unset the SDK doesn't add any
        # gateway header — direct-CP deployments continue to work unchanged.
        gateway_api_key = os.environ.get("AGT_GATEWAY_API_KEY", "").strip()

        fail_mode = os.environ.get("AGT_FAIL_MODE", "open").strip().lower()
        if fail_mode not in ("open", "closed"):
            logger.warning("AGT_FAIL_MODE=%r invalid — defaulting to 'open'", fail_mode)
            fail_mode = "open"

        return cls(
            enabled=enabled,
            cp_url=cp_url,
            cp_token=cp_token,
            policy_server_url=policy_url,
            audit_url=audit_url,
            agent_id=agent_id,
            agent_name=agent_name,
            agent_description=description,
            capabilities=capabilities,
            agent_type=agent_type,
            agent_source=agent_source,
            bootstrap_token=bootstrap_token,
            org_code=org_code,
            gateway_api_key=gateway_api_key,
            fail_mode=fail_mode,
            heartbeat_seconds=_int("AGT_HEARTBEAT_SECONDS", 60),
            policy_refresh_seconds=_int("AGT_POLICY_REFRESH_SECONDS", 60),
            injection_scanner=_bool("AGT_INJECTION_SCANNER", True),
            local_safety_baseline=_bool("AGT_LOCAL_SAFETY_BASELINE", True),
            log_level=os.environ.get("AGT_LOG_LEVEL", "INFO").upper().strip() or "INFO",
        )
