# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""LangGraph adapter — ``GovernedToolNode``.

A drop-in replacement for ``langgraph.prebuilt.ToolNode`` that intercepts
every tool call, runs it through the governance pipeline (injection scan +
local baseline + policy evaluation), and either forwards to the underlying
``ToolNode`` (allowed) or returns a ``ToolMessage`` with a block reason.

Customer code:

    from agt_sdk.langgraph import GovernedToolNode
    tool_node = GovernedToolNode(tools)
    graph = create_react_agent(llm, tool_node, prompt=...)

That's the entire integration. All configuration is read from environment
variables — see ``agt_sdk/README.md``.
"""

from __future__ import annotations

from typing import Any

try:
    from langchain_core.messages import AIMessage, ToolMessage
    from langgraph.prebuilt import ToolNode
except ImportError as exc:    # pragma: no cover - import guard
    raise ImportError(
        "agt_sdk.langgraph requires langgraph and langchain-core. "
        "Install with: pip install 'agt-sdk[langgraph]'"
    ) from exc

from agt_sdk._kernel import AutoKernel


class GovernedToolNode(ToolNode):
    """``ToolNode`` subclass that enforces AGT governance per tool call.

    Drop-in: anywhere your code currently builds ``ToolNode(tools, ...)`` you
    can swap to ``GovernedToolNode(tools, ...)`` — no other change needed.

    The governance configuration (CP URL, token, agent identity, policy
    bundle) is loaded from environment variables on first use. See the
    package README for the full env-var reference.
    """

    def __init__(
        self,
        tools: list,
        *,
        agent_id: str | None = None,
        policy_names: list[str] | None = None,
        extra_policies: dict[str, dict[str, Any]] | None = None,
        fail_mode: str | None = None,
        **tool_node_kwargs: Any,
    ) -> None:
        """Build a governed tool node.

        Args:
            tools:           List of LangChain ``BaseTool`` instances. Same
                             argument as ``ToolNode``.
            agent_id:        Override ``AGT_AGENT_ID`` env var for this node only.
            policy_names:    Restrict policy evaluation to these named bundles.
                             Defaults to "all loaded policies".
            extra_policies:  Local policies merged on top of whatever CP returns.
            fail_mode:       ``"open"`` | ``"closed"``. Overrides env var.
            **tool_node_kwargs:
                             Passed straight through to the parent ``ToolNode``
                             (``handle_tool_errors``, ``messages_key``, etc.).
        """
        super().__init__(tools, **tool_node_kwargs)
        self._kernel = AutoKernel.instance()
        self._agent_id_override = agent_id
        self._policy_names = policy_names
        self._fail_mode_override = fail_mode

        if extra_policies:
            self._kernel.add_policies(extra_policies)

    async def ainvoke(
        self,
        input: Any,
        config: Any = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        # Pass through immediately when governance is disabled.
        if not self._kernel.enabled:
            return await super().ainvoke(input, config, **kwargs)

        tool_calls = self._extract_tool_calls(input)
        if not tool_calls:
            return await super().ainvoke(input, config, **kwargs)

        # ── Evaluate every tool call in the message ──────────────────────────
        blocked: dict[str, str] = {}     # tool_call_id → reason
        for tc in tool_calls:
            res = await self._kernel.check(
                tool_name=tc.get("name", ""),
                tool_args=tc.get("args", {}) or {},
                policy_names=self._policy_names,
            )
            if not res.allowed:
                blocked[tc["id"]] = res.reason or "Blocked by AGT governance"

        # ── Fast path: nothing blocked ──────────────────────────────────────
        if not blocked:
            return await super().ainvoke(input, config, **kwargs)

        # ── Build error ToolMessages for blocked calls ───────────────────────
        blocked_msgs: list[ToolMessage] = [
            ToolMessage(
                content=f"[BLOCKED by AGT governance]: {reason}",
                tool_call_id=tc_id,
                name=next(
                    (tc.get("name", "unknown") for tc in tool_calls if tc.get("id") == tc_id),
                    "unknown",
                ),
                status="error",
            )
            for tc_id, reason in blocked.items()
        ]

        # ── Run base ToolNode for allowed calls only ────────────────────────
        allowed_tcs = [tc for tc in tool_calls if tc["id"] not in blocked]
        if not allowed_tcs:
            return {"messages": blocked_msgs}

        # Build a filtered input that has only allowed tool calls, in the same
        # shape that LangGraph passed in — list-of-tool_call_dicts, list of messages,
        # or {"messages": [...]} dict.
        filtered_input = self._rebuild_input(input, allowed_tcs)
        base_result = await super().ainvoke(filtered_input, config, **kwargs)
        if isinstance(base_result, dict):
            allowed_msgs: list = base_result.get("messages", [])
        elif isinstance(base_result, list):
            allowed_msgs = base_result
        else:
            allowed_msgs = []

        return {"messages": allowed_msgs + blocked_msgs}

    # ── Tool-call extraction helpers ──────────────────────────────────────────

    @staticmethod
    def _is_tool_call_dict(d: Any) -> bool:
        """A langchain ``tool_call`` dict has at minimum ``name`` and ``id`` keys."""
        return isinstance(d, dict) and "name" in d and "id" in d

    def _extract_tool_calls(self, input: Any) -> list[dict[str, Any]]:
        """Return the tool_calls list from any of LangGraph's input shapes."""
        # Shape A: bare list of tool_call dicts (LangGraph 0.3+ ToolNode invocation)
        if isinstance(input, list) and input and self._is_tool_call_dict(input[0]):
            return list(input)

        # Shape B: list of messages
        if isinstance(input, list) and input:
            last = input[-1]
            if isinstance(last, dict):
                return list(last.get("tool_calls") or [])
            return list(getattr(last, "tool_calls", None) or [])

        # Shape C: {"messages": [...]} dict
        if isinstance(input, dict):
            messages = input.get("messages", [])
            if not messages:
                return []
            last = messages[-1]
            if isinstance(last, dict):
                return list(last.get("tool_calls") or [])
            return list(getattr(last, "tool_calls", None) or [])

        return []

    def _rebuild_input(self, original_input: Any, allowed_tool_calls: list[dict[str, Any]]) -> Any:
        """Reconstruct the original input shape with only allowed tool calls."""
        # Shape A — bare list of tool_call dicts
        if isinstance(original_input, list) and original_input and self._is_tool_call_dict(original_input[0]):
            return allowed_tool_calls

        # Shape B / C — list-of-messages or dict
        if isinstance(original_input, list):
            if not original_input:
                return original_input
            last = original_input[-1]
            new_last = self._patch_tool_calls(last, allowed_tool_calls)
            return original_input[:-1] + [new_last]

        if isinstance(original_input, dict):
            messages = original_input.get("messages", [])
            if not messages:
                return original_input
            new_last = self._patch_tool_calls(messages[-1], allowed_tool_calls)
            return {**original_input, "messages": messages[:-1] + [new_last]}

        return original_input

    @staticmethod
    def _patch_tool_calls(message: Any, allowed_tool_calls: list[dict[str, Any]]) -> Any:
        """Return a copy of `message` with its tool_calls replaced."""
        if isinstance(message, dict):
            return {**message, "tool_calls": allowed_tool_calls}
        return AIMessage(
            content=getattr(message, "content", ""),
            tool_calls=allowed_tool_calls,
            id=getattr(message, "id", None),
        )
