# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Control-plane-aware variant of agent_os.policies.remote.RemotePolicyProvider.

The upstream ``RemotePolicyProvider`` was designed against the agent-mesh
``policy-server`` at ``http://agentmesh:8444``, which returns a bare
``{policies: [...], fetched_at: "..."}`` JSON dict. The AGT control-plane
exposes the same logical bundle at ``/api/v1/policies/bundle`` but wraps
it in its standard ``ApiResponse`` envelope::

    {"success": true, "data": {"policies": [...], "fetched_at": "..."},
     "error": null, "meta": ...}

If the SDK uses the upstream provider unmodified against the CP, the
``data.get("policies", [])`` line in upstream ``_fetch`` reads the
top-level ``"policies"`` key (which doesn't exist on the wrapped shape)
and silently caches an empty list. The SDK then runs forever on
``StatelessKernel.DEFAULT_POLICIES`` only — CP→SDK distribution is broken
without any visible error.

This subclass overrides ``_fetch`` to peel the envelope before populating
the cache. Both shapes are handled (wrapped + bare) so the same SDK works
against either backend.

IMPL-047 P0-1 (Tier A.3+sponsor) — scoped bundle resolution
-----------------------------------------------------------
When ``agent_id`` / ``agent_type`` / ``sponsor_id`` are supplied, the
provider POSTs the agent's profile to ``/policies/bundle/resolve`` and
the CP returns just the policies whose bindings apply to this agent.
That closes 4 of 6 binding axes at boot (``agent``, ``agent_type``,
``sponsor``, ``org``). The ``tool`` and ``mcp_server`` axes remain
kernel-side: each policy's binding metadata is delivered with it, and
``kernel.check(tool=X)`` matches them locally — no per-call CP traffic.

Resolve response shape is ``{"effective_policies": [...]}`` (vs the flat
endpoint's ``{"policies": [...]}``). Both are accepted.

Older CPs return 404/405 on the resolve route; the provider then falls
back to the flat GET and logs a one-shot deprecation warning.

Living in the SDK, not in ``packages/agent-os/``, keeps upstream merge-safe.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable

import httpx

from agent_os.policies.remote import RemotePolicyProvider

from ._paths import api_v1_url, is_valid_org_code
from .exceptions import AGTConfigurationError

logger = logging.getLogger(__name__)


class CPRemotePolicyProvider(RemotePolicyProvider):
    """``RemotePolicyProvider`` that unwraps the CP's ``ApiResponse`` envelope.

    Fetches ``/api/v1/orgs/{org_code}/policies/bundle`` (or the legacy
    unscoped ``/api/v1/policies/bundle`` when ``org_code`` is unset — CP
    grace 307-redirects; this subclass composes the org-scoped URL up
    front so httpx, which does not follow redirects by default, doesn't
    silently cache an empty list).

    Accepts either:

    - ``{"data": {"policies": [...], "fetched_at": "..."}, ...}`` (CP) — unwrap
    - ``{"policies": [...], "fetched_at": "..."}`` (upstream policy-server) — pass-through

    Everything else (refresh loop, lock, get_policies, start/stop, on_refresh
    callback wiring) is inherited from the upstream class unchanged.
    """

    # IMPL-045 / IMPL-047-P0-1 — additive kwargs for URL + scoped-resolve
    # context. Empty-string defaults keep existing callers working.
    def __init__(
        self,
        policy_server_url: str,
        ttl: int = 60,
        token: str = "",
        on_refresh: Callable[[list[dict[str, Any]]], None] | None = None,
        org_code: str = "",
        agent_id: str = "",
        agent_type: str = "",
        sponsor_id: str = "",
        gateway_api_key: str = "",
        require_org_scope: bool = False,
    ) -> None:
        super().__init__(policy_server_url, ttl=ttl, token=token, on_refresh=on_refresh)
        self._org_code = org_code
        # Fail closed on a missing/invalid org slug when the caller is in
        # org-scoped mode (bootstrapped agent or SaaS gateway). Without this
        # guard, ``api_v1_url`` silently composes the legacy *unscoped*
        # ``/api/v1/policies/bundle`` — which on a multi-tenant CP either
        # 404s (org-scoped-only gateway) or, worse, would address the wrong
        # policy surface. Refusing here means the agent never fetches policy
        # from an unscoped endpoint; the caller (_lifecycle) treats this as a
        # hard configuration error rather than a fail-open-to-defaults case.
        if require_org_scope and not is_valid_org_code(org_code):
            raise AGTConfigurationError(
                "org-scoped policy provider requires a valid AGT_ORG_CODE "
                f"(got {org_code!r}); refusing to fetch policy from the "
                "unscoped /api/v1/policies/bundle endpoint. Set AGT_ORG_CODE "
                "to this agent's org slug."
            )
        # Compose once — warmup_sync + _fetch reuse this. ``self._url`` came
        # from the parent constructor (already rstrip'd).
        self._policy_url = api_v1_url(self._url, "/policies/bundle", org_code)
        self._resolve_url = self._policy_url + "/resolve"
        self._agent_id   = agent_id
        self._agent_type = agent_type
        self._sponsor_id = sponsor_id
        # PGAIAuthGateway header — appended to every outbound auth header
        # set via ``_auth_headers`` so warmup_sync + _fetch both carry it.
        self._gateway_api_key = gateway_api_key
        # Set once the CP returns 404/405 from /resolve — switches to flat
        # GET for the rest of this process and suppresses repeat warnings.
        self._scoped_resolve_unavailable = False

    def _auth_headers(self) -> dict[str, str]:
        h: dict[str, str] = {}
        if self._token:
            # Auth-header dispatch matches the upstream rules — agt_* tokens
            # go in X-AGT-Token, JWTs in Authorization Bearer.
            if self._token.startswith("agt_"):
                h["X-AGT-Token"] = self._token
            else:
                h["Authorization"] = f"Bearer {self._token}"
        # PGAIAuthGateway headers — required by the SaaS gateway sitting
        # in front of the CP. Empty in direct-CP deployments. Uses the
        # single source of truth in _gateway_headers so this stays in
        # sync with _lifecycle.py / _ingest.py / _heartbeat.py.
        if self._gateway_api_key:
            # Import locally to avoid a circular import at module load.
            from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
            h[GATEWAY_API_KEY_HEADER] = self._gateway_api_key
        return h

    @staticmethod
    def _unwrap(raw: object) -> dict:
        """Peel ApiResponse envelope if present, else pass through."""
        if isinstance(raw, dict) and isinstance(raw.get("data"), dict):
            return raw["data"]
        return raw if isinstance(raw, dict) else {}

    @staticmethod
    def _extract_policies(payload: dict) -> list[dict]:
        """Read policies from either response shape.

        Flat ``/policies/bundle`` returns ``{"policies": [...]}``; the scoped
        ``/policies/bundle/resolve`` returns ``{"effective_policies": [...]}``.
        Both reach here already unwrapped of the ApiResponse envelope.
        """
        if "effective_policies" in payload:
            return payload.get("effective_policies") or []
        return payload.get("policies") or []

    def _has_scope_context(self) -> bool:
        """True when any context field is set — i.e. we should try /resolve."""
        return bool(self._agent_id or self._agent_type or self._sponsor_id)

    def _context_body(self) -> dict:
        """Build the ``ResolveRequest`` body. Empty fields omitted; the CP
        treats them as None and resolves against the broader scope."""
        body: dict[str, Any] = {}
        if self._agent_id:
            body["agent_id"] = self._agent_id
        if self._agent_type:
            body["agent_type"] = self._agent_type
        if self._sponsor_id:
            body["sponsor_id"] = self._sponsor_id
        return body

    def _mark_resolve_unavailable(self, status_code: int) -> None:
        """One-shot deprecation log + switch to flat-GET for the rest of process."""
        if not self._scoped_resolve_unavailable:
            logger.warning(
                "agt_sdk: CP returned %d for %s — falling back to flat "
                "/policies/bundle. Scoped policy resolution requires "
                "IMPL-027 on the CP. This SDK process will continue with "
                "the org-wide bundle.",
                status_code, self._resolve_url,
            )
        self._scoped_resolve_unavailable = True

    def warmup_sync(self) -> None:
        """One-shot synchronous fetch — populates the cache before any
        ``kernel.check()`` call has a chance to run.

        Why this is needed: ``StatelessKernel.start()`` schedules the async
        ``_remote_policy.start()`` either via ``loop.run_until_complete``
        (when no loop is running — sync agent like agent_alpha.py) or via
        ``loop.create_task`` (when called from inside ``asyncio.run`` — async
        agent like agent_beta.py). In the second path, ``kernel.start()``
        returns *immediately* without awaiting the fetch, so the agent's
        first few ``await kernel.check(...)`` calls race the still-pending
        bundle download — they see ``StatelessKernel.DEFAULT_POLICIES`` only
        and CP-only rules don't fire.

        ``warmup_sync`` is called from the SDK lifecycle right after
        wiring this provider into the kernel, so by the time
        ``AutoKernel.instance()`` returns, ``self._cache`` is populated
        regardless of caller context. The async refresh loop started later
        by ``kernel.start()`` continues to refresh on the configured TTL.

        Trade-off: blocks for the duration of one HTTP round-trip (~tens
        of ms locally; capped at 5s). When called from inside a running
        event loop this briefly blocks that loop — acceptable for a
        one-shot startup warmup.
        """
        try:
            with httpx.Client(timeout=5.0) as client:
                resp = self._do_fetch_sync(client)
                resp.raise_for_status()
                policies = self._extract_policies(self._unwrap(resp.json()))
                self._cache = policies
                self._fetched_at = time.monotonic()
            logger.debug(
                "agt_sdk: warmup-fetched %d policies from %s",
                len(self._cache), self._url,
            )
            if self._on_refresh is not None:
                try:
                    self._on_refresh(list(self._cache))
                except Exception:
                    logger.warning(
                        "agt_sdk: warmup on_refresh callback raised — ignoring",
                        exc_info=True,
                    )
        except Exception as exc:
            logger.warning(
                "agt_sdk: policy warmup failed (%s) — async refresh will retry",
                exc,
            )

    def _do_fetch_sync(self, client: "httpx.Client") -> "httpx.Response":
        """POST to ``/resolve`` when context is set and the route is available;
        otherwise GET the flat bundle. Detects 404/405 from older CPs and
        falls back transparently."""
        headers = self._auth_headers()
        if self._has_scope_context() and not self._scoped_resolve_unavailable:
            resp = client.post(self._resolve_url, headers=headers, json=self._context_body())
            if resp.status_code in (404, 405):
                self._mark_resolve_unavailable(resp.status_code)
                return client.get(self._policy_url, headers=headers)
            return resp
        return client.get(self._policy_url, headers=headers)

    async def _fetch(self) -> None:  # type: ignore[override]
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await self._do_fetch_async(client)
                resp.raise_for_status()
                policies = self._extract_policies(self._unwrap(resp.json()))
                async with self._lock:
                    self._cache = policies
                    self._fetched_at = time.monotonic()
                logger.debug(
                    "agt_sdk: fetched %d policies from %s", len(self._cache), self._url
                )
                if self._on_refresh is not None:
                    try:
                        self._on_refresh(list(self._cache))
                    except Exception:
                        logger.warning(
                            "agt_sdk: policy bundle on_refresh callback raised — ignoring",
                            exc_info=True,
                        )
        except Exception as exc:
            if self._cache:
                logger.warning(
                    "agt_sdk: remote policy fetch failed (%s) — using %d cached policies",
                    exc, len(self._cache),
                )
            else:
                logger.warning(
                    "agt_sdk: remote policy fetch failed (%s) — no cache, using empty policy set",
                    exc,
                )

    async def _do_fetch_async(self, client: "httpx.AsyncClient") -> "httpx.Response":
        """Async counterpart of ``_do_fetch_sync``. Same fallback semantics."""
        headers = self._auth_headers()
        if self._has_scope_context() and not self._scoped_resolve_unavailable:
            resp = await client.post(self._resolve_url, headers=headers, json=self._context_body())
            if resp.status_code in (404, 405):
                self._mark_resolve_unavailable(resp.status_code)
                return await client.get(self._policy_url, headers=headers)
            return resp
        return await client.get(self._policy_url, headers=headers)
