# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""SDK exceptions."""

from __future__ import annotations


class AGTSDKError(Exception):
    """Base class for all SDK errors."""


class AGTConfigurationError(AGTSDKError):
    """Raised when SDK configuration is invalid or required env vars are missing.

    Only raised in fail-closed mode when ``AGT_CP_URL`` is set but malformed.
    Missing env vars are silently treated as "governance disabled" (the SDK
    becomes a pass-through).
    """


class AGTBlocked(AGTSDKError):
    """Raised when a tool/action is blocked by governance.

    Adapters typically convert this into a framework-native error message
    (e.g. ``ToolMessage(status="error")`` for LangChain) rather than letting
    it propagate. The exception is exposed for use cases where the customer
    wants to handle it directly (e.g. raw decorator usage).

    Attributes:
        reason:        Human-readable reason from the policy engine.
        matched_rule:  Name of the policy rule that triggered the block.
        policy_name:   Name of the policy bundle that owns the rule.
        action:        The action/tool name that was blocked.
    """

    def __init__(
        self,
        reason: str,
        action: str = "",
        matched_rule: str | None = None,
        policy_name: str | None = None,
    ) -> None:
        super().__init__(reason)
        self.reason = reason
        self.action = action
        self.matched_rule = matched_rule
        self.policy_name = policy_name

    def __str__(self) -> str:
        return f"[BLOCKED by AGT governance]: {self.reason}"


class AGTPeerUntrusted(AGTSDKError):
    """Raised by ``@peer_verified`` when a peer may not be called.

    IMPL-065. The decorator raises rather than returning a verdict, because a
    verdict nobody is obliged to read is a gate you can forget to check — and
    the failure mode is a silent ungated peer call.

    Callers wanting the detail without re-running the gate read ``.verdict``,
    which carries the same ``A2AVerdict`` ``kernel.a2a_gate()`` returns. Callers
    that would rather branch than catch should use that method directly.

    Attributes:
        verdict: the full ``A2AVerdict`` — peer name, DID, trust score, reason.
    """

    def __init__(self, verdict: object) -> None:
        self.verdict = verdict
        peer = getattr(verdict, "peer_name", "?")
        reason = getattr(verdict, "reason", "") or "peer refused"
        super().__init__(f"A2A refused for peer {peer!r}: {reason}")
