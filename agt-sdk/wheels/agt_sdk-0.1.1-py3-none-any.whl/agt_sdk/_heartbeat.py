# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Background heartbeat thread.

POSTs to ``{cp_url}/api/v1/orgs/{org_code}/agents/{agent_id}/heartbeat``
every ``AGT_HEARTBEAT_SECONDS`` (default 60), or to the legacy
``/api/v1/agents/{agent_id}/heartbeat`` when no org code is set (CP
answers with a 307 grace redirect). Drives the "last seen" badge in the
control-plane UI and feeds orphan-agent detection (IMPL-012).

Best-effort: failures are logged at DEBUG and swallowed. Daemon thread —
exits with the process. Disable with ``AGT_HEARTBEAT_SECONDS=0``.
"""

from __future__ import annotations

import json
import logging
import threading
import urllib.error
import urllib.request

from ._paths import api_v1_url

logger = logging.getLogger("agt_sdk.heartbeat")


class HeartbeatThread:
    """Single daemon thread that posts heartbeats on a fixed interval."""

    def __init__(
        self,
        cp_url: str,
        cp_token: str,
        agent_id: str,
        interval_seconds: int = 60,
        org_code: str = "",
        gateway_api_key: str = "",
    ) -> None:
        self._url = api_v1_url(cp_url, f"/agents/{agent_id}/heartbeat", org_code)
        self._headers = {
            "X-AGT-Token":  cp_token,
            "Content-Type": "application/json",
            "Accept":       "application/json",
        }
        # PGAIAuthGateway header — API key. Uses the single source of truth
        # so _heartbeat stays in sync with the other outbound call sites
        # (_lifecycle, _ingest, _policy_provider).
        if gateway_api_key:
            from agt_sdk._gateway_headers import GATEWAY_API_KEY_HEADER
            self._headers[GATEWAY_API_KEY_HEADER] = gateway_api_key
        self._agent_id = agent_id
        self._interval = max(1, interval_seconds)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name=f"agt-sdk-heartbeat-{self._agent_id}",
        )
        self._thread.start()
        logger.info("heartbeat thread started for %s (interval=%ds)", self._agent_id, self._interval)

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        # Send first heartbeat ~2 s after start so the agent appears 'live' quickly.
        self._stop.wait(2.0)
        while not self._stop.is_set():
            self._beat_once()
            self._stop.wait(self._interval)

    def _beat_once(self) -> None:
        body = json.dumps({"agent_id": self._agent_id}).encode("utf-8")
        req = urllib.request.Request(self._url, data=body, headers=self._headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5) as r:  # noqa: S310 - controlled URL
                logger.debug("heartbeat ok status=%s agent=%s", r.status, self._agent_id)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            logger.debug("heartbeat failed agent=%s: %s", self._agent_id, exc)
        except Exception as exc:    # pragma: no cover - defensive
            logger.debug("heartbeat unexpected error agent=%s: %s", self._agent_id, exc)
