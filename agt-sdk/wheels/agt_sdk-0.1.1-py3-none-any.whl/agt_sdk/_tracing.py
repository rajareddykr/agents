# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Opik observability for agt_sdk - via the custom pointguard tracer SDK only.

Every governed decision (allow/deny from the check pipeline) is emitted to Opik
using pointguard's tracker/decorator subsystem - the same machinery behind
``@track`` in the tracer SDK examples (examples/openai_integration_example.py).
We use its programmatic form, ``start_as_current_trace`` /
``start_as_current_span`` + ``flush_tracker``, so agent code stays untouched
while every governed tool call becomes a trace + a ``guardrail`` span.

The ONLY layer that talks to Opik is our custom SDK ``pointguard``; this module
never imports native ``opik``. Connection + project come from the ambient
``~/.pointguard.config`` (pointguard configure ...), exactly like the examples.

Design:
    - Opt-in. Off unless AGT_TRACING is one of {opik, pointguard, true, 1, yes}.
    - No hard dependency. If pointguard is missing or init fails, every function
      here is a safe no-op - governance is never affected.
    - One trace per governed decision (named by the agent) with one guardrail
      span (named by the tool) carrying the verdict; flushed immediately.

Enable:
    AGT_TRACING=opik
    # Connection/project come from ~/.pointguard.config (pointguard configure).
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional

logger = logging.getLogger(__name__)

_enabled_cache: Optional[bool] = None
_pg: Any = None


def enabled() -> bool:
    """True when Opik tracing is switched on via the AGT_TRACING env var."""
    global _enabled_cache
    if _enabled_cache is None:
        val = os.environ.get("AGT_TRACING", "").strip().lower()
        _enabled_cache = val in ("opik", "pointguard", "true", "1", "yes")
    return _enabled_cache


def _ready() -> Any:
    """Import + prime pointguard once. Returns the pointguard module, or None."""
    global _pg
    if _pg is not None:
        return _pg or None
    try:
        import pointguard

        for _stale in ("POINTGUARD_URL_OVERRIDE", "AGT_OPIK_URL",
                       "AGT_OPIK_ORG_CODE", "AGT_OPIK_APP_ID"):
            os.environ.pop(_stale, None)
        pointguard.Pointguard()  # prime cached client; surfaces bad config early
        _pg = pointguard
        logger.info("agt_sdk: Opik tracing enabled via pointguard "
                    "(@track subsystem, config=~/.pointguard.config)")
    except Exception as exc:  # noqa: BLE001
        logger.warning("agt_sdk: Opik tracing disabled - pointguard init failed: %s", exc)
        _pg = False
        return None
    return _pg


def status() -> str:
    """Human-readable tracing status; eagerly primes pointguard."""
    if not enabled():
        return "Opik tracing: OFF  (set AGT_TRACING=opik to enable)"
    if _ready() is None:
        return ("Opik tracing: ENABLED but pointguard init FAILED "
                "(is it installed? check the warning log)")
    return "Opik tracing: ON  (pointguard @track, config=~/.pointguard.config)"


def record_decision(agent_id, agent_name, tool_name, args_repr, result) -> None:
    """Emit one Opik trace+span for a governed decision (decorator subsystem)."""
    if not enabled():
        return
    pg = _ready()
    if pg is None:
        return
    try:
        allowed = bool(getattr(result, "allowed", False))
        outcome = "allow" if allowed else "block"
        source = getattr(result, "source", "") or "policy"
        args_preview = (args_repr or "")[:1000]
        with pg.start_as_current_trace(
            name=agent_name or agent_id or "agt-agent",
            input={"tool": tool_name, "args": args_preview},
            metadata={"agent_id": agent_id, "framework": "agt-sdk"},
            tags=["agt-sdk", "governance", outcome],
        ):
            with pg.start_as_current_span(
                name=tool_name or "tool",
                type="guardrail",
                input={"tool": tool_name, "args": args_preview},
                output={"allowed": allowed, "reason": getattr(result, "reason", None)},
                metadata={
                    "outcome": outcome,
                    "matched_rule": getattr(result, "matched_rule", None),
                    "policy_name": getattr(result, "policy_name", None),
                    "source": source,
                    "latency_ms": getattr(result, "latency_ms", 0.0),
                    "agent_id": agent_id,
                },
                tags=[outcome, source],
                flush=True,
            ):
                pass
    except Exception as exc:  # noqa: BLE001
        logger.debug("agt_sdk: Opik span emit failed: %s", exc)


def flush() -> None:
    """Flush pointguard's tracker queue. Safe no-op when disabled."""
    if not enabled():
        return
    pg = _ready()
    if pg is None:
        return
    try:
        pg.flush_tracker()
    except Exception:  # noqa: BLE001
        pass
