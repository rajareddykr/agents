# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""``@governed`` decorator — framework-agnostic.

For raw Python tool functions (no LangChain / LangGraph). Wraps any
callable so its arguments are checked against the active governance
policies before the function body runs.

    from agt_sdk import governed

    @governed(action="send_email")
    async def send_email(to: str, subject: str, body: str) -> None:
        ...

If the call is blocked, an :class:`AGTBlocked` exception is raised. The
caller can catch it or let it propagate.

Both sync and async callables are supported; the decorator detects which.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

from agt_sdk._kernel import AutoKernel
from agt_sdk.exceptions import AGTBlocked

F = TypeVar("F", bound=Callable[..., Any])


def governed(
    *,
    action: str | None = None,
    policy_names: list[str] | None = None,
) -> Callable[[F], F]:
    """Decorator that runs a governance check before each call.

    Args:
        action:        Action name passed to the policy engine. Defaults to
                       the decorated function's ``__name__``.
        policy_names:  Restrict evaluation to these named bundles. Defaults
                       to all loaded.

    Returns:
        The decorated callable. Async functions stay async; sync stay sync.

    Raises:
        AGTBlocked: when a call is blocked by governance.
    """
    def _decorate(fn: F) -> F:
        kernel = AutoKernel.instance()
        action_name = action or getattr(fn, "__name__", "anonymous")

        if not kernel.enabled:
            return fn

        sig = None
        try:
            sig = inspect.signature(fn)
        except (TypeError, ValueError):
            pass

        def _build_args_dict(args: tuple, kwargs: dict[str, Any]) -> dict[str, Any]:
            if sig is None:
                return {"args": list(args), "kwargs": dict(kwargs)}
            try:
                bound = sig.bind_partial(*args, **kwargs)
                return dict(bound.arguments)
            except TypeError:
                return {"args": list(args), "kwargs": dict(kwargs)}

        if asyncio.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                params = _build_args_dict(args, kwargs)
                result = await kernel.check(action_name, params, policy_names=policy_names)
                if not result.allowed:
                    raise AGTBlocked(
                        reason=result.reason or "Blocked by AGT policy",
                        action=action_name,
                        matched_rule=result.matched_rule,
                        policy_name=result.policy_name,
                    )
                return await fn(*args, **kwargs)
            return async_wrapper  # type: ignore[return-value]

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            params = _build_args_dict(args, kwargs)
            # Bridge to the async check from sync context.
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                result = asyncio.run(kernel.check(action_name, params, policy_names=policy_names))
            else:
                # Inside a running loop — execute on a worker thread.
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
                    fut = ex.submit(
                        asyncio.run,
                        kernel.check(action_name, params, policy_names=policy_names),
                    )
                    result = fut.result()
                # Mark loop variable as used to satisfy linters.
                _ = loop

            if not result.allowed:
                raise AGTBlocked(
                    reason=result.reason or "Blocked by AGT policy",
                    action=action_name,
                    matched_rule=result.matched_rule,
                    policy_name=result.policy_name,
                )
            return fn(*args, **kwargs)
        return sync_wrapper  # type: ignore[return-value]

    return _decorate
