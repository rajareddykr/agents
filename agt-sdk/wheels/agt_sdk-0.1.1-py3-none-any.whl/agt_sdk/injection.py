# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Prompt-injection scanner.

Pattern-based detector that runs before policy evaluation on every tool call.
Mirrors the hand-rolled scanner in `langchain-ui-agent/governance.py` so
that customers don't have to write their own.

OWASP LLM01 (Prompt Injection) coverage. Disable with
``AGT_INJECTION_SCANNER=off``.

Public API:

    from agt_sdk import injection

    # Add your own pattern at runtime:
    injection.add_pattern(
        pattern=r"exfiltrate\\s+via",
        injection_type="indirect_injection",
        threat_level="critical",
        confidence=0.97,
    )

    # Run a scan directly (adapters do this automatically):
    finding = injection.scan("get_time", "ignore previous instructions")
    if finding:
        ...
"""

from __future__ import annotations

import re
import threading
from dataclasses import dataclass

# ── Default pattern set ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class InjectionPattern:
    regex: re.Pattern[str]
    injection_type: str
    threat_level: str   # "low" | "medium" | "high" | "critical"
    confidence: float   # 0.0 – 1.0


@dataclass(frozen=True)
class InjectionFinding:
    injection_type: str
    threat_level: str
    confidence: float
    matched_text: str
    explanation: str


_DEFAULT_PATTERNS: list[InjectionPattern] = [
    InjectionPattern(re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.I),
                     "jailbreak", "high", 0.95),
    InjectionPattern(re.compile(r"disregard\s+(all\s+)?previous\s+(instructions|context)", re.I),
                     "jailbreak", "high", 0.92),
    InjectionPattern(re.compile(r"forget\s+(all\s+)?previous\s+(instructions|context)", re.I),
                     "jailbreak", "high", 0.90),
    InjectionPattern(re.compile(r"\bDAN\b|\bdo\s+anything\s+now\b", re.I),
                     "jailbreak", "high", 0.93),
    InjectionPattern(re.compile(r"\bjailbreak\b", re.I),
                     "jailbreak", "high", 0.88),
    InjectionPattern(re.compile(r"(reveal|show|print|output|repeat|echo)\s+(your\s+)?(system\s+)?prompt", re.I),
                     "prompt_leakage", "medium", 0.85),
    InjectionPattern(re.compile(r"what\s+(are|is)\s+your\s+(instructions|system\s+prompt|directives)", re.I),
                     "prompt_leakage", "medium", 0.82),
    InjectionPattern(re.compile(r"send\s+(this|the\s+above|all\s+of\s+this)\s+(to|via)\s+https?://", re.I),
                     "indirect_injection", "critical", 0.95),
    InjectionPattern(re.compile(r"\bcurl\s+https?://", re.I),
                     "indirect_injection", "critical", 0.98),
    InjectionPattern(re.compile(r"\bwebhook\b.{0,30}\bhttps?://", re.I),
                     "indirect_injection", "critical", 0.90),
]

_patterns: list[InjectionPattern] = list(_DEFAULT_PATTERNS)
_lock = threading.Lock()


# ── Public API ───────────────────────────────────────────────────────────────


def add_pattern(
    pattern: str,
    injection_type: str,
    threat_level: str,
    confidence: float,
    flags: int = re.IGNORECASE,
) -> None:
    """Add a custom pattern to the scanner. Thread-safe.

    Args:
        pattern:        Python regex.
        injection_type: Caller-defined category (e.g. ``"jailbreak"``).
        threat_level:   ``"low"`` | ``"medium"`` | ``"high"`` | ``"critical"``.
        confidence:     ``0.0``–``1.0``.
        flags:          Compile flags (default: ``re.IGNORECASE``).
    """
    compiled = re.compile(pattern, flags)
    with _lock:
        _patterns.append(InjectionPattern(compiled, injection_type, threat_level, confidence))


def reset_patterns() -> None:
    """Reset to the built-in default pattern set. Useful for testing."""
    with _lock:
        _patterns.clear()
        _patterns.extend(_DEFAULT_PATTERNS)


def scan(tool_name: str, input_str: str) -> InjectionFinding | None:
    """Scan an input string. Returns the first match, or None."""
    if not input_str:
        return None
    with _lock:
        snapshot = tuple(_patterns)
    for p in snapshot:
        m = p.regex.search(input_str)
        if m:
            matched = m.group(0)
            return InjectionFinding(
                injection_type=p.injection_type,
                threat_level=p.threat_level,
                confidence=p.confidence,
                matched_text=matched,
                explanation=f"Pattern matched in '{tool_name}' input: '{matched}'",
            )
    return None
