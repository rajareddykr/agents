# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""CrewAI adapter.

One-line integration:

    from agt_sdk.crewai import wrap
    wrap(crew)                # wraps every tool on every agent

Then call ``crew.kickoff()`` as usual.

The wrapper accepts a ``Crew``, an ``Agent``, or a list of tools — whichever
is most convenient for the customer's code shape. It walks the object graph
to find every distinct tool instance and replaces its ``_run`` / ``_arun``
methods (CrewAI ``BaseTool``) and/or ``func`` / ``coroutine`` attributes
(LangChain-wrapped tools used inside CrewAI) with governance-checking
versions.

Tools whose ``_agt_wrapped`` attribute is already True are left alone, so
calling ``wrap(...)`` twice on the same crew is safe.

When ``AGT_GOVERNANCE_ENABLED=false`` (or ``AGT_CP_URL`` is unset) the
function is a transparent identity — it returns the crew unmodified.

Note: ``governed`` is the deprecated alias for ``wrap`` (renamed in
IMPL-035 cleanup 4). Both work identically in this release; the old
name emits ``DeprecationWarning`` and will be removed in v0.3.
"""

from __future__ import annotations

from typing import Any

from agt_sdk._async import run_async as _run_async
from agt_sdk._kernel import AutoKernel


# ── Public API ───────────────────────────────────────────────────────────────


def wrap(obj: Any) -> Any:
    """Wrap a CrewAI ``Crew``, ``Agent``, or list of tools.

    Returns the input unchanged when governance is disabled. Otherwise
    walks the object graph and replaces each tool's run methods with
    governance-checking versions. Idempotent — safe to call twice.

    Args:
        obj: A ``crewai.Crew``, ``crewai.Agent``, or any iterable of tools.

    Returns:
        The same ``obj`` (modified in place when governance is enabled).
    """
    kernel = AutoKernel.instance()
    if not kernel.enabled:
        return obj

    for tool in _collect_tools(obj):
        _wrap_tool_inplace(tool, kernel)
    return obj


def governed(obj: Any) -> Any:
    """Deprecated alias for :func:`wrap`. Will be removed in v0.3."""
    import warnings
    warnings.warn(
        "agt_sdk.crewai.governed is renamed to agt_sdk.crewai.wrap. "
        "The old name will be removed in v0.3.",
        DeprecationWarning,
        stacklevel=2,
    )
    return wrap(obj)


# ── Internal — walk the CrewAI object graph ─────────────────────────────────


def _collect_tools(obj: Any) -> list[Any]:
    """Return every distinct tool reachable from *obj*.

    Handles all the shapes a customer might pass:
      * ``Crew`` (has ``agents`` and ``tasks``)
      * ``Agent`` (has ``tools``)
      * ``Task`` (has ``tools`` and an ``agent``)
      * a list / tuple of tools directly
    """
    seen: set[int] = set()
    out: list[Any] = []

    def _add(t: Any) -> None:
        if t is None or id(t) in seen:
            return
        seen.add(id(t))
        out.append(t)

    # Bare list/tuple of tools
    if isinstance(obj, (list, tuple)):
        for t in obj:
            _add(t)
        return out

    # Crew → walk agents and tasks
    agents = getattr(obj, "agents", None) or []
    for a in agents:
        for t in (getattr(a, "tools", None) or []):
            _add(t)

    tasks = getattr(obj, "tasks", None) or []
    for ts in tasks:
        for t in (getattr(ts, "tools", None) or []):
            _add(t)
        # A task may carry its own agent reference; capture its tools too.
        a = getattr(ts, "agent", None)
        if a is not None:
            for t in (getattr(a, "tools", None) or []):
                _add(t)

    # Single Agent (no agents attribute, but has its own tools)
    if not agents and not tasks:
        own = getattr(obj, "tools", None)
        if own:
            for t in own:
                _add(t)

    return out


# ── Internal — wrap a single tool's run methods ─────────────────────────────


def _capture_args(args: tuple, kwargs: dict) -> dict:
    """Build a tool_args dict the policy engine can pattern-match against.

    CrewAI typically calls tools with named kwargs (driven by the tool's
    pydantic args_schema) so we use kwargs as the primary view. Positional
    args are stored under ``_positional`` so the policy can still see them.
    """
    out = dict(kwargs)
    if args:
        out["_positional"] = list(args)
    return out


def _wrap_tool_inplace(tool: Any, kernel: AutoKernel) -> None:
    """Replace a tool's run callables with governance-checking wrappers."""
    if getattr(tool, "_agt_wrapped", False):
        return    # idempotent

    name = getattr(tool, "name", None) or tool.__class__.__name__

    # CrewAI BaseTool surface — sync `_run` and async `_arun`
    orig_run = getattr(tool, "_run", None)
    orig_arun = getattr(tool, "_arun", None)
    # LangChain tool surface — `func` (sync) and `coroutine` (async)
    orig_func = getattr(tool, "func", None)
    orig_coro = getattr(tool, "coroutine", None)

    if callable(orig_run):
        def wrapped_run(*args: Any, **kwargs: Any) -> Any:
            res = _run_async(kernel.check(
                tool_name=name,
                tool_args=_capture_args(args, kwargs),
            ))
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return orig_run(*args, **kwargs)
        _setattr_safe(tool, "_run", wrapped_run)

    if callable(orig_arun):
        async def wrapped_arun(*args: Any, **kwargs: Any) -> Any:
            res = await kernel.check(
                tool_name=name,
                tool_args=_capture_args(args, kwargs),
            )
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return await orig_arun(*args, **kwargs)
        _setattr_safe(tool, "_arun", wrapped_arun)

    # Only wrap func/coroutine if no BaseTool surface was present —
    # otherwise we'd evaluate the same tool call twice.
    if not callable(orig_run) and callable(orig_func):
        def wrapped_func(*args: Any, **kwargs: Any) -> Any:
            res = _run_async(kernel.check(
                tool_name=name,
                tool_args=_capture_args(args, kwargs),
            ))
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return orig_func(*args, **kwargs)
        _setattr_safe(tool, "func", wrapped_func)

    if not callable(orig_arun) and callable(orig_coro):
        async def wrapped_coro(*args: Any, **kwargs: Any) -> Any:
            res = await kernel.check(
                tool_name=name,
                tool_args=_capture_args(args, kwargs),
            )
            if not res.allowed:
                return f"[BLOCKED by AGT governance]: {res.reason}"
            return await orig_coro(*args, **kwargs)
        _setattr_safe(tool, "coroutine", wrapped_coro)

    _setattr_safe(tool, "_agt_wrapped", True)


def _setattr_safe(obj: Any, name: str, value: Any) -> None:
    """``setattr`` that swallows errors from frozen pydantic models, etc."""
    try:
        setattr(obj, name, value)
    except Exception:
        # Some pydantic v2 frozen tools reject normal setattr. Last resort:
        try:
            object.__setattr__(obj, name, value)
        except Exception:
            pass
