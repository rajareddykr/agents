# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""LangChain adapter for the new ``create_agent`` middleware API.

Use this when your code looks like:

    from langchain.agents import create_agent
    from agt_sdk.langchain import GovernanceMiddleware

    agent = create_agent(llm, tools=tools, middleware=[GovernanceMiddleware()])

For the older ``AgentExecutor`` API, use :func:`governed` to wrap an
existing executor.

This adapter mirrors the hand-rolled ``GovernanceMiddleware`` pattern from
``langchain-ui-agent/governance.py`` so that customers don't have to write
500 lines of policy-fetch / decision-push glue.
"""

from __future__ import annotations

import asyncio
from typing import Any

try:
    from langchain.agents.middleware.types import AgentMiddleware, ToolCallRequest
    from langchain_core.messages import ToolMessage
except ImportError as exc:    # pragma: no cover - import guard
    raise ImportError(
        "agt_sdk.langchain requires langchain>=0.3 with the create_agent middleware API. "
        "Install with: pip install 'agt-sdk[langchain]'"
    ) from exc

from agt_sdk._async import run_async as _run_async
from agt_sdk._kernel import AutoKernel


class GovernanceMiddleware(AgentMiddleware):
    """Middleware that runs every tool call through AGT governance.

    Drop into ``create_agent(llm, tools=..., middleware=[GovernanceMiddleware()])``
    and your agent inherits policy enforcement, decision logging, registration,
    and heartbeat with no other code changes.
    """

    def __init__(
        self,
        *,
        agent_id: str | None = None,
        policy_names: list[str] | None = None,
        extra_policies: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """Build the middleware. All config defaults come from env vars.

        Args:
            agent_id:        Override ``AGT_AGENT_ID``.
            policy_names:    Restrict to these named bundles.
            extra_policies:  Local policies merged on top of CP-fetched ones.
        """
        super().__init__()
        self._kernel = AutoKernel.instance()
        self._agent_id_override = agent_id
        self._policy_names = policy_names
        if extra_policies:
            self._kernel.add_policies(extra_policies)

    def wrap_tool_call(self, request: ToolCallRequest, handler):
        """LangChain calls this around every tool invocation.

        We run the AGT check synchronously (the inner kernel.check is async,
        so we run it on a fresh event loop here — LangChain's middleware
        signature is sync-only as of langchain 0.3).
        """
        tool_name = request.tool_call.get("name", "unknown")
        tool_id = request.tool_call.get("id", "unknown")
        tool_args = request.tool_call.get("args", {}) or {}

        # Fast path: governance disabled — skip everything.
        if not self._kernel.enabled:
            return handler(request)

        result = _run_async(self._kernel.check(
            tool_name=tool_name,
            tool_args=tool_args,
            policy_names=self._policy_names,
        ))

        if result.allowed:
            return handler(request)

        return ToolMessage(
            content=f"[BLOCKED by AGT governance]: {result.reason}",
            tool_call_id=tool_id,
            name=tool_name,
            status="error",
        )


def governed(executor: Any) -> Any:
    """Wrap a legacy ``AgentExecutor`` so every tool callback is governed.

    Use only with the older LangChain ``AgentExecutor`` API. New code
    should use :class:`GovernanceMiddleware` with ``create_agent``.

    Args:
        executor: A LangChain ``AgentExecutor`` instance.

    Returns:
        The same executor with each ``tool.func`` / ``tool.coroutine`` swapped
        for a governance-wrapping callable.
    """
    kernel = AutoKernel.instance()
    if not kernel.enabled:
        return executor

    tools = getattr(executor, "tools", None)
    if not tools:
        return executor

    for t in tools:
        _wrap_tool_inplace(t, kernel)
    return executor


def _wrap_tool_inplace(tool: Any, kernel: AutoKernel) -> None:
    """Best-effort wrap of a LangChain tool's run/arun functions."""
    name = getattr(tool, "name", "") or tool.__class__.__name__

    orig_func = getattr(tool, "func", None)
    orig_coro = getattr(tool, "coroutine", None)

    if callable(orig_func):
        def wrapped_sync(*args, **kwargs):
            result = _run_async(kernel.check(
                tool_name=name,
                tool_args={"args": args, "kwargs": kwargs},
            ))
            if not result.allowed:
                return f"[BLOCKED by AGT governance]: {result.reason}"
            return orig_func(*args, **kwargs)
        tool.func = wrapped_sync

    if callable(orig_coro):
        async def wrapped_async(*args, **kwargs):
            result = await kernel.check(
                tool_name=name,
                tool_args={"args": args, "kwargs": kwargs},
            )
            if not result.allowed:
                return f"[BLOCKED by AGT governance]: {result.reason}"
            return await orig_coro(*args, **kwargs)
        tool.coroutine = wrapped_async


# _run_async is now imported from agt_sdk._async (shared with the CrewAI adapter
# and the @governed decorator).
