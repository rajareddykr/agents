# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Sync-from-async bridge.

Several framework adapters (LangChain middleware, CrewAI tools, the
``@governed`` decorator on sync functions) need to call the kernel's async
:meth:`AutoKernel.check` from a synchronous context. This module is the
single, well-tested place that handles the two cases:

  * No event loop running     → ``asyncio.run(coro)``
  * Event loop already running → execute the coro on a worker thread
                                 (``asyncio.run`` would raise
                                 ``RuntimeError: This event loop is already
                                 running``).
"""

from __future__ import annotations

import asyncio
import concurrent.futures
from collections.abc import Coroutine
from typing import Any, TypeVar

T = TypeVar("T")


def run_async(coro: Coroutine[Any, Any, T]) -> T:
    """Run *coro* to completion from a synchronous caller.

    Args:
        coro: An awaitable coroutine.

    Returns:
        The coroutine's return value.

    Raises:
        Whatever exceptions the coroutine raises.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    # Inside a running loop — execute on a worker thread to avoid
    # "RuntimeError: This event loop is already running".
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
        future = ex.submit(asyncio.run, coro)
        return future.result()
