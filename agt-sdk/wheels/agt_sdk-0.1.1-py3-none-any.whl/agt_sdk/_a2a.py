# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""IMPL-065 — the A2A initiator gate.

IMPL-032 absorbed the mesh **responder** into ``AutoKernel.instance()``. This is
the other half: deciding whether *this* agent may call a peer. Before it, every
initiator hand-wrote the protocol — 117 lines in the SDK's own example, 99 in a
customer's coordinator, where the pagination was omitted so peer resolution
silently truncated past 200 rows.

Two entry points over one gate:

* ``@peer_verified("name")`` — the primary surface, mirroring ``@governed``.
  Refusal raises, so the check cannot be forgotten.
* ``kernel.a2a_gate("name")`` — returns the verdict, for peers not known at
  import time (fan-out, capability selection, a name read from config).

**Resolution lives here, not on ``HTTPRegistryStore``.** That class is entirely
synchronous — ``httpx.Client``, ``def`` methods — so calling it from this async
gate would block the event loop for the duration of a CP round trip; in a
FastAPI-hosted coordinator that stalls every concurrent request. It also carries
no ``org_code`` and builds only unscoped URLs, so it cannot form
``/orgs/{org}/agents`` at all. With the CP-side ``name=`` filter now in place
resolution is a single exact-match request, so the resilience machinery that
class provides would be overkill for what this needs.

Why a NAME and not a DID: a DID is a rotating epoch credential. The SDK cannot
persist its private key, so every restart mints a new one and the previous epoch
is marked ``superseded``. An initiator that pins a peer DID breaks on that peer's
next restart. The name is the only stable handle.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# A CP agent row is a usable peer only if neither its lifecycle status nor its
# DID status marks it inactive. ``superseded`` = rotated out by a newer epoch;
# the CP refuses handshakes against it, so calling one is a guaranteed failure.
_INACTIVE = frozenset({"revoked", "suspended", "decommissioned", "superseded"})

# One edge per (peer name, peer DID, verdict) per process. The DID makes a
# peer's epoch rotation publish a fresh edge. The VERDICT makes a change of
# outcome publish one too: keying on (name, did) alone meant a peer allowed
# once and later refused — trust decayed below the bar — never published the
# refusal, so the CP showed a trusted edge for a peer we had stopped calling.
# Repeats of the same outcome are still collapsed, which is what the dedup is
# actually for.
_PUBLISHED: set[tuple[str, str, bool]] = set()


@dataclass(frozen=True)
class A2AVerdict:
    """Whether this agent may call ``peer_name``, and why.

    A plain dataclass on purpose: nothing from ``agentmesh`` appears in it, so a
    developer's type surface never reaches across the plane boundary.
    """

    allowed: bool
    peer_name: str
    peer_did: str | None = None
    trust_score: int | None = None
    reason: str = ""
    source: str = "gate"        # gate | mesh_off | unresolved | below_threshold


def _self_did(kernel: Any) -> str:
    """This agent's minted DID — not the name-like ``agent_id``."""
    return kernel.diagnostics().get("bootstrap_did") or kernel.config.agent_id


def _is_active(row: dict) -> bool:
    """Both status columns must be clear.

    ``current_status`` is ``agents.status``; ``current_did_status`` is the epoch
    state IMPL-064 writes ``superseded`` into. They mean different things and a
    peer is only usable when neither is inactive. Older CP builds expose
    ``status`` / ``did_status`` on the epochs view — accept whichever is present
    so the gate works against a control plane that predates the logical view.
    """
    status = (row.get("current_status") or row.get("status") or "active").lower()
    did_status = (row.get("current_did_status") or row.get("did_status") or "active").lower()
    return status not in _INACTIVE and did_status not in _INACTIVE


def _auth_headers(cfg: Any) -> dict[str, str]:
    """Gateway key + the agent's scoped CP token.

    Never the bootstrap token: it is single-use and already spent by the time a
    gate runs. Omitting the gateway key is what made five mesh call sites 401
    behind PGAIAuthGateway before the header fix.
    """
    h: dict[str, str] = {}
    if getattr(cfg, "gateway_api_key", ""):
        h["X-appsoc-api-key"] = cfg.gateway_api_key
    if getattr(cfg, "cp_token", ""):
        h["X-AGT-Token"] = cfg.cp_token
    return h


async def resolve_peer(kernel: Any, peer_name: str) -> dict | None:
    """Resolve a peer NAME to its current active epoch. ``None`` if unusable.

    One request. The CP-side ``name=`` filter (IMPL-065 step 1) makes this an
    exact match, so there is no paging, no page cap, and no client-side
    scanning — the three things the hand-written version got wrong.
    """
    import httpx

    cfg = kernel.config
    me = _self_did(kernel)
    url = f"{cfg.cp_url}/api/v1/orgs/{cfg.org_code}/agents"

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            url,
            params={"name": peer_name, "limit": 200},
            headers=_auth_headers(cfg),
        )
        r.raise_for_status()
        items = (r.json() or {}).get("items") or []

    for row in items:
        did = row.get("current_did") or row.get("did")
        if not did or did == me:
            continue                      # never gate against ourselves
        if row.get("name") != peer_name:
            continue                      # defensive: CP filters, we verify
        if not _is_active(row):
            logger.debug("a2a: peer %r epoch %s is inactive — skipping", peer_name, did)
            continue
        return {
            "did": did,
            "name": peer_name,
            "trust_score": int(row.get("trust_score") or 0),
        }
    return None


async def _publish(kernel: Any, peer_name: str, peer_did: str, result: Any,
                   *, allowed: bool) -> None:
    """Record the handshake as a Trust Graph edge.

    Fail-OPEN by design: publishing reports the decision, it never makes it. A
    publish error must not turn a trusted peer into a refused one.
    """
    key = (peer_name, peer_did, allowed)
    if key in _PUBLISHED:
        return
    try:
        await kernel.cp_handshake_publisher.publish_handshake(
            initiator_did=_self_did(kernel), transport="a2a", result=result,
        )
        _PUBLISHED.add(key)
    except Exception as exc:              # noqa: BLE001 — fail-open, deliberately
        logger.warning("a2a: handshake publish failed (ignored): %s", exc)


async def run_gate(kernel: Any, peer_name: str, *, min_trust: int | None = None) -> A2AVerdict:
    """Decide whether this agent may delegate to ``peer_name``.

    Fail-CLOSED on the decision: unknown, inactive, superseded or below-threshold
    is refused and the downstream call must not happen. Fail-OPEN on publication.

    Governance-only mode (no ``[mesh]`` extra, or no bootstrap token) allows and
    warns: there is no trust data to gate on, and refusing every delegation would
    make an optional extra load-bearing and break existing callers on upgrade.
    """
    cfg = kernel.config
    bar = cfg.a2a_min_trust if min_trust is None else min_trust

    if kernel.cp_handshake_publisher is None:
        logger.warning(
            "a2a: mesh off — delegation to %r is NOT gated. Install "
            "agt-sdk[mesh] and bootstrap the agent to enforce.", peer_name,
        )
        return A2AVerdict(True, peer_name, reason="mesh off — not gated", source="mesh_off")

    try:
        peer = await resolve_peer(kernel, peer_name)
    except Exception as exc:              # noqa: BLE001 — fail-closed
        if cfg.a2a_fail_mode == "open":
            logger.warning(
                "a2a: peer lookup for %r failed and AGT_A2A_FAIL_MODE=open — "
                "ALLOWING UNGATED: %r", peer_name, exc,
            )
            return A2AVerdict(True, peer_name, reason=f"lookup failed, fail-open: {exc!r}",
                              source="unresolved")
        return A2AVerdict(False, peer_name, reason=f"peer lookup failed: {exc!r}",
                          source="unresolved")

    if peer is None:
        return A2AVerdict(False, peer_name,
                          reason=f"peer {peer_name!r} not registered, not active, or superseded",
                          source="unresolved")

    # Imported HERE, not at module scope: agt_sdk must remain importable without
    # the [mesh] extra. This is the plane boundary the example had to violate.
    from agentmesh.trust.handshake import HandshakeResult

    did, trust = peer["did"], peer["trust_score"]
    allowed = trust >= bar

    if allowed:
        reason = f"trust {trust} >= required {bar}"
        result = HandshakeResult.success(
            peer_did=did, trust_score=trust,
            capabilities=["read", "search"], peer_name=peer_name,
        )
    else:
        reason = f"trust {trust} < required {bar}"
        result = HandshakeResult.failure(did, reason)

    # Published either way — a REFUSED handshake must be visible in the CP, not
    # merely logged locally.
    await _publish(kernel, peer_name, did, result, allowed=allowed)

    return A2AVerdict(allowed, peer_name, did, trust, reason,
                      "gate" if allowed else "below_threshold")
