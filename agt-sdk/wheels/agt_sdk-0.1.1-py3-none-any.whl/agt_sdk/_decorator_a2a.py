# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""``@peer_verified`` — IMPL-065's primary surface.

The mesh counterpart to ``@governed``. Same shape on purpose: check before the
body runs, raise if refused. A2A should not be a second idiom.

    from agt_sdk import governed, peer_verified

    @governed(action="send_email")                    # policy → AGTBlocked
    async def send_email(to, subject): ...

    @peer_verified("Finance-AGENT-2", min_trust=600)  # mesh   → AGTPeerUntrusted
    async def request_invoice(invoice_id): ...

Why a decorator rather than only ``kernel.a2a_gate()``: the method leaves the
developer writing ``if not verdict.allowed`` at every delegation point, and a
check you must remember to write is one you can forget — the failure mode being
a silent ungated peer call, which is what this exists to prevent.

Use ``kernel.a2a_gate()`` directly when the peer is not known at import time.
"""
from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable
from typing import Any, TypeVar

from agt_sdk._kernel import AutoKernel
from agt_sdk.exceptions import AGTPeerUntrusted

F = TypeVar("F", bound=Callable[..., Any])


def peer_verified(
    peer_name: str,
    *,
    min_trust: int | None = None,
) -> Callable[[F], F]:
    """Gate a delegating function on the trustworthiness of ``peer_name``.

    Args:
        peer_name:  The peer's stable NAME. Not a DID — DIDs are per-epoch and
                    rotate on the peer's next restart.
        min_trust:  CP trust floor 0–1000. Defaults to ``AGT_A2A_MIN_TRUST``.
                    ``0`` is attested mode: identity is still fail-closed
                    (unknown / inactive / superseded peers are refused) but no
                    trust bar is applied.

    Returns:
        The decorated callable, signature unchanged. Async stays async, sync
        stays sync.

    Raises:
        AGTPeerUntrusted: when the peer may not be called. Carries the full
            :class:`~agt_sdk._a2a.A2AVerdict` on ``.verdict``.

    The decorated function's signature is deliberately **not** modified — no
    resolved peer is injected. ``@governed`` never changes a signature, and
    having the two decorators differ there is the surprise most likely to bite
    someone who has learned one of them. A body that needs the DID should call
    ``kernel.a2a_gate()`` itself.
    """
    def _decorate(fn: F) -> F:
        kernel = AutoKernel.instance()

        # Governance disabled entirely — the SDK is a pass-through, so the
        # decorator must be too. Matches @governed.
        if not kernel.enabled:
            return fn

        async def _gate() -> None:
            verdict = await kernel.a2a_gate(peer_name, min_trust=min_trust)
            if not verdict.allowed:
                raise AGTPeerUntrusted(verdict)

        if asyncio.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                await _gate()
                return await fn(*args, **kwargs)
            return async_wrapper        # type: ignore[return-value]

        @functools.wraps(fn)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Bridge to the async gate from sync context — same approach as
            # @governed, so behaviour is consistent between the two.
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                asyncio.run(_gate())
            else:
                # Already inside a loop: run on a worker thread so we neither
                # block it nor try to nest run().
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    pool.submit(asyncio.run, _gate()).result()
            return fn(*args, **kwargs)
        return sync_wrapper             # type: ignore[return-value]

    return _decorate
