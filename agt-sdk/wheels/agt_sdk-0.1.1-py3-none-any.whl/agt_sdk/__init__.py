# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""agt-sdk — zero-config wrapper SDK for AGT Pattern A.

Public API:

    from agt_sdk import AutoKernel, governed, AGTBlocked
    from agt_sdk.langgraph import GovernedToolNode
    from agt_sdk.langchain import GovernanceMiddleware

See README.md for the full developer guide.
"""

from __future__ import annotations

# Runtime compatibility patches for the currently-shipped agt-os-kernel.
# MUST run before any kernel import so environment-variable overrides + Pydantic
# schema relaxations are in effect before ``StatelessKernel`` is instantiated.
# Remove this line once the agt-os-kernel wheel ships the fixes upstream.
from agt_sdk import _kernel_compat as _kc
_kc.apply()
del _kc

from agt_sdk._kernel import AutoKernel
from agt_sdk.exceptions import AGTBlocked, AGTConfigurationError, AGTPeerUntrusted
from agt_sdk._decorator import governed
from agt_sdk._decorator_a2a import peer_verified  # noqa: E402
from agt_sdk._a2a import A2AVerdict  # noqa: E402
from agt_sdk import injection

__all__ = [
    "AutoKernel",
    "AGTBlocked",
    "AGTPeerUntrusted",
    "AGTConfigurationError",
    "governed",
    "peer_verified",
    "A2AVerdict",
    "injection",
]

__version__ = "0.1.1"
