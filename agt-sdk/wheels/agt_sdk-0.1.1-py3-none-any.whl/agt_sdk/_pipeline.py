# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Hot-path 4-stage tool-call evaluation pipeline.

Extracted from ``_kernel.py`` (IMPL-035 cleanup 1). Each tool call runs
through this pipeline; budget is < 0.1 ms for the allow path. Stage
order:

  1. Master kill switch — disabled → allow (no recording).
  2. Prompt-injection scanner (if enabled).
  3. Local safety baseline (if enabled).
  4. Policy evaluation via the kernel.

The pipeline holds a back-reference to its ``AutoKernel`` so each stage
can read config and write decisions through ``kernel._record(...)``.
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any

from agt_sdk._baseline import baseline_check
from agt_sdk import injection

if TYPE_CHECKING:
    from agt_sdk._kernel import AutoKernel, CheckResult

logger = logging.getLogger("agt_sdk.pipeline")


class CheckPipeline:
    """The hot-path 4-stage pipeline.

    Owns no state of its own; reads from and writes to the AutoKernel
    that constructed it. One instance per AutoKernel.
    """

    def __init__(self, kernel: "AutoKernel") -> None:
        self._k = kernel

    async def run(
        self,
        tool_name: str,
        tool_args: dict[str, Any] | None,
        policy_names: list[str] | None = None,
    ) -> "CheckResult":
        # Late import to avoid circular at module load time.
        from agt_sdk._kernel import CheckResult

        t0 = time.perf_counter()

        if not self._k._cfg.enabled:
            return CheckResult(allowed=True, source="noop")

        args = tool_args or {}
        try:
            args_repr = json.dumps(args, default=str)
        except Exception:
            args_repr = str(args)

        # 1. Injection scan
        if self._k._cfg.injection_scanner:
            finding = injection.scan(tool_name, args_repr)
            if finding:
                latency = (time.perf_counter() - t0) * 1000
                result = CheckResult(
                    allowed=False,
                    reason=f"Prompt injection detected: {finding.explanation}",
                    matched_rule="injection-scanner",
                    policy_name="local-safety-baseline",
                    latency_ms=latency,
                    source="injection",
                )
                self._k._record(tool_name, args_repr, result)
                return result

        # 2. Local safety baseline
        if self._k._cfg.local_safety_baseline:
            ok, reason = baseline_check(tool_name, args_repr)
            if not ok:
                latency = (time.perf_counter() - t0) * 1000
                result = CheckResult(
                    allowed=False,
                    reason=reason,
                    matched_rule="local-safety-baseline",
                    policy_name="local-safety-baseline",
                    latency_ms=latency,
                    source="baseline",
                )
                self._k._record(tool_name, args_repr, result)
                return result

        # 2.5 Ensure the policy bundle is fresh even without a persistent async
        # refresh loop (sync / per-call agents). Re-fetch when the cache is older
        # than the TTL so a CP change — e.g. a kill-switch block-all bundle
        # served after suspension — takes effect on the next governed call.
        await self._k._maybe_refresh_policy()

        # 2.6 Kill switch — hard stop. When the applied bundle is the block-all
        # kill-switch policy (operator suspended this agent), deny every call
        # here, independent of the underlying kernel's rule evaluation.
        if self._k._kill_switch_engaged():
            latency = (time.perf_counter() - t0) * 1000
            result = CheckResult(
                allowed=False,
                reason="Kill switch active - all operations blocked by operator",
                matched_rule="kill-switch-deny-all",
                policy_name="kill-switch-block-all",
                latency_ms=latency,
                source="policy",
            )
            self._k._record(tool_name, args_repr, result)
            return result

        # 3. Policy evaluation
        if self._k._kernel is None:
            # Kernel didn't initialise (should be rare — only if agent-os import failed).
            # Treat as fail-open or fail-closed per config.
            latency = (time.perf_counter() - t0) * 1000
            if self._k._cfg.fail_mode == "closed":
                return CheckResult(
                    allowed=False,
                    reason="Governance kernel not initialised; fail_mode=closed",
                    source="policy",
                    latency_ms=latency,
                )
            return CheckResult(allowed=True, source="policy", latency_ms=latency)

        try:
            from agent_os.stateless import ExecutionContext
        except ImportError:
            logger.warning("agent_os not importable — fail mode = %s", self._k._cfg.fail_mode)
            return CheckResult(
                allowed=(self._k._cfg.fail_mode == "open"),
                reason="agent_os.stateless unavailable",
                source="policy",
            )

        ctx = ExecutionContext(
            agent_id=self._k._cfg.agent_id,
            policies=policy_names or list((self._k._kernel.policies or {}).keys()),
        )

        try:
            result = await self._k._kernel.execute(
                action=tool_name,
                params=args,
                context=ctx,
            )
        except Exception as exc:
            logger.warning(
                "kernel.execute raised: %s; fail_mode=%s", exc, self._k._cfg.fail_mode
            )
            return CheckResult(
                allowed=(self._k._cfg.fail_mode == "open"),
                reason=f"Governance check raised: {exc}",
                source="policy",
                latency_ms=(time.perf_counter() - t0) * 1000,
            )

        latency = (time.perf_counter() - t0) * 1000
        if result.success:
            check_result = CheckResult(allowed=True, source="policy", latency_ms=latency)
        else:
            check_result = CheckResult(
                allowed=False,
                reason=result.error or "Blocked by AGT policy",
                policy_name="cp-bundle",
                source="policy",
                latency_ms=latency,
            )
        self._k._record(tool_name, args_repr, check_result)
        return check_result
