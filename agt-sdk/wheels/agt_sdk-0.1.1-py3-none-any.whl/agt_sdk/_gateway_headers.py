# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""PGAIAuthGateway integration headers.

The SaaS platform fronts the control plane with PGAIAuthGateway, which
validates a per-tenant API key on every request before forwarding to
``aisec-agents-gov-core``. Without the key the gateway rejects the
request before it ever reaches the CP.

This module is the single place that knows about the gateway header
name. Every SDK HTTP call site merges the dict returned by
:func:`gateway_headers` into its outbound headers.

Behaviour:

* When ``cfg.gateway_api_key`` is empty (the default), the helper
  returns ``{}`` so direct-CP deployments (no gateway) keep working
  unchanged — same code runs in dev (no gateway) and prod (gateway on).
* When ``cfg.gateway_api_key`` is set, every outbound request carries
  ``X-appsoc-api-key: <key>``.

Header name
-----------
Hardcoded to ``X-appsoc-api-key`` — the contract negotiated with the
SaaS platform team. If the platform ever renames this header, change
the constant here and ship a new SDK release.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agt_sdk._config import SdkConfig


GATEWAY_API_KEY_HEADER = "X-appsoc-api-key"


def gateway_headers(cfg: "SdkConfig") -> dict[str, str]:
    """Return the extra headers required by the PGAIAuthGateway.

    Args:
        cfg: The SDK configuration. Only ``cfg.gateway_api_key`` is read.

    Returns:
        ``{"X-appsoc-api-key": <key>}`` when the key is set, else ``{}``. The
        empty dict is safe to splat into any header mapping
        (``{**existing, **gateway_headers(cfg)}``).
    """
    if not cfg.gateway_api_key:
        return {}
    return {
        GATEWAY_API_KEY_HEADER: cfg.gateway_api_key,
    }
