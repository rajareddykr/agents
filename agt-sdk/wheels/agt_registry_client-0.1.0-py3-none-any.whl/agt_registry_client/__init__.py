# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""agt-registry-client — resilient HTTP client for the wire-1.0 §11 AGT registry.

Implements ``agentmesh.registry.store.RegistryStore`` over HTTP with a
TTL cache + stale-while-revalidate + negative cache + circuit breaker.

Spec: ``docs/pg-specs/IMPL-040-cp-backed-registry-store.md`` §6
Plan: ``docs/pg-plans/Plan-IMPL-040.md`` Phase 3
"""
from agt_registry_client.http_store import HTTPRegistryStore
from agt_registry_client.observability import (
    DEFAULT_INTERVAL_SECONDS as METRICS_DEFAULT_INTERVAL_SECONDS,
    MetricsLogger,
    start_metrics_logger,
)
from agt_registry_client.types import AgentRecord

__all__ = [
    "HTTPRegistryStore",
    "AgentRecord",
    "MetricsLogger",
    "start_metrics_logger",
    "METRICS_DEFAULT_INTERVAL_SECONDS",
]
__version__ = "0.1.0"
