# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Periodic metric drain for :class:`HTTPRegistryStore` (IMPL-040 §6.8 / Phase 6).

The store exposes a stable ``metrics`` dict snapshot (counters, gauges,
p99). This module ships a thin async loop that reads that snapshot at a
configurable interval and emits it via the standard logging tree, so
operators can collect it from logs or hook a richer exporter without
forcing one on every consumer.

Two integration shapes:

* :func:`start_metrics_logger` — fire-and-forget. Schedules
  :meth:`MetricsLogger.run` on the running loop and returns the
  :class:`asyncio.Task` so callers can cancel on shutdown. Used by the
  SDK lifecycle when ``[mesh]`` is wired.
* :class:`MetricsLogger` — bring your own loop. Useful for tests and
  for embedding inside larger observability frameworks.

Failure model: any error reading metrics (e.g. registry handle was
already closed) is logged at WARNING and the loop continues. Cancellation
exits cleanly.

The plan (`Plan-IMPL-040.md` §6.1) anticipated OTLP integration via an
existing SDK exporter; that exporter doesn't exist downstream (the
IMPL-032.5 publishers POST JSON to dedicated CP endpoints, not OTLP).
Logging is the smallest useful step and leaves the OTLP hook open as a
follow-up: callers can pass ``on_snapshot`` to forward each snapshot to
any sink they want.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Any, Awaitable, Callable, Optional

from agt_registry_client.http_store import HTTPRegistryStore

logger = logging.getLogger(__name__)


# Default cadence matches the SDK drift sampler default — slow enough to
# be invisible in steady state, fast enough that a stuck breaker shows up
# within a minute.
DEFAULT_INTERVAL_SECONDS = 60.0


SnapshotCallback = Callable[[dict[str, Any]], Optional[Awaitable[None]]]


class MetricsLogger:
    """Periodic drain of :attr:`HTTPRegistryStore.metrics`.

    Parameters
    ----------
    registry:
        The store to observe. Held by reference; the logger doesn't own
        its lifecycle.
    interval_seconds:
        Wall-clock time between snapshots. Clamped to ``>= 1.0``.
    on_snapshot:
        Optional callback invoked with each snapshot. Sync or async. If
        the callback raises, the loop logs at WARNING and continues —
        an instrumentation bug must never poison the host process.
    log_level:
        Python ``logging`` level for the per-snapshot log line. Defaults
        to ``INFO`` so it's visible in normal operations.
    """

    def __init__(
        self,
        registry: HTTPRegistryStore,
        *,
        interval_seconds: float = DEFAULT_INTERVAL_SECONDS,
        on_snapshot: SnapshotCallback | None = None,
        log_level: int = logging.INFO,
    ) -> None:
        self._registry = registry
        self._interval = max(1.0, float(interval_seconds))
        self._on_snapshot = on_snapshot
        self._log_level = log_level
        self._stopped = asyncio.Event()

    async def run(self) -> None:
        """Sample → emit → sleep, until cancelled or :meth:`stop` fires."""
        logger.debug(
            "agt-registry-client: metrics logger starting (interval=%.1fs)",
            self._interval,
        )
        try:
            while not self._stopped.is_set():
                try:
                    snapshot = self._registry.metrics
                except Exception as exc:
                    logger.warning(
                        "agt-registry-client: metrics snapshot failed: %s", exc
                    )
                else:
                    logger.log(
                        self._log_level,
                        "agt_registry metrics: %s",
                        _compact(snapshot),
                    )
                    if self._on_snapshot is not None:
                        try:
                            result = self._on_snapshot(snapshot)
                            # ``inspect.isawaitable`` covers coroutines,
                            # asyncio Futures/Tasks, and any custom
                            # awaitable. The previous ``iscoroutine``
                            # check missed everything except a bare
                            # ``async def`` call, so a callback that
                            # returned e.g. ``asyncio.ensure_future(...)``
                            # would be silently dropped.
                            if inspect.isawaitable(result):
                                await result
                        except Exception as exc:
                            logger.warning(
                                "agt-registry-client: metrics callback raised "
                                "(ignored): %s",
                                exc,
                            )
                try:
                    await asyncio.wait_for(
                        self._stopped.wait(), timeout=self._interval
                    )
                except asyncio.TimeoutError:
                    continue  # Normal wake-up; loop again.
        except asyncio.CancelledError:
            logger.debug("agt-registry-client: metrics logger cancelled")
            raise

    def stop(self) -> None:
        """Signal the loop to exit on its next wakeup."""
        self._stopped.set()


def start_metrics_logger(
    registry: HTTPRegistryStore,
    *,
    interval_seconds: float = DEFAULT_INTERVAL_SECONDS,
    on_snapshot: SnapshotCallback | None = None,
    log_level: int = logging.INFO,
) -> Optional[asyncio.Task]:
    """Schedule a :class:`MetricsLogger` on the running event loop.

    Returns the created :class:`asyncio.Task`, or ``None`` if there's no
    running loop (caller should fall back to creating one or skip
    metrics — mirrors the SDK's drift-sampler pattern).
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.debug(
            "agt-registry-client: no running event loop; metrics logger not "
            "scheduled (caller can construct MetricsLogger and run it later)"
        )
        return None

    drainer = MetricsLogger(
        registry,
        interval_seconds=interval_seconds,
        on_snapshot=on_snapshot,
        log_level=log_level,
    )
    return loop.create_task(drainer.run())


def _compact(snapshot: dict[str, Any]) -> str:
    """Render a snapshot for a single log line.

    Stable ordering for grep-ability; floats trimmed to one decimal so
    the line doesn't wrap unnecessarily.
    """
    parts: list[str] = []
    for key in sorted(snapshot):
        value = snapshot[key]
        if isinstance(value, dict):
            inner = ",".join(f"{k}={v}" for k, v in sorted(value.items()))
            parts.append(f"{key}={{{inner}}}")
        elif isinstance(value, float):
            parts.append(f"{key}={value:.1f}")
        else:
            parts.append(f"{key}={value}")
    return " ".join(parts)
