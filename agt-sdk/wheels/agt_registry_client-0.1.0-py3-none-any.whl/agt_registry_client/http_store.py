# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""`HTTPRegistryStore` — wire-1.0 §11 client with cache + breaker.

Spec: ``docs/pg-specs/IMPL-040-cp-backed-registry-store.md`` §6
Plan: ``docs/pg-plans/Plan-IMPL-040.md`` Phase 3

Implements the upstream ``agentmesh.registry.store.RegistryStore``
Protocol *structurally* over HTTP. Synchronous because the upstream
Protocol declares sync methods; the SDK that consumes this lives in
its own daemon-thread event loop (IMPL-038) so blocking HTTP doesn't
stall caller asyncio loops.

Resilience contract
-------------------
Per the spec §6.1–§6.6:

* L1 TTL+stale-while-revalidate LRU (positive cache).
* 30-second negative cache for 404s.
* Circuit breaker — 5 consecutive failures → 30s cooldown.
* 100 ms per-call timeout, 1 retry on transient failure.
* Fail-degraded: known peers served from stale cache during outages;
  unknown peers return ``None`` (caller decides).

What counts as a "transient failure" for retry / breaker purposes:
HTTP 5xx, connection errors, read/write timeouts. NOT 4xx — 404 means
"the CP gave a definitive negative answer", which we propagate as None.
"""
from __future__ import annotations

import base64
import logging
import random
import time
from collections import Counter, deque
from datetime import datetime, timezone
from typing import Any, Callable, Iterable

import httpx

from agentmesh.registry.store import AgentRecord

from agt_registry_client.breaker import BreakerState, CircuitBreaker
from agt_registry_client.cache import LRUCache, NegativeCache

logger = logging.getLogger("agt_registry_client")


# ── Defaults (per spec §6) ──────────────────────────────────────────────────

DEFAULT_TIMEOUT_MS = 100              # per-call HTTP timeout
DEFAULT_CACHE_TTL_SECONDS = 900       # 15 min — matches TrustHandshake.DEFAULT_CACHE_TTL_SECONDS
DEFAULT_STALE_WINDOW_SECONDS = 14400  # 4 h — fail-degraded window
DEFAULT_NEGATIVE_CACHE_SECONDS = 30
DEFAULT_BREAKER_THRESHOLD = 5
DEFAULT_BREAKER_COOLDOWN_SECONDS = 30
DEFAULT_MAX_CACHE_ENTRIES = 1000
DEFAULT_NEGATIVE_CACHE_ENTRIES = 200
DEFAULT_RETRY_BUDGET = 1              # one retry on transient failure


class HTTPRegistryStore:
    """``RegistryStore``-Protocol-shaped client over httpx.

    Constructed once per SDK / consumer; reused across many calls. Caller
    is responsible for calling :meth:`close` (or using as a context
    manager) to release the underlying httpx.Client.
    """

    def _auth_header(self) -> dict[str, str] | None:
        """Per-request token override (IMPL-078). None = the client's baked
        header stands (no provider, or the provider failed/returned empty —
        a rotation convenience must never break peer verification)."""
        provider = self._token_provider
        if provider is None:
            return None
        try:
            token = provider() or ""
        except Exception:  # noqa: BLE001
            return None
        if not token:
            return None
        return {"X-AGT-Token": token, **self._extra_headers}

    def __init__(
        self,
        base_url: str,
        api_token: str,
        *,
        timeout_ms: int = DEFAULT_TIMEOUT_MS,
        cache_ttl_seconds: float = DEFAULT_CACHE_TTL_SECONDS,
        stale_window_seconds: float = DEFAULT_STALE_WINDOW_SECONDS,
        negative_cache_seconds: float = DEFAULT_NEGATIVE_CACHE_SECONDS,
        breaker_failure_threshold: int = DEFAULT_BREAKER_THRESHOLD,
        breaker_cooldown_seconds: float = DEFAULT_BREAKER_COOLDOWN_SECONDS,
        max_cache_entries: int = DEFAULT_MAX_CACHE_ENTRIES,
        negative_cache_entries: int = DEFAULT_NEGATIVE_CACHE_ENTRIES,
        retry_budget: int = DEFAULT_RETRY_BUDGET,
        transport: httpx.BaseTransport | None = None,
        extra_headers: dict[str, str] | None = None,
        token_provider: Callable[[], str] | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        if not api_token:
            raise ValueError("api_token is required")
        self._base_url = base_url.rstrip("/")
        self._token = api_token
        self._extra_headers = dict(extra_headers or {})
        # IMPL-078: read at REQUEST time for the token to present; the baked
        # client header (api_token, still required) is the fallback. Peer
        # lookups are how A2A verification works — under a rotated-credential
        # regime this keeps them on the freshest token without reconstruction.
        self._token_provider = token_provider
        self._timeout_seconds = timeout_ms / 1000.0
        self._retry_budget = max(0, retry_budget)

        self._cache: LRUCache[AgentRecord] = LRUCache(
            max_entries=max_cache_entries,
            ttl_seconds=cache_ttl_seconds,
            stale_window_seconds=stale_window_seconds,
        )
        self._neg_cache = NegativeCache(
            max_entries=negative_cache_entries,
            ttl_seconds=negative_cache_seconds,
        )
        self._breaker = CircuitBreaker(
            failure_threshold=breaker_failure_threshold,
            cooldown_seconds=breaker_cooldown_seconds,
        )
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=httpx.Timeout(self._timeout_seconds),
            headers={"X-AGT-Token": self._token, **self._extra_headers},
            transport=transport,
        )

        # Observability counters. Exported as a dict via the `metrics`
        # property; consumers can drain via the MetricsLogger callback
        # (see observability.py for the integration shape).
        self._counters: Counter[str] = Counter()
        # Bounded rolling window of per-call latencies. A list grew
        # without bound in a long-lived process and made every `metrics`
        # snapshot an O(n log n) sort. The cap is generous enough that
        # p99 stays meaningful across the recent traffic burst without
        # keeping forever-old samples that no operator cares about.
        self._latencies_ms: deque[float] = deque(maxlen=2048)

    # ── Lifecycle ───────────────────────────────────────────────────────────

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> HTTPRegistryStore:
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

    # ── Protocol methods ────────────────────────────────────────────────────

    def get_agent(self, did: str) -> AgentRecord | None:
        """Look up an agent. Cache-first; fall back to CP; fail-degraded on outage."""
        # Negative cache absorbs hostile / repeated 404s.
        if self._neg_cache.is_recent_miss(did):
            self._inc("agt_registry_lookup_total", result="miss_404")
            return None

        cached = self._cache.get(did)
        if cached is not None and cached.fresh:
            self._inc("agt_registry_lookup_total", result="hit_fresh")
            return cached.value

        # Cache miss or stale entry. Try the CP unless the breaker is open.
        if not self._breaker.allow():
            if cached is not None:
                # OPEN breaker + stale entry: serve stale to keep known peers alive.
                self._inc("agt_registry_lookup_total", result="hit_stale_breaker_open")
                self._inc("agt_registry_stale_serves_total")
                return cached.value
            self._inc("agt_registry_lookup_total", result="miss_cp_unavailable")
            self._inc("agt_registry_cp_failures_total", cause="breaker_open")
            return None

        ok, record, status = self._try_get(did)
        if ok:
            self._cache.put(did, record)  # type: ignore[arg-type]
            self._inc("agt_registry_lookup_total", result="miss_cp_ok")
            return record
        # CP gave a definitive 404 → negative cache, propagate None.
        if status == 404:
            self._neg_cache.remember_miss(did)
            self._inc("agt_registry_lookup_total", result="miss_404")
            return None
        # Transient failure. Serve stale if we have it.
        if cached is not None:
            self._inc("agt_registry_lookup_total", result="hit_stale")
            self._inc("agt_registry_stale_serves_total")
            return cached.value
        self._inc("agt_registry_lookup_total", result="miss_cp_unavailable")
        return None

    def put_agent(self, record: AgentRecord) -> None:
        """Register or update an agent.

        Mapped to the CP's existing ``POST /api/v1/agents`` register
        endpoint (see ``app/routers/agents.py:register_agent``). Cache
        and negative cache are invalidated on success so the next read
        sees the new state.
        """
        body = {
            "agent_id": record.did,
            "name": record.metadata.get("name") or record.did,
            "description": record.metadata.get("description") or "",
            "did": record.did,
            "public_key": base64.b64encode(record.public_key).decode() if record.public_key else None,
            "capabilities": list(record.capabilities),
            "agent_type": record.metadata.get("agent_type") or "unknown",
            "organization": record.metadata.get("organization") or "",
            "sponsor_email": record.metadata.get("sponsor_email"),
            "source": "registry_client",
        }
        self._call_with_retry("POST", "/api/v1/agents", json=body)
        self._cache.invalidate(record.did)
        self._neg_cache.forget(record.did)

    def delete_agent(self, did: str) -> bool:
        """Soft-revoke an agent via the wire-1.0 ``DELETE /agents/{did}``."""
        ok, _payload, status = self._call_with_retry(
            "DELETE", f"/api/v1/agents/{did}"
        )
        if ok:
            self._cache.invalidate(did)
            self._neg_cache.remember_miss(did)
            return True
        if status == 404:
            return False
        # Transient outage during a delete — propagate as False; caller
        # may want to retry. We do NOT poison the cache here.
        return False

    def search_by_capability(self, capability: str, limit: int = 50) -> list[AgentRecord]:
        """Wire-1.0 ``GET /discover``. No cache (could be wired later)."""
        ok, payload, _status = self._call_with_retry(
            "GET",
            "/api/v1/discover",
            params={"capability": capability, "limit": limit},
        )
        if not ok or payload is None:
            return []
        items = payload.get("data") or []
        records: list[AgentRecord] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            record = _record_from_wire(item)
            if record is not None:
                records.append(record)
        return records

    def consume_one_time_key(self, did: str) -> dict[str, Any] | None:
        """Wire-1.0 ``GET /agents/{did}/prekeys``.

        v1 server returns 501 (pre-keys deferred per IMPL-040 §10 Open Q
        #1). We treat that as ``None`` (no OPK available) so callers fall
        back to 3-DH per wire-1.0 §11.3.
        """
        return None

    def update_last_seen(self, did: str) -> None:
        """Unconditional last-seen refresh. Maps to the throttled wire
        endpoint with ``min_interval_seconds=0``."""
        self._call_with_retry(
            "POST",
            f"/api/v1/agents/{did}/last-seen",
            json={"min_interval_seconds": 0.0},
        )
        self._cache.invalidate(did)

    def try_update_last_seen(self, did: str, min_interval_seconds: float = 10.0) -> bool:
        """Wire-1.0 ``POST /agents/{did}/last-seen`` with throttle."""
        ok, payload, _status = self._call_with_retry(
            "POST",
            f"/api/v1/agents/{did}/last-seen",
            json={"min_interval_seconds": min_interval_seconds},
        )
        if not ok or payload is None:
            return False
        data = payload.get("data") or {}
        updated = bool(data.get("updated"))
        if updated:
            self._cache.invalidate(did)
        return updated

    # ── Observability ───────────────────────────────────────────────────────

    @property
    def metrics(self) -> dict[str, Any]:
        """Snapshot of metrics. Returned shape is stable; counters reset
        only when the client is reconstructed."""
        return {
            "agt_registry_lookup_total":         dict(_counter_by_prefix(self._counters, "agt_registry_lookup_total")),
            "agt_registry_stale_serves_total":   int(self._counters.get("agt_registry_stale_serves_total", 0)),
            "agt_registry_cp_failures_total":    dict(_counter_by_prefix(self._counters, "agt_registry_cp_failures_total")),
            "agt_registry_breaker_state":        self._breaker.state.value,
            "agt_registry_p99_latency_ms":       _p99(self._latencies_ms),
            "agt_registry_cache_size":           len(self._cache),
            "agt_registry_negative_cache_size":  len(self._neg_cache),
        }

    # ── Internals ───────────────────────────────────────────────────────────

    def _try_get(self, did: str) -> tuple[bool, AgentRecord | None, int | None]:
        """Single GET for an agent. Returns (ok, record_or_none, status).

        On success: ``(True, record, 200)``.
        On 404:     ``(False, None, 404)``.
        On other:   ``(False, None, status_or_None)``.

        The full ``AgentRecord`` shape comes from ``/agents/{did}``
        (``AgentOut``). An earlier version of this method also fetched
        ``/agents/{did}/presence`` but never used the response — that
        extra round-trip on every cache miss was a hot-path regression
        and has been removed. If a future need surfaces ``presence`` as
        canonical, add an ``/agents/{did}/record`` endpoint and call
        that instead of a two-call dance.
        """
        ok, payload, status = self._call_with_retry(
            "GET", f"/api/v1/agents/{did}"
        )
        if not ok or payload is None:
            return False, None, status
        data = payload.get("data") or {}
        record = _record_from_agent_out(data)
        if record is None:
            return False, None, status
        return True, record, status

    def _call_with_retry(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
    ) -> tuple[bool, dict[str, Any] | None, int | None]:
        """One HTTP call with one retry on transient failure.

        Returns ``(ok, parsed_json, status)``. ``ok`` is True only on
        2xx. On 404, ``ok`` is False with ``status=404`` — caller
        decides whether 404 is acceptable. (An earlier version of this
        method took an ``allow_404`` parameter that did nothing; it has
        been removed so the signature matches behaviour.)
        """
        attempts = self._retry_budget + 1
        last_status: int | None = None
        for attempt in range(attempts):
            t0 = time.monotonic()
            try:
                resp = self._client.request(
                    method, path, json=json, params=params,
                    headers=self._auth_header(),
                )
            except (httpx.TimeoutException, httpx.ConnectError, httpx.ReadError, httpx.WriteError) as exc:
                self._latencies_ms.append((time.monotonic() - t0) * 1000.0)
                self._inc("agt_registry_cp_failures_total", cause="timeout_or_conn")
                logger.debug("CP request transport failure: %s", exc)
                if attempt < attempts - 1:
                    time.sleep(_jitter_backoff(attempt))
                    continue
                self._breaker.record_failure()
                return False, None, None

            self._latencies_ms.append((time.monotonic() - t0) * 1000.0)
            last_status = resp.status_code

            if 200 <= resp.status_code < 300:
                try:
                    payload = resp.json()
                except ValueError as exc:
                    # 2xx with unparseable JSON is a CP-side regression,
                    # not a successful response. Treat as transient: count
                    # against the budget, retry, and only trip the breaker
                    # when retries are exhausted. Returning ok=True with
                    # payload=None previously masked the regression and
                    # left callers fielding a silent partial response.
                    self._inc(
                        "agt_registry_cp_failures_total", cause="invalid_json"
                    )
                    logger.debug(
                        "CP %s %s returned 2xx but JSON parse failed: %s",
                        method, path, exc,
                    )
                    if attempt < attempts - 1:
                        time.sleep(_jitter_backoff(attempt))
                        continue
                    self._breaker.record_failure()
                    return False, None, resp.status_code
                self._breaker.record_success()
                return True, payload, resp.status_code

            if resp.status_code == 404:
                # Definitive negative answer — not a breaker-worthy failure.
                # We close the breaker on the first 4xx as well (the CP is healthy).
                self._breaker.record_success()
                return False, None, 404

            if 400 <= resp.status_code < 500:
                # Other 4xx — also not a transient outage. Don't retry, don't
                # trip the breaker. Caller sees ok=False with the status.
                self._breaker.record_success()
                return False, None, resp.status_code

            # 5xx: count as a failure; retry once.
            self._inc("agt_registry_cp_failures_total", cause="http_5xx")
            if attempt < attempts - 1:
                time.sleep(_jitter_backoff(attempt))
                continue
            self._breaker.record_failure()
            return False, None, resp.status_code

        # Unreachable; defensive.
        return False, None, last_status

    def _inc(self, name: str, **labels: str) -> None:
        if labels:
            label_key = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
            key = f"{name}#{label_key}"
        else:
            key = name
        self._counters[key] += 1


# ── Wire JSON ↔ AgentRecord ─────────────────────────────────────────────────


def _record_from_wire(data: dict[str, Any]) -> AgentRecord | None:
    """Parse the wire-1.0-shaped ``AgentRecordOut`` JSON returned by
    ``/discover`` and ``/agents/{did}/record`` (future).

    Returns ``None`` for malformed records — a single bad row in a
    ``/discover`` page must not crash ``search_by_capability`` for
    the whole result set. Callers filter the ``None``s out.
    """
    did = data.get("did")
    if not isinstance(did, str) or not did:
        logger.warning("agt-registry-client: skipping record with missing/invalid did: %r", data)
        return None
    pk_b64 = data.get("public_key_b64") or ""
    try:
        public_key = base64.b64decode(pk_b64, validate=True) if pk_b64 else b""
    except (ValueError, TypeError) as exc:
        # Malformed public_key — drop the record rather than substitute
        # arbitrary bytes that callers could misinterpret as a key. A
        # downstream signature check on bad bytes would fail loudly.
        logger.warning(
            "agt-registry-client: skipping record %s — public_key_b64 not valid base64 (%s)",
            did, exc,
        )
        return None
    try:
        reputation_score = float(data.get("reputation_score") or 0.5)
    except (TypeError, ValueError):
        reputation_score = 0.5
    return AgentRecord(
        did=did,
        public_key=public_key,
        capabilities=list(data.get("capabilities") or []),
        metadata=dict(data.get("metadata") or {}),
        registered_at=_parse_dt(data.get("registered_at")),
        last_seen=_parse_dt(data.get("last_seen")),
        reputation_score=reputation_score,
    )


def _record_from_agent_out(data: dict[str, Any]) -> AgentRecord | None:
    """Parse the CP-side ``AgentOut`` shape returned by ``/agents/{did}``.

    Fields mapped per IMPL-040 §5.2. Missing fields fall back to sensible
    defaults so partial responses don't crash the caller. Returns
    ``None`` if essential fields are missing or unparseable — caller
    decides how to surface that.
    """
    did = data.get("did") or data.get("agent_id")
    if not isinstance(did, str) or not did:
        logger.warning(
            "agt-registry-client: skipping AgentOut with no did/agent_id: %r",
            {k: data.get(k) for k in ("did", "agent_id", "name")},
        )
        return None
    pk_b64 = data.get("public_key") or ""
    try:
        public_key = base64.b64decode(pk_b64, validate=True) if pk_b64 else b""
    except (ValueError, TypeError) as exc:
        # Previously this fell back to ``pk_b64.encode("utf-8")`` —
        # which gave callers the bytes of the *base64 text* and
        # silently propagated invalid key material. Now: log and set
        # public_key=b"". Any signature verification against the empty
        # key will fail loudly downstream rather than mis-succeed.
        logger.warning(
            "agt-registry-client: %s — public_key not valid base64 (%s); "
            "setting empty key so downstream verification fails loud",
            did, exc,
        )
        public_key = b""
    return AgentRecord(
        did=did,
        public_key=public_key,
        capabilities=list(data.get("capabilities") or []),
        metadata={
            "name":             data.get("name") or "",
            "agent_type":       data.get("agent_type") or "",
            "organization":     data.get("organization") or "",
            **({"description": data["description"]} if data.get("description") else {}),
        },
        registered_at=_parse_dt(data.get("created_at")),
        last_seen=_parse_dt((data.get("lifecycle") or {}).get("last_heartbeat_at"))
                  if data.get("lifecycle") else _parse_dt(None),
        reputation_score=(
            ((data.get("trust") or {}).get("score") or 0) / 1000.0
            if data.get("trust") else 0.5
        ),
    )


def _parse_dt(value: str | None) -> datetime:
    if not value:
        return datetime.now(timezone.utc)
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return datetime.now(timezone.utc)


def _jitter_backoff(attempt: int) -> float:
    """20–80 ms jittered backoff. Bounded so retry stays inside the
    150 ms total wall-budget (per spec §6.5)."""
    base = 0.02 * (attempt + 1)
    return base + random.uniform(0, base)


def _p99(samples: Iterable[float]) -> float:
    s = sorted(samples)
    if not s:
        return 0.0
    idx = max(0, int(len(s) * 0.99) - 1)
    return s[idx]


def _counter_by_prefix(counters: Counter[str], prefix: str) -> Counter[str]:
    """Slice the flat counter by metric-name prefix, splitting on the
    `#labels` suffix into a sub-dict for the metrics output."""
    out: Counter[str] = Counter()
    for key, value in counters.items():
        if key == prefix:
            out["_total"] += value
        elif key.startswith(prefix + "#"):
            label_part = key.split("#", 1)[1]
            out[label_part] += value
    return out


# Suppress unused-import warning when state is exposed for introspection in tests.
_ = BreakerState
