# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Three-state circuit breaker for the CP HTTP path.

Spec: ``docs/pg-specs/IMPL-040-cp-backed-registry-store.md`` §6.4

States
------
* **CLOSED** — normal operation; all calls go to the CP.
* **OPEN** — after ``failure_threshold`` consecutive failures, the
  breaker rejects calls for ``cooldown_seconds``.
* **HALF_OPEN** — after the cooldown elapses, one probe is allowed.
  Success → CLOSED. Failure → OPEN (new cooldown).

What counts as a failure
------------------------
The caller decides. Typically: HTTP 5xx, connection error, timeout. NOT
4xx — a 404 means "ask the CP, it gave a definitive answer", not "CP is
sick". Treating 4xx as a breaker failure would suppress legitimate
negative answers.
"""
from __future__ import annotations

import enum
import threading
import time
from typing import Callable


class BreakerState(str, enum.Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe 3-state breaker.

    Single counter (``_consecutive_failures``) drives transitions when
    CLOSED. While OPEN, the time-of-trip determines when a HALF_OPEN
    probe is allowed.
    """

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        cooldown_seconds: float = 30.0,
        time_source: Callable[[], float] = time.monotonic,
    ) -> None:
        if failure_threshold <= 0:
            raise ValueError("failure_threshold must be positive")
        if cooldown_seconds < 0:
            raise ValueError("cooldown_seconds must be non-negative")
        self._threshold = failure_threshold
        self._cooldown = cooldown_seconds
        self._now = time_source
        self._lock = threading.Lock()
        self._state = BreakerState.CLOSED
        self._consecutive_failures = 0
        self._opened_at: float | None = None
        self._half_open_in_flight = False

    # ── Public state ────────────────────────────────────────────────────────

    @property
    def state(self) -> BreakerState:
        """Current breaker state. Reads OPEN→HALF_OPEN if the cooldown elapsed."""
        with self._lock:
            self._maybe_transition_to_half_open_locked()
            return self._state

    def allow(self) -> bool:
        """Return True if a call should be issued; False to short-circuit.

        At most one HALF_OPEN probe in flight at a time. Subsequent
        callers during HALF_OPEN are denied until the probe resolves.
        """
        with self._lock:
            self._maybe_transition_to_half_open_locked()
            if self._state is BreakerState.CLOSED:
                return True
            if self._state is BreakerState.HALF_OPEN and not self._half_open_in_flight:
                self._half_open_in_flight = True
                return True
            return False

    # ── Outcome reporting ───────────────────────────────────────────────────

    def record_success(self) -> None:
        with self._lock:
            self._half_open_in_flight = False
            self._consecutive_failures = 0
            self._state = BreakerState.CLOSED
            self._opened_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._half_open_in_flight = False
            self._consecutive_failures += 1
            # If we were probing (HALF_OPEN), one failure re-opens the breaker.
            if self._state is BreakerState.HALF_OPEN:
                self._state = BreakerState.OPEN
                self._opened_at = self._now()
                return
            if self._consecutive_failures >= self._threshold:
                self._state = BreakerState.OPEN
                self._opened_at = self._now()

    # ── Internals ───────────────────────────────────────────────────────────

    def _maybe_transition_to_half_open_locked(self) -> None:
        """Promote OPEN → HALF_OPEN if the cooldown has elapsed.

        Caller must hold ``self._lock``.
        """
        if self._state is not BreakerState.OPEN or self._opened_at is None:
            return
        if self._now() - self._opened_at >= self._cooldown:
            self._state = BreakerState.HALF_OPEN
            self._half_open_in_flight = False
