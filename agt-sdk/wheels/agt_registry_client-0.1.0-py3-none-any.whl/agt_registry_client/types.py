# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Type re-exports for ``agt_registry_client`` users.

Keeps the upstream ``agentmesh.registry.store.AgentRecord`` dataclass as
the canonical shape. Users don't need to depend on the upstream
``agentmesh-platform`` package directly — this re-export makes
``from agt_registry_client import AgentRecord`` the one obvious import.
"""
from agentmesh.registry.store import AgentRecord

__all__ = ["AgentRecord"]
