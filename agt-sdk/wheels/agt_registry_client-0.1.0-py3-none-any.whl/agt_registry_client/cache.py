# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Bounded TTL + stale-while-revalidate + negative cache.

Spec: ``docs/pg-specs/IMPL-040-cp-backed-registry-store.md`` §6.3

Two structures live here:

* :class:`LRUCache` — positive cache. An entry is **fresh** until the TTL
  elapses, then **stale** for an additional ``stale_window_seconds``, then
  evicted. :meth:`get` returns the entry along with its freshness flag so
  the caller can decide whether to refresh in the background.
* :class:`NegativeCache` — a tiny short-TTL cache of "we saw a 404 for
  this key recently". Absorbs hostile / malformed peer DIDs.

Both are thread-safe. Lock granularity is the whole cache — for our use
case (≤ 1000 entries, ≤ tens of QPS per agent) that's adequate; the
hot path is uncontended after a few seconds of warm-up.

Time source is injectable for tests. Production passes ``time.monotonic``.
"""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Callable, Generic, TypeVar

V = TypeVar("V")


@dataclass(frozen=True)
class CacheEntry(Generic[V]):
    """A value with its freshness state at read time.

    ``fresh`` is True when the entry was within the TTL window. Otherwise
    the entry is being served from the stale-while-revalidate window —
    valid to return but the caller should schedule a refresh.
    """

    value: V
    fresh: bool
    age_seconds: float


class LRUCache(Generic[V]):
    """Thread-safe bounded TTL+stale LRU.

    Eviction order: oldest-write-first when ``max_entries`` is reached.
    No LRU touch-on-read — read access doesn't change eviction priority,
    only writes do. Simplifies reasoning about cache state.
    """

    def __init__(
        self,
        *,
        max_entries: int,
        ttl_seconds: float,
        stale_window_seconds: float,
        time_source: Callable[[], float] = time.monotonic,
    ) -> None:
        if max_entries <= 0:
            raise ValueError("max_entries must be positive")
        if ttl_seconds < 0 or stale_window_seconds < 0:
            raise ValueError("ttl_seconds and stale_window_seconds must be non-negative")
        self._max = max_entries
        self._ttl = ttl_seconds
        self._stale = stale_window_seconds
        self._now = time_source
        self._lock = threading.RLock()
        # Insertion-ordered; oldest at the front when we hit max_entries.
        self._store: OrderedDict[str, tuple[V, float]] = OrderedDict()

    def get(self, key: str) -> CacheEntry[V] | None:
        """Return the entry if it exists and is within the stale window.

        Returns ``None`` for never-cached keys *and* for entries that have
        passed the combined TTL + stale window (effectively evicted on read).
        """
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, written_at = entry
            age = self._now() - written_at
            if age <= self._ttl:
                return CacheEntry(value=value, fresh=True, age_seconds=age)
            if age <= self._ttl + self._stale:
                return CacheEntry(value=value, fresh=False, age_seconds=age)
            # Past the stale window — evict lazily.
            del self._store[key]
            return None

    def put(self, key: str, value: V) -> None:
        """Insert or refresh an entry. Evicts the oldest write if at capacity."""
        with self._lock:
            if key in self._store:
                # Refresh in place; preserve insertion order for eviction.
                self._store[key] = (value, self._now())
                return
            while len(self._store) >= self._max:
                self._store.popitem(last=False)  # FIFO eviction
            self._store[key] = (value, self._now())

    def invalidate(self, key: str) -> bool:
        """Remove an entry. Returns True if it existed."""
        with self._lock:
            return self._store.pop(key, None) is not None

    def __len__(self) -> int:  # for tests / diagnostics
        with self._lock:
            return len(self._store)


class NegativeCache:
    """Short-TTL cache of "this key was 404 recently".

    Bounded — drops the oldest entry when full. Same time-source pattern
    as :class:`LRUCache`. Simpler API — booleans only.
    """

    def __init__(
        self,
        *,
        max_entries: int,
        ttl_seconds: float,
        time_source: Callable[[], float] = time.monotonic,
    ) -> None:
        if max_entries <= 0:
            raise ValueError("max_entries must be positive")
        if ttl_seconds < 0:
            raise ValueError("ttl_seconds must be non-negative")
        self._max = max_entries
        self._ttl = ttl_seconds
        self._now = time_source
        self._lock = threading.Lock()
        self._store: OrderedDict[str, float] = OrderedDict()

    def is_recent_miss(self, key: str) -> bool:
        with self._lock:
            written_at = self._store.get(key)
            if written_at is None:
                return False
            if self._now() - written_at <= self._ttl:
                return True
            del self._store[key]
            return False

    def remember_miss(self, key: str) -> None:
        with self._lock:
            if key in self._store:
                self._store[key] = self._now()
                return
            while len(self._store) >= self._max:
                self._store.popitem(last=False)
            self._store[key] = self._now()

    def forget(self, key: str) -> None:
        with self._lock:
            self._store.pop(key, None)

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)
