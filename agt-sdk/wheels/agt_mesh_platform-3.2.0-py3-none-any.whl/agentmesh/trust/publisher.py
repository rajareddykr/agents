# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Pushes verified mesh handshakes to the AGT control plane (IMPL-031).

Companion to ``agentmesh.reward.publisher.CPTrustPublisher`` — same
fail-open / explicit-caller-invocation pattern, different endpoint and
body shape.

The publisher is the wire layer only. The caller (typically the A2A
integration or trust-bridge consumer) invokes ``publish_handshake``
after each verified handshake; the publisher does not subscribe to any
internal mesh signal.

Wire contract::

    POST {cp_url}/api/v1/trust/handshakes/ingest
    Headers:
        X-AGT-Token: <api token with service role>
    Body:
        {
            "initiator_did": str,
            "peer_did":      str,
            "peer_name":     str | null,
            "transport":     "http" | "mcp" | "a2a",
            "verified":      bool,
            "trust_score":   float,
            "trust_level":   str,
            "capabilities":  [str, ...],
            "latency_ms":    float,
            "rejection_reason": str | null,
            "started_at":    ISO8601,
            "completed_at":  ISO8601 | null,
        }
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import httpx

from .._paths import api_v1_url
from .handshake import HandshakeResult

logger = logging.getLogger(__name__)


class CPHandshakePublisher:
    """Posts mesh-verified handshakes to the AGT CP ingest endpoint."""

    def __init__(
        self,
        cp_url: str,
        api_token: str,
        *,
        org_code: str = "",
        timeout: float = 5.0,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        self._cp_url = cp_url.rstrip("/")
        self._api_token = api_token
        self._extra_headers = dict(extra_headers or {})
        self._org_code = org_code
        self._timeout = timeout

    async def publish_handshake(
        self,
        initiator_did: str,
        transport: str,
        result: HandshakeResult,
    ) -> bool:
        """POST one handshake. Returns True on 2xx, False otherwise.

        Fail-open: any exception (network, JSON, etc.) is caught and
        logged; the caller is never blocked on publish.
        """
        url = api_v1_url(self._cp_url, "/trust/handshakes/ingest", self._org_code)
        body = self._build_body(initiator_did, transport, result)
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(
                    url,
                    json=body,
                    headers={"X-AGT-Token": self._api_token, **self._extra_headers},
                )
        except Exception as exc:
            logger.warning(
                "handshake publish failed for %s ↔ %s: %s",
                initiator_did, result.peer_did, exc,
            )
            return False

        if not (200 <= resp.status_code < 300):
            logger.warning(
                "handshake publish %s returned %s for %s ↔ %s",
                self._cp_url, resp.status_code, initiator_did, result.peer_did,
            )
            return False
        return True

    def _build_body(
        self,
        initiator_did: str,
        transport: str,
        result: HandshakeResult,
    ) -> dict[str, Any]:
        """Map HandshakeResult + caller context → CP ingest contract.

        Drops ``user_context`` — the CP HandshakeEvent model has no
        column for it. Maps ``handshake_started/_completed`` to
        ``started_at/completed_at`` to match CP naming.
        """
        started = result.handshake_started or datetime.now(timezone.utc)
        return {
            "initiator_did":    initiator_did,
            "peer_did":         result.peer_did,
            "peer_name":        result.peer_name,
            "transport":        transport,
            "verified":         result.verified,
            "trust_score":      float(result.trust_score),
            "trust_level":      result.trust_level,
            "capabilities":     list(result.capabilities),
            "latency_ms":       float(result.latency_ms or 0),
            "rejection_reason": result.rejection_reason,
            "started_at":       started.isoformat(),
            "completed_at":     result.handshake_completed.isoformat() if result.handshake_completed else None,
        }
