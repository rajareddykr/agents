# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""MCPHTTPProxy — containerised HTTP service for the AgentMesh MCP proxy.

This module exposes the MCPProxy governance logic over HTTP/JSON-RPC instead of
stdio, making it suitable for running as a long-lived Docker service.

Architecture:
  MCP client  ──POST /messages──►  MCPHTTPProxy (this service)
                                         │  policy check
                                         │  audit log
                                         ▼
                                  target MCP server (subprocess, stdin/stdout)

The target MCP subprocess is started once at service startup and kept alive.
Requests are serialised (one in-flight at a time) to match the subprocess's
sequential stdin→stdout contract.  This is correct for PoC and most production
workloads; concurrent-request support can be layered on later.

Usage (env-var driven, suitable for docker-compose):
  PROXY_TARGET        JSON array of the target command, e.g.:
                      '["npx","-y","@modelcontextprotocol/server-filesystem","/data"]'
  AGENTMESH_POLICY    strict | moderate | permissive  (default: strict)
  AGENTMESH_IDENTITY  proxy identity name             (default: mcp-proxy)
  PROXY_PORT          HTTP port to bind               (default: 9000)
  AGT_CP_URL          Control plane base URL
  AGT_CP_TOKEN        API token (agt_ prefix)
  AGT_AGENT_ID        Stable agent ID
  AGT_AGENT_NAME      Display name in the registry
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazily imported so the module is importable without fastapi installed.
# The actual FastAPI app is created in _build_app(), called from main().
# ---------------------------------------------------------------------------


def _parse_target_command() -> list[str]:
    """Read PROXY_TARGET env var (JSON array string) and return the command list."""
    raw = os.environ.get("PROXY_TARGET", "")
    if not raw:
        raise RuntimeError(
            "PROXY_TARGET env var is required, e.g.: "
            '\'["npx","-y","@modelcontextprotocol/server-filesystem","/data"]\''
        )
    try:
        cmd = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"PROXY_TARGET must be a JSON array, got: {raw!r}") from exc
    if not isinstance(cmd, list) or not cmd:
        raise RuntimeError("PROXY_TARGET must be a non-empty JSON array")
    return [str(c) for c in cmd]


class MCPHTTPProxy:
    """
    HTTP-transport variant of the AgentMesh MCP proxy.

    Manages a single target-MCP-server subprocess and routes JSON-RPC
    messages from HTTP clients through the policy and audit engines.
    """

    def __init__(
        self,
        target_command: list[str],
        policy: str = "strict",
        identity_name: str = "mcp-proxy",
        policy_server: str = "",
        policy_server_token: str = "",
        policy_refresh: int = 60,
        audit_sink: str = "",
        audit_sink_token: str = "",
    ) -> None:
        from agentmesh import PolicyEngine, AuditLog
        from agentmesh.identity import AgentIdentity

        self._target_command = target_command
        self._policy_level = policy
        self._identity_name = identity_name

        self.identity = AgentIdentity.create(
            name=identity_name, sponsor="proxy@agentmesh.ai", capabilities=["tool:*"]
        )
        self.policy_engine = PolicyEngine()
        self._load_policies(policy)
        self.audit_log = AuditLog()

        # Remote policy source
        self._policy_server = policy_server.rstrip("/") if policy_server else ""
        self._policy_server_token = policy_server_token
        self._policy_refresh = policy_refresh
        self._policy_fetched_at: float = 0.0
        self._remote_policy_loaded: bool = False

        # Remote audit sink
        self._audit_sink = audit_sink.rstrip("/") if audit_sink else ""
        self._audit_sink_token = audit_sink_token
        self._http_queue: asyncio.Queue = asyncio.Queue(maxsize=2000)
        self._flush_task: asyncio.Task | None = None

        self._process: asyncio.subprocess.Process | None = None
        self._lock = asyncio.Lock()   # one message in-flight at a time

    # ── Lifecycle ──────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Spawn the target MCP server subprocess."""
        from agentmesh.cli.proxy import MCPProxy as _UpstreamProxy
        _UpstreamProxy._validate_target_command(self._target_command)

        if self._policy_server:
            await self._fetch_remote_policies()
            logger.info("[http-proxy] Policy server enabled → %s", self._policy_server)

        if self._audit_sink:
            self._flush_task = asyncio.create_task(self._flush_audit())
            logger.info("[http-proxy] Audit sink enabled → %s", self._audit_sink)

        self._process = await asyncio.create_subprocess_exec(
            *self._target_command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        logger.info(
            "Target MCP server started (PID %d): %s",
            self._process.pid,
            " ".join(self._target_command),
        )

    async def stop(self) -> None:
        """Terminate the target subprocess gracefully."""
        if self._flush_task:
            self._flush_task.cancel()
            await asyncio.gather(self._flush_task, return_exceptions=True)
        if self._process and self._process.returncode is None:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self._process.kill()
                await self._process.wait()
            logger.info("Target MCP server stopped")

    # ── Remote policy + audit helpers ──────────────────────────────────────

    async def _refresh_policies_if_needed(self) -> None:
        if not self._policy_server:
            return
        import time
        if time.monotonic() - self._policy_fetched_at > self._policy_refresh:
            await self._fetch_remote_policies()

    async def _fetch_remote_policies(self) -> None:
        import time
        try:
            import httpx
        except ImportError:
            logger.warning("[http-proxy] httpx not installed — cannot fetch remote policies")
            return
        headers: dict[str, str] = {}
        if self._policy_server_token:
            headers["Authorization"] = f"Bearer {self._policy_server_token}"
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{self._policy_server}/api/v1/policies/bundle",
                    headers=headers,
                )
                resp.raise_for_status()
                bundle = resp.json()
                policies = bundle.get("policies", [])
                loaded = 0
                for pol in policies:
                    doc_yaml = pol.get("document_yaml") or pol.get("yaml")
                    if doc_yaml:
                        try:
                            self.policy_engine.load_yaml(doc_yaml)
                            loaded += 1
                        except Exception as exc:
                            logger.warning("[http-proxy] Could not load remote policy '%s': %s", pol.get("name"), exc)
                self._policy_fetched_at = time.monotonic()
                self._remote_policy_loaded = loaded > 0
                logger.info("[http-proxy] Fetched %d/%d policies from %s", loaded, len(policies), self._policy_server)
        except Exception as exc:
            logger.warning("[http-proxy] Remote policy fetch failed: %s — using %s", exc,
                           "remote-cached rules" if self._remote_policy_loaded else "local rules")

    async def _flush_audit(self) -> None:
        try:
            import httpx
        except ImportError:
            logger.warning("[http-proxy] httpx not installed — audit HTTP sink disabled")
            return
        async with httpx.AsyncClient(timeout=3.0) as client:
            while True:
                await asyncio.sleep(2.0)
                batch: list[dict] = []
                while not self._http_queue.empty() and len(batch) < 20:
                    batch.append(self._http_queue.get_nowait())
                if not batch:
                    continue
                try:
                    await client.post(
                        f"{self._audit_sink}/api/v1/audit/batch",
                        json={"entries": batch},
                        headers={"Content-Type": "application/json", "X-AGT-Token": self._audit_sink_token},
                    )
                except Exception as exc:
                    logger.debug("[http-proxy] Audit sink flush failed: %s", exc)

    # ── Message handling ───────────────────────────────────────────────────

    async def handle(self, message: dict[str, Any]) -> dict[str, Any]:
        """Route one JSON-RPC message through policy check → subprocess → response."""
        if not self._process or self._process.returncode is not None:
            return _error_response(message, -32603, "Proxy subprocess not running")

        # Policy enforcement
        if message.get("method") == "tools/call":
            await self._refresh_policies_if_needed()
            blocked_response = self._check_policy(message)
            if blocked_response:
                return blocked_response

        # Forward to target subprocess (one at a time)
        async with self._lock:
            try:
                payload = (json.dumps(message) + "\n").encode("utf-8")
                assert self._process.stdin is not None
                self._process.stdin.write(payload)
                await self._process.stdin.drain()

                assert self._process.stdout is not None
                raw = await asyncio.wait_for(
                    self._process.stdout.readline(), timeout=30.0
                )
                if not raw:
                    return _error_response(message, -32603, "Target subprocess closed stdout")
                return json.loads(raw.decode("utf-8").strip())
            except asyncio.TimeoutError:
                return _error_response(message, -32603, "Target subprocess timed out")
            except Exception as exc:
                logger.error("Error communicating with target subprocess: %s", exc)
                return _error_response(message, -32603, f"Proxy internal error: {exc}")

    # ── Policy helpers ─────────────────────────────────────────────────────

    def _load_policies(self, level: str) -> None:
        """Delegate to MCPProxy for policy loading — reuse without inheriting."""
        from agentmesh.cli.proxy import MCPProxy as _Up
        tmp = object.__new__(_Up)
        tmp.policy_level = level
        tmp.policy_engine = self.policy_engine
        tmp._load_default_policies()

    def _check_policy(self, message: dict[str, Any]) -> dict[str, Any] | None:
        """Return an error response dict if the tool call is blocked, else None."""
        params = message.get("params", {})
        tool_name = params.get("name", "unknown")
        arguments = params.get("arguments", {})
        context = {"action": {"tool": tool_name, "path": arguments.get("path", "")}}

        decision = self.policy_engine.evaluate(self.identity.did, context)

        self.audit_log.log(
            event_type="mcp_tool_call",
            agent_did=str(self.identity.did),
            action=tool_name,
            data={
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tool": tool_name,
                "decision": decision.action,
                "allowed": decision.allowed,
            },
            outcome="allowed" if decision.allowed else "denied",
        )

        # Non-blocking HTTP delivery to remote audit sink
        if self._audit_sink:
            http_entry = {
                "event_type": "policy_decision",
                "agent_did": str(self.identity.did),
                "action": tool_name,
                "outcome": "allowed" if decision.allowed else "denied",
                "data": {
                    "tool": tool_name,
                    "decision": decision.action,
                    "allowed": decision.allowed,
                    "matched_rule": getattr(decision, "matched_rule", None),
                    "adapter": "mcp_proxy_python_http",
                },
            }
            try:
                self._http_queue.put_nowait(http_entry)
            except asyncio.QueueFull:
                pass

        if not decision.allowed:
            logger.warning("BLOCKED: %s — %s", tool_name, decision.reason)
            return _error_response(
                message,
                -32001,
                f"Policy violation: {decision.reason}",
                data={
                    "blocked": True,
                    "policy": decision.policy_name,
                    "rule": decision.matched_rule,
                },
            )
        return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _error_response(
    message: dict[str, Any],
    code: int,
    text: str,
    data: dict | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"code": code, "message": text}
    if data:
        body["data"] = data
    return {"jsonrpc": "2.0", "id": message.get("id"), "error": body}


# ---------------------------------------------------------------------------
# FastAPI application
# ---------------------------------------------------------------------------

def _build_app(proxy: MCPHTTPProxy) -> Any:
    """Build and return the FastAPI application."""
    from fastapi import FastAPI, Request
    from fastapi.responses import JSONResponse

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Startup
        await proxy.start()
        cp_url   = os.environ.get("AGT_CP_URL", "")
        cp_token = os.environ.get("AGT_CP_TOKEN", "")
        agent_id = os.environ.get("AGT_AGENT_ID", "")
        agent_name = os.environ.get("AGT_AGENT_NAME", agent_id)
        if cp_url and cp_token and agent_id:
            from agentmesh.agt_cp.registration import register_with_cp
            await register_with_cp(
                url=cp_url,
                token=cp_token,
                agent_id=agent_id,
                agent_name=agent_name,
                source="mcp_proxy_python",
                did=str(proxy.identity.did),
                public_key=proxy.identity.public_key,
                verification_key_id=proxy.identity.verification_key_id,
                capabilities=["tool:*"],
            )
        yield
        # Shutdown
        await proxy.stop()

    app = FastAPI(
        title="AgentMesh MCP HTTP Proxy",
        description="Governance-enforcing HTTP proxy for MCP servers",
        version="1.0.0",
        lifespan=lifespan,
    )

    @app.get("/healthz")
    async def health():
        alive = proxy._process is not None and proxy._process.returncode is None
        status = "ok" if alive else "degraded"
        return {"status": status, "policy": proxy._policy_level}

    @app.post("/messages")
    async def messages(request: Request):
        """MCP JSON-RPC endpoint. Accepts a single message or a batch list."""
        body = await request.json()
        if isinstance(body, list):
            responses = [await proxy.handle(msg) for msg in body]
            return JSONResponse(content=responses)
        response = await proxy.handle(body)
        return JSONResponse(content=response)

    @app.get("/")
    async def info():
        return {
            "service": "agentmesh-mcp-http-proxy",
            "policy": proxy._policy_level,
            "target": proxy._target_command,
            "identity": str(proxy.identity.did),
        }

    return app


# ---------------------------------------------------------------------------
# Entrypoint  (python -m agentmesh.agt_cp.proxy_service)
# ---------------------------------------------------------------------------

def main() -> None:
    """Start the MCP HTTP proxy service. Reads all config from env vars."""
    import uvicorn

    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    target_command = _parse_target_command()
    policy         = os.environ.get("AGENTMESH_POLICY",            "strict")
    identity       = os.environ.get("AGENTMESH_IDENTITY",          "mcp-proxy")
    host           = os.environ.get("PROXY_HOST",                  "0.0.0.0")
    port           = int(os.environ.get("PROXY_PORT",              "9000"))
    policy_server  = os.environ.get("AGENTMESH_POLICY_SERVER_URL", "")
    policy_token   = os.environ.get("AGENTMESH_POLICY_SERVER_TOKEN", "")
    policy_refresh = int(os.environ.get("AGENTMESH_POLICY_REFRESH", "60"))
    audit_sink     = os.environ.get("AGENTMESH_AUDIT_COLLECTOR_URL", "")
    audit_token    = os.environ.get("AGENTMESH_CP_TOKEN",           "")

    proxy = MCPHTTPProxy(
        target_command,
        policy=policy,
        identity_name=identity,
        policy_server=policy_server,
        policy_server_token=policy_token,
        policy_refresh=policy_refresh,
        audit_sink=audit_sink,
        audit_sink_token=audit_token,
    )
    app = _build_app(proxy)

    logger.info("Starting MCP HTTP Proxy on %s:%d", host, port)
    logger.info("Target: %s", " ".join(target_command))
    logger.info("Policy: %s", policy)

    uvicorn.run(app, host=host, port=port, log_level=os.environ.get("LOG_LEVEL", "info").lower())


if __name__ == "__main__":
    main()
