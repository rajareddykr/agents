# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""AGT Control-Plane integration for AgentMesh — IMPL-012 Phase 2.

This sub-package is fully isolated from the upstream AgentMesh source so that
upstream merges never touch these files.  All AGT-specific additions live here.
"""
from agentmesh.agt_cp.registration import register_with_cp

__all__ = ["register_with_cp"]
