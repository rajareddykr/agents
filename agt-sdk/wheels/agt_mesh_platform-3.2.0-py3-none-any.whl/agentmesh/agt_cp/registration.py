# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Shared async function for registering any AGT agent with the control plane.

Used by the Python MCP proxy wrapper (Phase 2) and can be reused by any
future component that needs to POST an agent record to the AGT CP.
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def register_with_cp(
    url: str,
    token: str,
    agent_id: str,
    agent_name: str,
    source: str = "mcp_proxy_python",
    description: str = "",
    did: str | None = None,
    public_key: str | None = None,
    verification_key_id: str | None = None,
    capabilities: list | None = None,
) -> None:
    """POST an agent registration record to the AGT control plane.

    Best-effort: all network/auth errors are logged at WARNING and swallowed.
    The caller is never blocked by a registration failure.

    Args:
        url:                  Base URL of the control plane, e.g. http://localhost:8000
        token:                API token (agt_ prefix) with operator role.
        agent_id:             Stable, unique ID for this agent instance.
        agent_name:           Human-readable display name shown in the registry.
        source:               Registration source tag stored on the Agent record.
        description:          Optional free-text description.
        did:                  DID string from AgentIdentity (e.g. "did:mesh:abc123").
        public_key:           Base64-encoded Ed25519 public key.
        verification_key_id:  Key ID from AgentIdentity.
        capabilities:         List of capability strings.
    """
    try:
        import httpx
    except ImportError:
        logger.warning("httpx not installed — CP registration skipped. Install with: pip install httpx")
        return

    if not (url and token and agent_id):
        return

    payload: dict = {
        "agent_id":    agent_id,
        "name":        agent_name or agent_id,
        "description": description,
        "agent_type":  "mcp_proxy",
        "source":      source,
        "capabilities": capabilities or [],
    }
    if did:
        payload["did"] = did
    if public_key:
        payload["public_key"] = public_key
    if verification_key_id:
        payload["verification_key_id"] = verification_key_id

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{url.rstrip('/')}/api/v1/agents",
                json=payload,
                headers={"X-AGT-Token": token},
            )
        if not resp.is_success:
            logger.warning("CP registration returned HTTP %s for agent %s", resp.status_code, agent_id)
        else:
            logger.info("Registered agent %s (DID: %s) with CP (%s)", agent_id, did or "none", url)
    except Exception as exc:
        logger.warning("CP registration failed (non-blocking): %s", exc)
