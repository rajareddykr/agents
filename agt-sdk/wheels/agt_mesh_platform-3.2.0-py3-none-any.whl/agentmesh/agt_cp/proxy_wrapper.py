# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Click command 'proxy-cp' — wraps the upstream MCPProxy with AGT CP registration.

This file deliberately imports MCPProxy at call-time (not module-level) so that
the upstream proxy module can evolve without requiring changes here.  If the
upstream MCPProxy gains new __init__ parameters, add them to the forwarded kwargs
in _build_proxy() below.
"""
from __future__ import annotations

import asyncio
import os
import sys

import click


def _build_proxy(
    target: tuple,
    policy: str,
    no_footer: bool,
    identity: str,
    audit_sink: str = "",
    audit_sink_token: str = "",
    policy_server: str = "",
    policy_server_token: str = "",
    policy_refresh: int = 60,
):
    """Instantiate the upstream MCPProxy — isolated here for easy future patching."""
    from agentmesh.cli.proxy import MCPProxy
    return MCPProxy(
        target_command=list(target),
        policy=policy,
        identity_name=identity,
        enable_footer=not no_footer,
        audit_sink=audit_sink,
        audit_sink_token=audit_sink_token,
        policy_server=policy_server,
        policy_server_token=policy_server_token,
        policy_refresh=policy_refresh,
    )


@click.command("proxy-cp")
# ── Upstream MCPProxy options (mirrors cli/proxy.py exactly) ─────────────────
@click.option("--target", "-t", multiple=True, required=True,
              help="Target MCP server command (repeat for each arg)")
@click.option("--policy", "-p",
              type=click.Choice(["strict", "moderate", "permissive"]),
              default="strict", help="Policy enforcement level")
@click.option("--no-footer", is_flag=True, help="Disable verification footers")
@click.option("--identity", "-i", default="mcp-proxy", help="Agent identity name")
@click.option("--policy-server",
              default=lambda: os.environ.get("AGENTMESH_POLICY_SERVER_URL", ""),
              help="Fetch active policies from policy-server URL  [env: AGENTMESH_POLICY_SERVER_URL]")
@click.option("--policy-server-token",
              default=lambda: os.environ.get("AGENTMESH_POLICY_SERVER_TOKEN", ""),
              help="Bearer token for policy-server auth  [env: AGENTMESH_POLICY_SERVER_TOKEN]")
@click.option("--policy-refresh", default=60, type=int,
              help="Seconds between remote policy re-fetches (default: 60)")
@click.option("--audit-sink",
              default=lambda: os.environ.get("AGENTMESH_AUDIT_COLLECTOR_URL", ""),
              help="POST audit entries to this base URL  [env: AGENTMESH_AUDIT_COLLECTOR_URL]")
@click.option("--audit-sink-token",
              default=lambda: os.environ.get("AGENTMESH_CP_TOKEN", ""),
              help="X-AGT-Token header for audit-collector  [env: AGENTMESH_CP_TOKEN]")
# ── AGT Control-Plane registration options ───────────────────────────────────
@click.option("--cp-url",    envvar="AGT_CP_URL",    default="",
              help="AGT Control Plane base URL  [env: AGT_CP_URL]")
@click.option("--cp-token",  envvar="AGT_CP_TOKEN",  default="",
              help="API token (agt_ prefix) for the control plane  [env: AGT_CP_TOKEN]")
@click.option("--agent-id",  envvar="AGT_AGENT_ID",  default="",
              help="Stable agent ID to register  [env: AGT_AGENT_ID]")
@click.option("--agent-name", envvar="AGT_AGENT_NAME", default="",
              help="Display name in the registry  [env: AGT_AGENT_NAME]")
def proxy_cp(
    target: tuple,
    policy: str,
    no_footer: bool,
    identity: str,
    policy_server: str,
    policy_server_token: str,
    policy_refresh: int,
    audit_sink: str,
    audit_sink_token: str,
    cp_url: str,
    cp_token: str,
    agent_id: str,
    agent_name: str,
) -> None:
    """Start an AgentMesh MCP proxy with AGT Control Plane registration.

    Identical to 'agentmesh proxy' but also registers this proxy as an agent
    in the AGT Control Plane on startup so it appears in the agent registry.

    CP credentials can be passed as flags or via env vars:

    \b
      AGT_CP_URL     Control plane base URL
      AGT_CP_TOKEN   API token (agt_ prefix, operator role)
      AGT_AGENT_ID   Stable agent ID
      AGT_AGENT_NAME Display name in the registry

    Examples:

    \b
      # Using flags
      agentmesh proxy-cp --target npx --target -y \\
          --target @modelcontextprotocol/server-filesystem --target /Users/me \\
          --cp-url http://localhost:8000 --cp-token agt_xxx --agent-id my-proxy

    \b
      # Using env vars (zero extra flags)
      export AGT_CP_URL=http://localhost:8000
      export AGT_CP_TOKEN=agt_xxx
      export AGT_AGENT_ID=my-mcp-proxy
      agentmesh proxy-cp --target npx ...
    """
    if not list(target):
        click.echo("Error: --target is required", err=True)
        sys.exit(1)

    # Build the upstream proxy (unchanged behaviour)
    try:
        proxy_server = _build_proxy(
            target, policy, no_footer, identity,
            audit_sink=audit_sink,
            audit_sink_token=audit_sink_token,
            policy_server=policy_server,
            policy_server_token=policy_server_token,
            policy_refresh=policy_refresh,
        )
    except ValueError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)

    # Fire-and-forget CP registration before the proxy event loop starts
    resolved_id   = agent_id   or os.environ.get("AGT_AGENT_ID",   "")
    resolved_name = agent_name or os.environ.get("AGT_AGENT_NAME", resolved_id)
    resolved_url  = cp_url     or os.environ.get("AGT_CP_URL",   "")
    resolved_tok  = cp_token   or os.environ.get("AGT_CP_TOKEN", "")

    if resolved_url and resolved_tok and resolved_id:
        from agentmesh.agt_cp.registration import register_with_cp
        asyncio.run(register_with_cp(
            url=resolved_url,
            token=resolved_tok,
            agent_id=resolved_id,
            agent_name=resolved_name,
            source="mcp_proxy_python",
            did=str(proxy_server.identity.did),
            public_key=proxy_server.identity.public_key,
            verification_key_id=proxy_server.identity.verification_key_id,
            capabilities=["tool:*"],
        ))

    # Hand off to the upstream proxy event loop
    try:
        asyncio.run(proxy_server.start())
    except KeyboardInterrupt:
        sys.exit(0)
