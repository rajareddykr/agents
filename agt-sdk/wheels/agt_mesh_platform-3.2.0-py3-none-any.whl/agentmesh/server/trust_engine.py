# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""
Trust Engine Server

Validates agent identity and issues trust tokens via IATP handshakes.
Wraps agentmesh.trust (TrustHandshake, TrustBridge, CapabilityRegistry).
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

import httpx

from fastapi import HTTPException
from pydantic import BaseModel, Field

from agentmesh.identity.agent_id import AgentDID, AgentIdentity, IdentityRegistry
from agentmesh.server import create_base_app, run_server
from agentmesh.trust.capability import CapabilityRegistry
from agentmesh.trust.handshake import HandshakeChallenge, HandshakeResponse, TrustHandshake

logger = logging.getLogger(__name__)

# ── Control-plane registry bridge (IMPL-002) ─────────────────────────────────
_CP_URL   = os.getenv("AGENTMESH_CP_URL",   "").strip()
_CP_TOKEN = os.getenv("AGENTMESH_CP_TOKEN", "").strip()
_CP_HEADERS = {"X-AGT-Token": _CP_TOKEN, "Content-Type": "application/json"}
_cp_client: httpx.AsyncClient | None = None  # shared client; created at startup

app = create_base_app(
    "trust-engine",
    "Validates agent identity and issues trust tokens via IATP handshakes.",
)

# Shared state — initialised at startup
registry = IdentityRegistry()
capability_registry = CapabilityRegistry()
# In-memory challenge store (fallback when Redis not configured)
_pending_challenges_mem: dict[str, tuple[TrustHandshake, HandshakeChallenge]] = {}
# Redis trust state provider — set in startup if AGENTMESH_REDIS_URL is configured
_redis: Any = None  # RedisTrustStateProvider | None


@app.on_event("startup")
async def _startup() -> None:
    global _redis
    redis_url = os.environ.get("AGENTMESH_REDIS_URL", "").strip()
    if not redis_url:
        logger.info("AGENTMESH_REDIS_URL not set — trust state is ephemeral (in-memory only)")
        return
    try:
        import redis.asyncio as aioredis
        from agentmesh.storage.trust_state_provider import RedisTrustStateProvider
        client = aioredis.from_url(redis_url, decode_responses=True)
        _redis = RedisTrustStateProvider(client)
        await _seed_registry_from_redis(registry, _redis)
        logger.info("Trust state loaded from Redis (%s)", redis_url)
    except Exception as exc:
        logger.warning("Redis init failed (%s) — running ephemeral: %s", redis_url, exc)
        _redis = None


async def _seed_registry_from_redis(reg: IdentityRegistry, provider: Any) -> None:
    identities = await provider.all_identities()
    loaded = 0
    for identity_dict in identities:
        try:
            identity = AgentIdentity(**identity_dict)
            reg.register(identity)
            loaded += 1
        except Exception as exc:
            logger.warning("Skipped invalid identity from Redis: %s", exc)
    logger.info("Seeded %d identities from Redis", loaded)


@app.on_event("startup")
async def _startup_cp_bridge() -> None:
    global _cp_client
    if _CP_URL and _CP_TOKEN:
        _cp_client = httpx.AsyncClient(timeout=5.0)
        logger.info("CP registry bridge enabled → %s", _CP_URL)
    else:
        logger.info("CP registry bridge disabled (set AGENTMESH_CP_URL + AGENTMESH_CP_TOKEN)")


@app.on_event("shutdown")
async def _shutdown_cp_bridge() -> None:
    if _cp_client:
        await _cp_client.aclose()


async def _cp_register(did: str, identity: "AgentIdentity") -> None:
    """Fire-and-forget: push new agent to control-plane registry after DID creation."""
    if not _cp_client:
        return
    try:
        await _cp_client.post(
            f"{_CP_URL}/api/v1/agents",
            json={
                "agent_id":      str(did),
                "name":          identity.name,
                "description":   identity.description or "",
                "sponsor_email": identity.sponsor_email,
                "agent_type":    "agentmesh",
                "capabilities":  [],
                "source":        "trust_engine",
                "namespace":     "mesh",
            },
            headers=_CP_HEADERS,
        )
    except Exception as exc:
        logger.debug("CP register sync failed for %s: %s", did, exc)


async def _cp_heartbeat(did: str, trust_score: int) -> None:
    """Fire-and-forget: update trust score on successful handshake verification."""
    if not _cp_client:
        return
    try:
        await _cp_client.patch(
            f"{_CP_URL}/api/v1/agents/{did}",
            json={"trust_score": trust_score},
            headers=_CP_HEADERS,
        )
    except Exception as exc:
        logger.debug("CP heartbeat sync failed for %s: %s", did, exc)


# ── Request / Response models ────────────────────────────────────────


class ChallengeRequest(BaseModel):
    agent_did: str = Field(
        ..., description="DID of the agent requesting a challenge (did:mesh:...)"
    )


class ChallengeResponse(BaseModel):
    challenge_id: str
    nonce: str
    expires_in_seconds: int


class VerifyRequest(BaseModel):
    challenge_id: str = Field(..., description="ID of the challenge to verify against")
    agent_did: str
    response_nonce: str
    signature: str = Field(..., description="Hex-encoded Ed25519 signature of the nonce")
    public_key: str = Field(..., description="Base64-encoded Ed25519 public key")
    capabilities: list[str] = Field(default_factory=list)
    trust_score: int = Field(default=0, ge=0, le=1000)


class VerifyResponse(BaseModel):
    verified: bool
    trust_score: int = 0
    trust_level: str = ""
    peer_did: str = ""
    rejection_reason: str | None = None


class RegisterAgentRequest(BaseModel):
    name: str = Field(..., description="Human-readable agent name")
    public_key: str = Field(..., description="Base64-encoded Ed25519 public key")
    sponsor_email: str = Field(..., description="Human sponsor email")
    description: str | None = None
    did_unique_id: str | None = Field(
        None, description="Custom unique ID; auto-generated if omitted"
    )


class GrantCapabilityRequest(BaseModel):
    capability: str = Field(..., description="Capability string (e.g., 'read:data')")
    to_agent: str = Field(..., description="DID of grantee")
    from_agent: str = Field(..., description="DID of grantor")


# ── Endpoints ────────────────────────────────────────────────────────


@app.post("/api/v1/agents/register", tags=["identity"])
async def register_agent(req: RegisterAgentRequest) -> dict[str, str]:
    """Register an agent identity with its public key."""
    agent_did = AgentDID.generate(req.name)
    identity = AgentIdentity(
        did=agent_did,
        name=req.name,
        description=req.description or "",
        public_key=req.public_key,
        verification_key_id=f"{agent_did}#key-1",
        sponsor_email=req.sponsor_email,
    )
    registry.register(identity)
    if _redis:
        try:
            await _redis.save_identity(str(agent_did), identity.model_dump())
        except Exception as exc:
            logger.warning("Redis identity persist failed (non-blocking): %s", exc)
    asyncio.create_task(_cp_register(str(agent_did), identity))
    return {"status": "registered", "agent_did": str(agent_did)}


@app.post("/api/v1/handshake/challenge", tags=["trust"], response_model=ChallengeResponse)
async def issue_challenge(req: ChallengeRequest) -> ChallengeResponse:
    """Issue a cryptographic challenge for an agent to prove identity."""
    identity = registry.get(req.agent_did)
    if identity is None:
        raise HTTPException(404, f"Agent {req.agent_did} not registered")

    handshake = TrustHandshake(
        agent_did=req.agent_did,
        identity=identity,
        registry=registry,
    )
    challenge = HandshakeChallenge.generate()
    if _redis:
        try:
            await _redis.save_challenge(challenge.challenge_id, {
                "agent_did": req.agent_did,
                "nonce": challenge.nonce,
                "expires_in_seconds": challenge.expires_in_seconds,
            })
        except Exception as exc:
            logger.warning("Redis challenge persist failed — using in-memory: %s", exc)
            _pending_challenges_mem[challenge.challenge_id] = (handshake, challenge)
    else:
        _pending_challenges_mem[challenge.challenge_id] = (handshake, challenge)

    return ChallengeResponse(
        challenge_id=challenge.challenge_id,
        nonce=challenge.nonce,
        expires_in_seconds=challenge.expires_in_seconds,
    )


@app.post("/api/v1/handshake/verify", tags=["trust"], response_model=VerifyResponse)
async def verify_handshake(req: VerifyRequest) -> VerifyResponse:
    """Verify a signed challenge response from an agent."""
    if _redis:
        try:
            redis_data = await _redis.pop_challenge(req.challenge_id)
            # Redis path: reconstruct entry from in-memory registry for full verify
            entry = _pending_challenges_mem.pop(req.challenge_id, None)
            if entry is None and redis_data is None:
                raise HTTPException(404, "Challenge not found or expired")
            # If challenge was only in Redis (cross-replica case), build synthetic entry
            if entry is None and redis_data is not None:
                identity = registry.get(req.agent_did)
                if identity is None:
                    raise HTTPException(404, f"Agent {req.agent_did} not registered")
                entry = (
                    TrustHandshake(agent_did=req.agent_did, identity=identity, registry=registry),
                    HandshakeChallenge(
                        nonce=redis_data.get("nonce", ""),
                        expires_in_seconds=redis_data.get("expires_in_seconds", 60),
                    ),
                )
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Redis challenge pop failed — falling back to in-memory: %s", exc)
            entry = _pending_challenges_mem.pop(req.challenge_id, None)
    else:
        entry = _pending_challenges_mem.pop(req.challenge_id, None)
    if entry is None:
        raise HTTPException(404, "Challenge not found or expired")

    handshake, challenge = entry

    if challenge.is_expired():
        return VerifyResponse(verified=False, rejection_reason="Challenge expired")

    try:
        response = HandshakeResponse(
            challenge_id=req.challenge_id,
            response_nonce=req.response_nonce,
            agent_did=req.agent_did,
            signature=req.signature,
            public_key=req.public_key,
            capabilities=req.capabilities,
            trust_score=req.trust_score,
        )
        result = await handshake._verify_response(
            response=response,
            challenge=challenge,
            required_score=0,
            required_capabilities=None,
        )
        verified = result.get("verified", False)
        trust_score = result.get("trust_score", 0)
        if verified:
            asyncio.create_task(_cp_heartbeat(req.agent_did, trust_score))
        return VerifyResponse(
            verified=verified,
            trust_score=trust_score,
            trust_level=result.get("trust_level", ""),
            peer_did=result.get("peer_did", req.agent_did),
        )
    except Exception as exc:
        logger.warning("Handshake verification failed: %s", exc)
        return VerifyResponse(verified=False, rejection_reason=str(exc))


@app.post("/api/v1/capabilities/grant", tags=["capabilities"])
async def grant_capability(req: GrantCapabilityRequest) -> dict[str, Any]:
    """Grant a capability to an agent."""
    grant = capability_registry.grant(
        capability=req.capability,
        to_agent=req.to_agent,
        from_agent=req.from_agent,
    )
    return {"status": "granted", "grant_id": grant.grant_id, "capability": req.capability}


@app.get("/api/v1/capabilities/{agent_did:path}", tags=["capabilities"])
async def list_capabilities(agent_did: str) -> dict[str, Any]:
    """List capabilities granted to an agent."""
    scope = capability_registry.get_scope(agent_did)
    return {
        "agent_did": agent_did,
        "capabilities": [
            {"capability": g.capability, "active": g.is_valid()}
            for g in scope.grants
        ],
    }


def main() -> None:
    run_server(app, default_port=8443)


if __name__ == "__main__":
    main()
