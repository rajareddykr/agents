# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""
agentmesh policy-server.

The control plane is the single source of truth for policy documents.
This service is a thin subscriber: it receives YAML pushed from the AGT
control plane (IMPL-003), compiles it into an in-memory PolicyEngine, and
serves the bundle to enforcers (SDK, mcp-proxy, agent-mesh gateway) via
GET /api/v1/policies/bundle (IMPL-006).

Run locally:

    uvicorn agentmesh.server.policy_server:app --port 8444

Environment:

* ``AGENTMESH_POLICY_DIR``          — directory of seed YAML/JSON files
  (default: /etc/agentmesh/policies)
* ``AGENTMESH_POLICY_SERVER_TOKEN`` — if set, all write endpoints require
  ``Authorization: Bearer <token>``.
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from agentmesh.governance.policy import PolicyEngine
from agentmesh.governance.policy_evaluator import PolicyEvaluator
from agentmesh.governance.trust_policy import TrustPolicy
from agentmesh.server import run_server

logger = logging.getLogger("agentmesh.policy_server")

POLICY_DIR = os.getenv("AGENTMESH_POLICY_DIR", "/etc/agentmesh/policies")

# ── Process-global state ─────────────────────────────────────────────────────
# The engine is process-global because policy state is the whole reason this
# service exists. A restart means the CP must re-push — its bootstrap sync
# handles that.

_engine: PolicyEngine = PolicyEngine()
_trust_policies: list[TrustPolicy] = []
_trust_evaluator: PolicyEvaluator | None = None
_loaded_count: int = 0
_loaded_by_id: dict[str, str] = {}  # CP policy_id → engine policy name


def get_engine() -> PolicyEngine:
    """Return the process-global engine (used by tests)."""
    return _engine


def _reset_state() -> None:
    """Test helper — wipe all loaded policies."""
    global _loaded_by_id
    for name in list(_engine.list_policies()):
        _engine.remove_policy(name)
    _loaded_by_id = {}


def _load_policies() -> None:
    """Load seed YAML/JSON policy files from POLICY_DIR."""
    global _engine, _trust_policies, _trust_evaluator, _loaded_count

    policy_path = Path(POLICY_DIR)
    if not policy_path.exists():
        logger.warning("Policy directory %s does not exist", POLICY_DIR)
        return

    _engine = PolicyEngine()
    _trust_policies = []
    governance_count = 0

    for f in sorted(policy_path.glob("*.yaml")):
        try:
            _engine.load_yaml(f.read_text(encoding="utf-8"))
            governance_count += 1
            logger.info("Loaded governance policy: %s", f.name)
        except Exception:
            try:
                tp = TrustPolicy.from_yaml(f.read_text(encoding="utf-8"))
                _trust_policies.append(tp)
                logger.info("Loaded trust policy: %s", f.name)
            except Exception as exc:
                logger.warning("Skipped %s: %s", f.name, exc)

    for f in sorted(policy_path.glob("*.json")):
        try:
            _engine.load_json(f.read_text(encoding="utf-8"))
            governance_count += 1
        except Exception as exc:
            logger.warning("Skipped %s: %s", f.name, exc)

    if _trust_policies:
        _trust_evaluator = PolicyEvaluator(_trust_policies)

    _loaded_count = governance_count + len(_trust_policies)
    logger.info(
        "Loaded %d governance + %d trust policies",
        governance_count,
        len(_trust_policies),
    )


# ── Auth (optional bearer token) ─────────────────────────────────────────────

_bearer = HTTPBearer(auto_error=False)


def _require_token(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> None:
    expected = os.getenv("AGENTMESH_POLICY_SERVER_TOKEN", "").strip()
    if not expected:
        return
    if not creds or creds.scheme.lower() != "bearer" or creds.credentials != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing bearer token",
        )


# ── Pydantic models ──────────────────────────────────────────────────────────


class LoadedPolicy(BaseModel):
    policy_id: str = Field(..., description="ID the control plane uses for this policy.")
    name: str = Field(..., description="Internal policy name (engine key).")


class LoadedPoliciesResponse(BaseModel):
    count: int
    policies: list[LoadedPolicy]


class UpsertResult(BaseModel):
    status: str
    policy_id: str
    name: str


class DeleteResult(BaseModel):
    status: str
    policy_id: str


class EvaluateRequest(BaseModel):
    agent_did: str = Field(..., description="DID of the acting agent")
    action: str = Field(..., description="Action being performed")
    resource: str | None = Field(None, description="Target resource")
    context: dict[str, Any] = Field(default_factory=dict, description="Additional context")


class EvaluateResponse(BaseModel):
    allowed: bool
    action: str
    decision: str = Field(..., description="allow, deny, warn, or require_approval")
    matched_rule: str | None = None
    policy_name: str | None = None
    reason: str | None = None
    evaluation_ms: float | None = None


class TrustEvaluateRequest(BaseModel):
    context: dict[str, Any] = Field(..., description="Trust policy evaluation context")


class TrustEvaluateResponse(BaseModel):
    allowed: bool
    action: str
    rule_name: str | None = None
    reason: str = ""


# ── App ───────────────────────────────────────────────────────────────────────


def create_app() -> FastAPI:
    @asynccontextmanager
    async def lifespan(_: FastAPI):
        _load_policies()
        yield

    _app = FastAPI(
        title="agentmesh Policy Server",
        version="1.0.0",
        description=(
            "Compiled in-memory policy set for agent-mesh enforcers. "
            "The AGT control plane pushes YAML documents here via "
            "PUT /api/v1/policies/{id}; enforcers pull the compiled bundle "
            "from GET /api/v1/policies/bundle."
        ),
        lifespan=lifespan,
    )

    # ── Health ───────────────────────────────────────────────────────────────

    @_app.get("/healthz", tags=["health"])
    async def healthz() -> dict[str, Any]:
        return {"status": "ok", "loaded_policies": len(_engine.list_policies())}

    # ── Named policy CRUD — control-plane → policy-server sync (IMPL-003) ────

    @_app.put(
        "/api/v1/policies/{policy_id}",
        tags=["policy"],
        response_model=UpsertResult,
        dependencies=[Depends(_require_token)],
    )
    async def upsert_named_policy(policy_id: str, request: Request) -> UpsertResult:
        """Receive a YAML policy from the control plane and load it in-memory."""
        raw = await request.body()
        if not raw:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty policy body",
            )
        try:
            yaml_content = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Body must be utf-8 encoded YAML: {exc}",
            ) from exc

        previous_name = _loaded_by_id.get(policy_id)
        try:
            policy = _engine.load_yaml(yaml_content)
        except Exception as exc:
            logger.warning("Rejecting PUT /policies/%s — invalid YAML: %s", policy_id, exc)
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid policy YAML: {exc}",
            ) from exc

        if previous_name and previous_name != policy.name:
            _engine.remove_policy(previous_name)

        _loaded_by_id[policy_id] = policy.name
        logger.info(
            "Loaded policy '%s' (id=%s, rules=%d) from control-plane push",
            policy.name, policy_id, len(policy.rules),
        )
        return UpsertResult(status="loaded", policy_id=policy_id, name=policy.name)

    @_app.delete(
        "/api/v1/policies/{policy_id}",
        tags=["policy"],
        response_model=DeleteResult,
        dependencies=[Depends(_require_token)],
    )
    async def delete_named_policy(policy_id: str) -> DeleteResult:
        """Remove a policy by the control-plane ID. Idempotent."""
        name = _loaded_by_id.pop(policy_id, None)
        if name is None:
            return DeleteResult(status="not_found", policy_id=policy_id)
        removed = _engine.remove_policy(name)
        logger.info("Removed policy '%s' (id=%s, removed=%s)", name, policy_id, removed)
        return DeleteResult(status="removed" if removed else "not_found", policy_id=policy_id)

    # ── Bundle fetch — enforcer → policy-server pull (IMPL-006) ──────────────

    @_app.get("/api/v1/policies", tags=["policy"], response_model=LoadedPoliciesResponse)
    async def list_loaded_policies() -> LoadedPoliciesResponse:
        """List the policies currently compiled in memory."""
        items = [
            LoadedPolicy(policy_id=pid, name=name)
            for pid, name in sorted(_loaded_by_id.items())
        ]
        return LoadedPoliciesResponse(count=len(items), policies=items)

    @_app.get("/api/v1/policies/bundle", tags=["policy"])
    async def get_policy_bundle() -> dict[str, Any]:
        """Return the compiled policy bundle for enforcers to cache."""
        governance_policies = []
        for name in _engine.list_policies():
            p = _engine.get_policy(name)
            if p is not None:
                governance_policies.append(p.model_dump(exclude_none=True))
        trust_policy_dicts = []
        for tp in _trust_policies:
            try:
                trust_policy_dicts.append(tp.model_dump(exclude_none=True))
            except Exception:
                trust_policy_dicts.append({"name": getattr(tp, "name", "unknown")})
        return {
            "policies": governance_policies,
            "trust_policies": trust_policy_dicts,
            "total": len(governance_policies),
        }

    # ── Evaluation (hot path) ─────────────────────────────────────────────────

    @_app.post("/api/v1/evaluate", tags=["policy"], response_model=EvaluateResponse)
    async def evaluate(body: EvaluateRequest) -> EvaluateResponse:
        """Evaluate an action against the loaded policy set."""
        ctx = {"action": body.action, "resource": body.resource, **body.context}
        decision = _engine.evaluate(body.agent_did, ctx)
        return EvaluateResponse(
            allowed=decision.allowed,
            action=decision.action or "",
            decision=decision.action or "allow",
            matched_rule=decision.matched_rule,
            policy_name=decision.policy_name,
            reason=decision.reason,
            evaluation_ms=decision.evaluation_ms,
        )

    @_app.post(
        "/api/v1/policy/trust/evaluate",
        tags=["policy"],
        response_model=TrustEvaluateResponse,
    )
    async def evaluate_trust_policy(req: TrustEvaluateRequest) -> TrustEvaluateResponse:
        """Evaluate trust policies against a context."""
        if _trust_evaluator is None:
            raise HTTPException(status_code=503, detail="No trust policies loaded")
        result = _trust_evaluator.evaluate(req.context)
        return TrustEvaluateResponse(
            allowed=result.allowed,
            action=result.action,
            rule_name=result.rule_name,
            reason=result.reason,
        )

    @_app.post("/api/v1/policy/reload", tags=["policy"])
    async def reload_policies() -> dict[str, Any]:
        """Reload seed policies from the AGENTMESH_POLICY_DIR directory."""
        _load_policies()
        return {"status": "reloaded", "total_loaded": _loaded_count}

    return _app


app = create_app()


def main() -> None:
    run_server(app, default_port=8444)


if __name__ == "__main__":
    main()
