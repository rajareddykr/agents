# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Pushes per-dimension trust state from the mesh trust-engine to the AGT
control plane (IMPL-028).

The publisher is a thin wire layer — it takes a TrustScore the engine has
already computed and POSTs it to the CP ingest endpoint. No additional
computation, no engine modification. The caller (typically the
trust-engine service) invokes ``publish_score`` after each
``RewardEngine.record_signal`` (or batched).

Wire contract:
    POST {cp_url}/api/v1/agents/{agent_did}/trust/update
    Headers:
        X-AGT-Token: <api token with service role>
    Body:
        {
            "composite": int,                # 0-1000
            "dimensions": {
                "behavior": float,           # 0-1000
                "task_success": float,
                "policy_compliance": float,
                "communication_integrity": float,
                "resource_usage": float,
            },
            "source": "agentmesh-trust-engine",
            "observed_at": ISO8601,
        }
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Callable

import httpx

from .._paths import api_v1_url
from .scoring import TrustScore

logger = logging.getLogger(__name__)


# Mesh DimensionType.value  →  CP trust_dim_* column suffix.
# Mapping reflects the closest semantic match between the two dimension models.
# The CP column suffix is what the CP endpoint expects in its "dimensions" dict.
_MESH_TO_CP_DIM: dict[str, str] = {
    "policy_compliance":    "policy_compliance",
    "resource_efficiency":  "resource_usage",
    "output_quality":       "task_success",
    "security_posture":     "behavior",
    "collaboration_health": "communication_integrity",
}

# Mesh RewardDimension.score is 0-100; CP trust_dim_* is 0-1000.
_DIM_SCALE: float = 10.0


class CPTrustPublisher:
    """Posts mesh-computed trust state to the AGT CP ingest endpoint."""

    def __init__(
        self,
        cp_url: str,
        api_token: str,
        *,
        org_code: str = "",
        timeout: float = 5.0,
        source: str = "agentmesh-trust-engine",
        extra_headers: dict[str, str] | None = None,
        token_provider: Callable[[], str] | None = None,
    ) -> None:
        self._cp_url = cp_url.rstrip("/")
        self._api_token = api_token
        self._extra_headers = dict(extra_headers or {})
        self._org_code = org_code
        self._timeout = timeout
        self._source = source
        # IMPL-078: called at REQUEST time for the token to present, so a host
        # that rotates short-lived credentials keeps this publisher on the
        # freshest one without reconstruction. Optional — absent means the
        # construction-time token, exactly the pre-IMPL-078 behaviour.
        self._token_provider = token_provider

    def _current_token(self) -> str:
        """The token to present NOW: the provider's answer, else the static one.

        A broken or empty provider falls back — a rotation convenience must
        never be able to stop publishing.
        """
        if self._token_provider is not None:
            try:
                return self._token_provider() or self._api_token
            except Exception:  # noqa: BLE001
                return self._api_token
        return self._api_token

    async def publish_score(self, agent_did: str, score: TrustScore) -> bool:
        """POST one trust update. Returns True on 2xx, False otherwise.

        Fail-open: any exception (network, JSON, etc.) is caught and
        logged; the caller is never blocked on publish.
        """
        url = api_v1_url(self._cp_url, f"/agents/{agent_did}/trust/update", self._org_code)
        body = self._build_body(score)
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(
                    url,
                    json=body,
                    headers={"X-AGT-Token": self._current_token(), **self._extra_headers},
                )
        except Exception as exc:
            logger.warning("trust publish failed for %s: %s", agent_did, exc)
            return False

        if not (200 <= resp.status_code < 300):
            logger.warning(
                "trust publish %s returned %s for %s",
                self._cp_url, resp.status_code, agent_did,
            )
            return False
        return True

    def _build_body(self, score: TrustScore) -> dict[str, Any]:
        """Map a mesh TrustScore into the CP ingest contract."""
        cp_dims: dict[str, float] = {}
        for mesh_key, dim in score.dimensions.items():
            cp_key = _MESH_TO_CP_DIM.get(mesh_key)
            if cp_key is None:
                logger.debug("unknown mesh dimension '%s' — skipped", mesh_key)
                continue
            cp_dims[cp_key] = dim.score * _DIM_SCALE

        return {
            "composite":   score.total_score,
            "dimensions":  cp_dims,
            "source":      self._source,
            "observed_at": (score.calculated_at or datetime.now(timezone.utc)).isoformat(),
        }
