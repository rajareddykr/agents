# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Pushes drift / regime-change samples from NetworkTrustEngine to the AGT CP
(IMPL-037).

Mirror of ``agentmesh.reward.publisher.CPTrustPublisher`` (IMPL-028). The
engine class is unchanged; this module is wiring, not new computation.

Two emission paths flow through the same ``/drift/ingest`` POST:

  1. **Alert path** — fires immediately when
     ``NetworkTrustEngine.detect_regime_change`` crosses threshold. Hooked
     via ``engine.on_regime_change(self.on_alert)``.
  2. **Sampler path** — fires every ``sample_interval_seconds`` for each
     agent the engine has seen actions for, so the CP series doesn't gap
     during steady-state quiet periods. The handler iterates
     ``engine.known_agents()`` and calls ``detect_regime_change`` to fetch
     the current KL (or 0.0 if there's no alert).

Fail-open: any HTTP / JSON error is logged at WARNING and never raised.

Wire contract:
    POST {cp_url}/api/v1/agents/{agent_did}/drift/ingest
    Headers:
        X-AGT-Token: <api token with service role>
    Body (see app/schemas/agents.py:DriftSampleIn):
        {
            "kl_divergence": float,
            "threshold": float,
            "regime_change": bool,
            "recent_top_action": str | null,
            "recent_distribution": {action: prob, ...} | null,
            "historical_distribution": {action: prob, ...} | null,
            "source": "agentmesh-trust-decay",
            "observed_at": ISO8601,
        }

Wiring (in whatever future process hosts a NetworkTrustEngine instance):

    publisher = CPDriftPublisher(
        CPDriftPublisherConfig(cp_base_url=..., api_token=...),
        engine=network_trust_engine,
    )
    network_trust_engine.on_regime_change(publisher.on_alert)
    asyncio.create_task(publisher.sample_loop())
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import httpx

from .._paths import api_v1_url
from .trust_decay import NetworkTrustEngine, RegimeChangeAlert

logger = logging.getLogger(__name__)


@dataclass
class CPDriftPublisherConfig:
    cp_base_url:                 str
    api_token:                   str
    sample_interval_seconds:     float = 60.0
    request_timeout_seconds:     float = 5.0
    org_code:                    str = ""
    extra_headers:               dict | None = None


class CPDriftPublisher:
    """POSTs one drift sample per regime-change alert and one per quiet tick."""

    def __init__(self, cfg: CPDriftPublisherConfig, engine: NetworkTrustEngine) -> None:
        self._cfg = cfg
        self._engine = engine
        self._client = httpx.AsyncClient(
            base_url=cfg.cp_base_url,
            timeout=cfg.request_timeout_seconds,
            headers={"X-AGT-Token": cfg.api_token, **(cfg.extra_headers or {})},
        )
        self._sampler_task: asyncio.Task[None] | None = None
        self._stopped = False

    # ── Alert path ────────────────────────────────────────────────────────────

    def on_alert(self, alert: RegimeChangeAlert) -> None:
        """Callback for ``NetworkTrustEngine.on_regime_change``.

        Schedules an immediate POST. The engine fires this synchronously
        from ``detect_regime_change``; we ``create_task`` to avoid blocking.
        """
        body = {
            "kl_divergence":           alert.kl_divergence,
            "threshold":               alert.threshold,
            "regime_change":           True,
            "recent_top_action":       _top_action(alert.recent_distribution),
            "recent_distribution":     alert.recent_distribution,
            "historical_distribution": alert.historical_distribution,
            "source":                  "agentmesh-trust-decay",
            "observed_at":             _now_iso(),
        }
        asyncio.create_task(self._post(alert.agent_did, body))

    # ── Sampler path ──────────────────────────────────────────────────────────

    async def sample_loop(self) -> None:
        """Steady-state filler: every interval, POST one sample per known agent.

        Call once at startup; runs until ``close()`` flips ``_stopped``. The
        loop uses ``engine.known_agents()`` (IMPL-037 helper) to snapshot the
        set of DIDs to publish for.
        """
        while not self._stopped:
            try:
                await asyncio.sleep(self._cfg.sample_interval_seconds)
            except asyncio.CancelledError:
                return
            for did in self._engine.known_agents():
                alert = self._engine.detect_regime_change(did)
                body = {
                    "kl_divergence":           alert.kl_divergence if alert else 0.0,
                    "threshold":               self._engine.regime_threshold,
                    "regime_change":           alert is not None,
                    "recent_top_action":       _top_action(alert.recent_distribution) if alert else None,
                    "recent_distribution":     alert.recent_distribution if alert else None,
                    "historical_distribution": alert.historical_distribution if alert else None,
                    "source":                  "agentmesh-trust-decay",
                    "observed_at":             _now_iso(),
                }
                await self._post(did, body)

    # ── Common POST ───────────────────────────────────────────────────────────

    async def _post(self, agent_did: str, body: dict[str, Any]) -> None:
        try:
            url = api_v1_url(
                self._cfg.cp_base_url,
                f"/agents/{agent_did}/drift/ingest",
                self._cfg.org_code,
            )
            resp = await self._client.post(url, json=body)
            if not (200 <= resp.status_code < 300):
                logger.warning(
                    "drift ingest %s returned %s for %s",
                    self._cfg.cp_base_url, resp.status_code, agent_did,
                )
        except Exception as exc:
            logger.warning("drift ingest failed for %s: %s", agent_did, exc)

    async def close(self) -> None:
        """Cancel the sampler task (if running) and close the HTTP client."""
        self._stopped = True
        if self._sampler_task and not self._sampler_task.done():
            self._sampler_task.cancel()
            try:
                await self._sampler_task
            except (asyncio.CancelledError, Exception):
                pass
        await self._client.aclose()


def _top_action(dist: dict[str, float] | None) -> str | None:
    if not dist:
        return None
    return max(dist.items(), key=lambda kv: kv[1])[0]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
