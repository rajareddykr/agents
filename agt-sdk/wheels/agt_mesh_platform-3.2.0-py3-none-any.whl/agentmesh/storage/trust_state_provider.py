# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Redis-backed persistence for agentmesh trust state (IMPL-008).

This is a domain-specific semantic layer over the raw Redis client — it is NOT
a subclass of RedisStorageProvider (which is a generic low-level provider).
Instantiate it with any redis.asyncio.Redis client.

Key schema (all on Redis DB 1 — AGENTMESH_REDIS_URL):
  agentmesh:identity:{agent_did}     TTL none   AgentIdentity JSON
  agentmesh:trust:{agent_did}        TTL 86400  Trust state JSON
  agentmesh:reward:{agent_did}       TTL 86400  AgentRewardState JSON
  agentmesh:challenge:{challenge_id} TTL 60     HandshakeChallenge JSON (GETDEL)
  agentmesh:did:index                TTL none   HSET name→did reverse lookup
"""
from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

_IDENTITY_PREFIX  = "agentmesh:identity:"
_TRUST_PREFIX     = "agentmesh:trust:"
_REWARD_PREFIX    = "agentmesh:reward:"
_CHALLENGE_PREFIX = "agentmesh:challenge:"
_DID_INDEX        = "agentmesh:did:index"


class RedisTrustStateProvider:
    """
    Persists agentmesh trust state to Redis DB 1.

    Designed as a write-through companion to the in-memory IdentityRegistry:
    the registry holds the hot working set, Redis provides durability and
    cross-replica sharing for challenges (GETDEL is atomic).
    """

    def __init__(self, client: Any) -> None:
        self._r = client

    # ── Identity ──────────────────────────────────────────────────────────────

    async def save_identity(self, agent_did: str, identity: dict) -> None:
        await self._r.set(
            f"{_IDENTITY_PREFIX}{agent_did}",
            json.dumps(identity, default=str),
        )
        await self._r.hset(_DID_INDEX, identity.get("name", agent_did), agent_did)

    async def get_identity(self, agent_did: str) -> dict | None:
        raw = await self._r.get(f"{_IDENTITY_PREFIX}{agent_did}")
        return json.loads(raw) if raw else None

    async def delete_identity(self, agent_did: str) -> None:
        await self._r.delete(f"{_IDENTITY_PREFIX}{agent_did}")

    async def all_identities(self) -> list[dict]:
        """Load all persisted identities — used to seed in-memory registry on startup."""
        keys: list[str] = []
        cursor = 0
        while True:
            cursor, batch = await self._r.scan(
                cursor, match=f"{_IDENTITY_PREFIX}*", count=500
            )
            keys.extend(batch)
            if cursor == 0:
                break
        if not keys:
            return []
        raw_list = await self._r.mget(*keys)
        return [json.loads(r) for r in raw_list if r]

    # ── Trust scores ──────────────────────────────────────────────────────────

    async def save_trust(self, agent_did: str, state: dict) -> None:
        await self._r.setex(
            f"{_TRUST_PREFIX}{agent_did}",
            86400,
            json.dumps(state, default=str),
        )

    async def get_trust(self, agent_did: str) -> dict | None:
        raw = await self._r.get(f"{_TRUST_PREFIX}{agent_did}")
        return json.loads(raw) if raw else None

    async def get_or_init_trust(self, agent_did: str, default_score: int = 800) -> dict:
        existing = await self.get_trust(agent_did)
        if existing:
            return existing
        state: dict = {
            "score":           default_score,
            "tier":            "bronze",
            "actions_allowed": 0,
            "actions_blocked": 0,
        }
        await self.save_trust(agent_did, state)
        return state

    # ── Handshake challenges ──────────────────────────────────────────────────

    async def save_challenge(self, challenge_id: str, data: dict) -> None:
        """Store a challenge with 60s expiry."""
        await self._r.setex(
            f"{_CHALLENGE_PREFIX}{challenge_id}",
            60,
            json.dumps(data, default=str),
        )

    async def pop_challenge(self, challenge_id: str) -> dict | None:
        """Atomic get-and-delete (Redis GETDEL). Returns None if not found or expired."""
        raw = await self._r.getdel(f"{_CHALLENGE_PREFIX}{challenge_id}")
        return json.loads(raw) if raw else None

    # ── Reward state ──────────────────────────────────────────────────────────

    async def save_reward_state(self, agent_did: str, state: dict) -> None:
        await self._r.setex(
            f"{_REWARD_PREFIX}{agent_did}",
            86400,
            json.dumps(state, default=str),
        )

    async def get_reward_state(self, agent_did: str) -> dict | None:
        raw = await self._r.get(f"{_REWARD_PREFIX}{agent_did}")
        return json.loads(raw) if raw else None
