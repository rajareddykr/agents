# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""IMPL-031: Heartbeat client that POSTs liveness to the AGT control plane.

Per-agent background task. Each running agent owns its own client.
The control plane already exposes `POST /api/v1/agents/{agent_id}/heartbeat`
(see control-plane/backend/app/routers/agents.py:464); this client adds
the missing caller.

Mesh-registered agents use their DID as `agents.id` (per
`server/trust_engine.py:_cp_register`), so the agent_id passed to the
constructor is normally the agent's DID for mesh deployments.

Fail-open semantics: HTTP errors are logged at WARNING and the loop
continues. Network problems should not crash the agent.
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

import httpx

from .._paths import api_v1_url

logger = logging.getLogger(__name__)


_DEFAULT_INTERVAL_SECONDS: float = 30.0
_DEFAULT_TIMEOUT_SECONDS:  float = 5.0


class CPHeartbeatClient:
    """Posts heartbeats to the CP on a configurable interval."""

    def __init__(
        self,
        cp_url: str,
        agent_id: str,
        api_token: str,
        *,
        org_code: str = "",
        interval_seconds: float | None = None,
        timeout: float = _DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        if interval_seconds is None:
            env_val = os.getenv("AGT_HEARTBEAT_INTERVAL_SECONDS", "")
            try:
                interval_seconds = float(env_val) if env_val else _DEFAULT_INTERVAL_SECONDS
            except ValueError:
                interval_seconds = _DEFAULT_INTERVAL_SECONDS

        self._cp_url = cp_url.rstrip("/")
        self._agent_id = agent_id
        self._api_token = api_token
        self._org_code = org_code
        self._interval_seconds = interval_seconds
        self._timeout = timeout

        self._task: asyncio.Task[Any] | None = None
        self._stopped = asyncio.Event()

    async def start(self) -> None:
        """Begin posting heartbeats. First POST fires immediately;
        subsequent posts happen every ``interval_seconds``.

        Idempotent: calling ``start()`` again while a task is running
        is a no-op.
        """
        if self._task is not None and not self._task.done():
            return
        self._stopped.clear()
        # First heartbeat awaited inline so the dashboard sees liveness
        # before the loop's first sleep returns.
        await self._post_one()
        self._task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        """Cancel the background loop. No final heartbeat is sent.

        Safe to call before ``start()``.
        """
        self._stopped.set()
        if self._task is None:
            return
        self._task.cancel()
        try:
            await self._task
        except (asyncio.CancelledError, Exception):
            pass
        self._task = None

    async def _heartbeat_loop(self) -> None:
        try:
            while not self._stopped.is_set():
                try:
                    await asyncio.wait_for(
                        self._stopped.wait(),
                        timeout=self._interval_seconds,
                    )
                    return  # _stopped was set
                except asyncio.TimeoutError:
                    pass  # interval elapsed; POST the next heartbeat
                await self._post_one()
        except asyncio.CancelledError:
            raise

    async def _post_one(self) -> bool:
        """POST one heartbeat. Failures logged, never raised."""
        url = api_v1_url(self._cp_url, f"/agents/{self._agent_id}/heartbeat", self._org_code)
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(
                    url,
                    headers={"X-AGT-Token": self._api_token},
                )
        except Exception as exc:
            logger.warning("heartbeat post failed for %s: %s", self._agent_id, exc)
            return False

        if not (200 <= resp.status_code < 300):
            logger.warning(
                "heartbeat post %s returned %s for %s",
                self._cp_url, resp.status_code, self._agent_id,
            )
            return False
        return True
