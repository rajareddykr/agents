# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""URL composition for agent-mesh → CP publisher requests (IMPL-045).

The mesh-side CP publishers (handshake, trust, risk, drift, heartbeat)
each POST to the control plane. After IMPL-045 every CP route moved under
an org-scoped prefix — ``/api/v1/orgs/{org_code}{suffix}``. This helper is
the mesh equivalent of the SDK's ``agt_sdk._paths.api_v1_url``; it is kept
as a standalone copy here on purpose, because agent-mesh is a foundation
package and must not import from the SDK (the dependency runs the other
way).

When ``org_code`` is empty the legacy ``/api/v1{suffix}`` form is returned
so behaviour is unchanged for callers that have not been migrated — the CP
answers those with a 307 to the org-scoped path during the grace window,
but ``httpx.AsyncClient`` does not follow 307 by default, so direct
composition (passing a real ``org_code``) is the supported mode.
"""
from __future__ import annotations

import logging
import re
import threading

logger = logging.getLogger("agentmesh.paths")

# DNS-label rules: lowercase alphanumerics + dashes, no leading/trailing
# dash, max 63 chars. Mirrors the CP's server-side org-slug validation.
_SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")

_warned_lock = threading.Lock()
_warned: set[str] = set()


def _warn_once(key: str, message: str) -> None:
    with _warned_lock:
        if key in _warned:
            return
        _warned.add(key)
    logger.warning(message)


def is_valid_org_code(org_code: str) -> bool:
    """Cheap shape check for an org slug. Empty string is *not* valid."""
    return bool(org_code) and bool(_SLUG_RE.match(org_code))


def api_v1_url(base_url: str, suffix: str, org_code: str = "") -> str:
    """Compose a fully-qualified CP URL for the v1 API.

    Args:
        base_url:  Control-plane base, e.g. ``https://cp.example.com``.
        suffix:    Path **below** ``/api/v1`` — must start with ``/``,
                   e.g. ``/trust/handshakes/ingest``.
        org_code:  Org slug. When non-empty and well-formed the path is
                   org-scoped; otherwise the legacy unscoped form is
                   returned (with a one-time warning).

    Returns:
        ``{base}/api/v1[/orgs/{org_code}]{suffix}``.
    """
    if not suffix.startswith("/"):
        raise ValueError(f"suffix must start with '/': {suffix!r}")

    base = base_url.rstrip("/")
    if org_code:
        if not is_valid_org_code(org_code):
            _warn_once(
                f"badcode:{org_code}",
                f"agentmesh: org_code={org_code!r} is not a valid org slug "
                "(expected lowercase alphanumerics + dashes); falling back to "
                "legacy unscoped /api/v1 paths.",
            )
        else:
            return f"{base}/api/v1/orgs/{org_code}{suffix}"

    _warn_once(
        f"unscoped:{suffix}",
        "agentmesh: no org_code supplied; using legacy /api/v1 paths and "
        "relying on the CP's 307 grace redirect (which httpx does not follow). "
        "Pass org_code to address the org-scoped endpoint directly.",
    )
    return f"{base}/api/v1{suffix}"
