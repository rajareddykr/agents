# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""IMPL-020 §3.7 — which keystore tier holds this agent's private key.

Four places a private key can live, in preference order. Higher tiers are better
because the key never exists in the agent's address space in a form an attacker
who owns the process can walk away with:

    Tier 1  HSM             PKCS#11 token
    Tier 2  Cloud KMS       key wrapped by KMS, ciphertext on local disk
    Tier 3  TPM             key sealed to the platform, ciphertext on local disk
    Tier 4  Escrow          HKDF-SHA256(AGT_AGENT_PASSPHRASE), ciphertext in the CP

**Only tier 4 is implemented.** Tiers 1–3 are detection stubs. The point of
shipping the resolver before the tiers is that the *policy* — probe order,
operator lock, refuse-rather-than-downgrade — is then right from day one, and a
later tier slots in underneath with no change to any calling agent.

Two rules do the real work here, and both exist to stop a *silent* downgrade:

**An operator lock is a lock.** ``AGT_KEYSTORE_TIER=kms`` on a host with no KMS
is a refusal to start, not a fall back to escrow. An operator who pinned a tier
did so because the weaker one is unacceptable to them; quietly giving them the
weaker one is worse than not starting, because it looks like it worked.

**A recorded tier is sticky.** The chosen tier is written next to the agent's
state so a restart resolves the same way. If a host loses its TPM, the agent
refuses rather than re-resolving down to escrow — the key it needs is sealed to
hardware that is gone, and pretending otherwise means generating a new identity.

Deviation from the spec text, deliberate: §3.7 says the stubs "select the tier
and raise a clear 'not yet implemented'". Taken literally, an agent on a host
that merely *has* a PKCS#11 library would auto-select tier 1 and then refuse to
boot — a working fleet taken down by a library being present. So auto-probing
never selects an unimplemented tier; it reports them unavailable and falls
through to escrow. Asking for one **explicitly** still refuses, which is where
the honest "not yet implemented" belongs.
"""
from __future__ import annotations

import logging
import os
from enum import IntEnum
from pathlib import Path

logger = logging.getLogger("agentmesh.keystore_tier")

TIER_ENV = "AGT_KEYSTORE_TIER"
PASSPHRASE_ENV = "AGT_AGENT_PASSPHRASE"

# Kept in step with ``key_backup.MIN_PASSPHRASE_LEN`` by importing it rather than
# restating it — two numbers that must agree, declared once.
try:                                                       # pragma: no cover
    from agentmesh.identity.key_backup import MIN_PASSPHRASE_LEN
except ImportError:                                        # pragma: no cover
    MIN_PASSPHRASE_LEN = 32


class KeystoreTier(IntEnum):
    """Lower value = stronger custody. Ordering is the probe order."""

    HSM    = 1
    KMS    = 2
    TPM    = 3
    ESCROW = 4

    @property
    def implemented(self) -> bool:
        return self is KeystoreTier.ESCROW


# What an operator may write in AGT_KEYSTORE_TIER. Accepts the names rather than
# the numbers: "kms" survives a reordering of the enum, "2" does not.
TIER_ALIASES: dict[str, KeystoreTier] = {
    "hsm":     KeystoreTier.HSM,
    "pkcs11":  KeystoreTier.HSM,
    "kms":     KeystoreTier.KMS,
    "tpm":     KeystoreTier.TPM,
    "escrow":  KeystoreTier.ESCROW,
    "cp":      KeystoreTier.ESCROW,
}


class KeystoreTierError(Exception):
    """The requested or recorded tier cannot be used. **Always fatal.**

    Never caught into a downgrade. Every path that raises this has already
    established that the only alternative is a weaker custody model than the
    operator asked for, and choosing that silently is the failure mode this
    module exists to prevent.
    """


# ── Detection stubs ──────────────────────────────────────────────────────────
#
# Each returns False until its tier is built. Kept as separate functions rather
# than one table so the probe that replaces a stub is a one-function change and
# the call site never moves.


def _hsm_available() -> bool:
    return False


def _kms_available() -> bool:
    return False


def _tpm_available() -> bool:
    return False


def _escrow_available(passphrase: str | None) -> bool:
    """Tier 4 needs a passphrase of usable length, and nothing else."""
    return bool(passphrase) and len(passphrase or "") >= MIN_PASSPHRASE_LEN


def _probe(tier: KeystoreTier) -> bool:
    """Dispatch to a tier's detection function, resolved at call time.

    Deliberately not a dict of function objects: that captures the stubs at
    import, so replacing one would not take effect through the table and tests
    could not substitute a probe. Late binding is what makes the "swap one
    function" claim above actually true.
    """
    if tier is KeystoreTier.HSM:
        return _hsm_available()
    if tier is KeystoreTier.KMS:
        return _kms_available()
    if tier is KeystoreTier.TPM:
        return _tpm_available()
    raise ValueError(f"{tier!r} has no hardware probe; escrow is checked separately")


# ── Sticky state ─────────────────────────────────────────────────────────────


def default_state_path() -> Path:
    """Where the chosen tier is remembered between restarts."""
    return Path(os.environ.get("AGT_STATE_DIR", Path.home() / ".agt")) / "keystore_tier"


def _read_recorded(path: Path) -> KeystoreTier | None:
    try:
        raw = path.read_text(encoding="utf-8").strip().lower()
    except (OSError, ValueError):
        return None
    return TIER_ALIASES.get(raw)


def _record(path: Path, tier: KeystoreTier) -> None:
    """Best-effort. A tier we cannot write down is not a reason to refuse to
    start — it only means the next restart re-probes and reaches the same
    answer, because the inputs have not changed."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(tier.name.lower(), encoding="utf-8")
    except OSError as exc:
        logger.warning(
            "keystore tier: could not record the chosen tier at %s (%s). The "
            "agent continues; the next restart re-probes.", path, exc,
        )


# ── Resolution ───────────────────────────────────────────────────────────────


def resolve_tier(
    *,
    passphrase: str | None = None,
    state_path: Path | None = None,
    record: bool = True,
) -> KeystoreTier:
    """Decide which tier holds this agent's key, or refuse to start.

    Order of authority: the operator's lock, then whatever was recorded on a
    previous run, then probing. Each level can only *refuse* — none of them may
    hand back something weaker than what was asked for.

    Args:
        passphrase: ``AGT_AGENT_PASSPHRASE``. Read from the environment when not
                    supplied, so a caller that already has it does not have to
                    put it back into the environment to be seen.
        state_path: override the sticky-state location (tests, or an agent whose
                    state lives somewhere unusual).
        record:     write the resolved tier for next time.

    Raises:
        KeystoreTierError: the locked tier is unavailable or unimplemented, the
                           recorded tier is no longer available, or nothing at
                           all is available — including tier 4 without a usable
                           passphrase.
    """
    if passphrase is None:
        passphrase = os.environ.get(PASSPHRASE_ENV, "").strip()
    path = state_path or default_state_path()

    # ── 1. Operator lock ────────────────────────────────────────────────────
    locked_raw = os.environ.get(TIER_ENV, "").strip().lower()
    if locked_raw:
        locked = TIER_ALIASES.get(locked_raw)
        if locked is None:
            raise KeystoreTierError(
                f"{TIER_ENV}={locked_raw!r} is not a known tier. Use one of: "
                f"{', '.join(sorted(TIER_ALIASES))}."
            )
        if not locked.implemented:
            raise KeystoreTierError(
                f"{TIER_ENV}={locked_raw!r} selects tier {int(locked)} "
                f"({locked.name}), which is not implemented yet. Refusing to "
                f"start rather than silently using CP escrow (tier 4) — you "
                f"pinned this tier because escrow is not acceptable here. Unset "
                f"{TIER_ENV} to accept escrow."
            )
        if not _available(locked, passphrase):
            raise KeystoreTierError(_unavailable_reason(locked, passphrase))
        if record:
            _record(path, locked)
        logger.info("keystore tier: %s (locked by %s)", locked.name, TIER_ENV)
        return locked

    # ── 2. Whatever last time chose ─────────────────────────────────────────
    recorded = _read_recorded(path)
    if recorded is not None:
        if not _available(recorded, passphrase):
            # The host changed underneath a key that is already committed to this
            # tier. Re-resolving downward would generate a new identity and call
            # it a clean start.
            raise KeystoreTierError(
                f"this agent previously used tier {int(recorded)} "
                f"({recorded.name}) but it is no longer available. "
                f"{_unavailable_reason(recorded, passphrase)} Refusing to fall back: the "
                f"existing key is held by that tier, and starting on a weaker "
                f"one would mint a new identity. Restore it, or delete "
                f"{path} to deliberately re-enrol this agent."
            )
        logger.info("keystore tier: %s (recorded at %s)", recorded.name, path)
        return recorded

    # ── 3. Probe, strongest first ───────────────────────────────────────────
    for tier in (KeystoreTier.HSM, KeystoreTier.KMS, KeystoreTier.TPM):
        if _probe(tier):                                   # pragma: no cover
            if record:
                _record(path, tier)
            logger.info("keystore tier: %s (detected)", tier.name)
            return tier

    if _escrow_available(passphrase):
        if record:
            _record(path, KeystoreTier.ESCROW)
        logger.info(
            "keystore tier: ESCROW (tier 4) — no HSM, KMS or TPM detected. The "
            "private key is encrypted with %s and the ciphertext is stored in "
            "the control plane.", PASSPHRASE_ENV,
        )
        return KeystoreTier.ESCROW

    raise KeystoreTierError(_unavailable_reason(KeystoreTier.ESCROW, passphrase))


def _available(tier: KeystoreTier, passphrase: str | None) -> bool:
    if tier is KeystoreTier.ESCROW:
        return _escrow_available(passphrase)
    return _probe(tier)


def _unavailable_reason(tier: KeystoreTier, passphrase: str | None = None) -> str:
    """Say what is missing and what to do, never just 'unavailable'.

    ``passphrase`` is the one actually resolved, not the environment's. A caller
    that supplies it as an argument — which the SDK does — was otherwise told
    "not set" while holding a perfectly good short one, sending them to look at
    the wrong thing.
    """
    if tier is KeystoreTier.ESCROW:
        current = passphrase if passphrase is not None else os.environ.get(PASSPHRASE_ENV, "")
        if not current:
            return (
                f"{PASSPHRASE_ENV} is not set. Tier 4 encrypts the agent's "
                f"private key with it before escrowing the ciphertext, so "
                f"without it there is nothing to recover on restart and this "
                f"agent would mint a new identity every time it starts. It is "
                f"organisation-wide and stays on this host."
            )
        return (
            f"{PASSPHRASE_ENV} is {len(current)} characters; tier 4 requires at "
            f"least {MIN_PASSPHRASE_LEN}. HKDF stretches a passphrase but cannot "
            f"create entropy, and a guessable one plus a stolen database is a "
            f"recovered key."
        )
    detail = {
        KeystoreTier.HSM: "no PKCS#11 token was detected",
        KeystoreTier.KMS: "no cloud KMS credentials or endpoint were detected",
        KeystoreTier.TPM: "no TPM was detected",
    }[tier]
    return f"Tier {int(tier)} ({tier.name}): {detail}."
