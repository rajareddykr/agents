# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""IMPL-020 Part 3 — tier-4 key escrow, agent side.

Encrypt the agent's Ed25519 private key with an operator-supplied passphrase and
park the ciphertext in the control plane. On restart, fetch it back and decrypt.
Same key ⇒ same DID ⇒ **no new epoch**, which is the point: without this, every
restart mints a new identity and resets trust, drift history and policy bindings.

Three facts drive every design choice here.

**The passphrase never reaches the CP.** It is host-local and organisation-wide.
`SECRET_KEY`, or any other CP-side value, is never an input to the derivation.
That is what makes a total CP compromise — database, secrets, admin credentials —
yield ciphertext and nothing else.

**The agent does not know its DID at restore.** A DID is
``sha256(public_key)[:24]`` of the key being recovered, so it cannot appear in
the salt, the AAD, the URL or the request. The complete inventory at restore is:
passphrase, org code, agent name, credential. Hence the salt and AAD are the
**logical agent handle** ``org|name`` — the identity that survives an epoch
change. Spec §3.1.

**The org passphrase is shared, so the handle is what separates agents.** Two
agents in one organisation derive different unwrap keys because their names
differ, and the handle-as-AAD means a blob lifted from one agent's row fails to
decrypt as another's even for a holder of the org passphrase.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import os
from typing import Any

import httpx
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

logger = logging.getLogger("agentmesh.key_backup")

PASSPHRASE_ENV = "AGT_AGENT_PASSPHRASE"
HKDF_INFO = b"agt-key-backup-v1"
KDF_LABEL = "hkdf-sha256-v1"

# A short passphrase is the one input we can cheaply refuse. HKDF stretches but
# does not create entropy; a guessable passphrase plus a stolen database is a
# recovered key.
MIN_PASSPHRASE_LEN = 32

IV_LEN = 12


class KeyRecoveryError(Exception):
    """Raised when an escrowed key exists but cannot be decrypted.

    Deliberately **not** a soft failure. The caller must not fall through to
    generating a fresh key: that mints a new DID on a wrong passphrase — a
    silent identity change that presents as a clean start. Spec §3.5.
    """


def handle(org_code: str, agent_name: str) -> bytes:
    """Salt and AAD. Stable across DID epochs — that is the entire point."""
    return f"{org_code}|{agent_name}".encode("utf-8")


def derive_did(private_key: Ed25519PrivateKey) -> str:
    """Recompute the DID from a key. Spec §3.4.

    The agent asks nobody for this: the DID *is* a commitment to the public key,
    so recomputing it both identifies the agent and proves the recovered key is
    the one that DID was minted from.
    """
    pub = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return "did:mesh:" + hashlib.sha256(pub).hexdigest()[:24]


class KeyBackupService:
    """Tier-4 escrow client. Tiers 1–3 (HSM / KMS / TPM) never construct this."""

    def __init__(
        self,
        cp_url: str,
        api_token: str,
        agent_passphrase: str,
        *,
        timeout: float = 5.0,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        """
        Args:
            cp_url:           Control plane base URL. Receives ciphertext only.
            api_token:        The agent's credential, sent as ``X-AGT-Token``.
                              The CP resolves it to *which* agent is calling.
            agent_passphrase: HOST-LOCAL, organisation-wide. **Never** transmitted.
                              Do not pass a CP-side secret here — doing so
                              collapses the trust model this whole tier exists for.
            extra_headers:    e.g. the PGAIAuthGateway API key. Omitting it is how
                              five mesh call sites once 401'd behind the gateway.
        """
        if not agent_passphrase or len(agent_passphrase) < MIN_PASSPHRASE_LEN:
            raise ValueError(
                f"{PASSPHRASE_ENV} must be at least {MIN_PASSPHRASE_LEN} characters. "
                "Refusing to start rather than escrow under a weak secret — see "
                "IMPL-020 Trust Model."
            )
        self._cp_url = cp_url.rstrip("/")
        self._api_token = api_token
        self._passphrase = agent_passphrase
        self._timeout = timeout
        self._extra_headers = dict(extra_headers or {})

    # ── derivation ───────────────────────────────────────────────────────────

    def _unwrap_key(self, org_code: str, agent_name: str) -> bytes:
        return HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=handle(org_code, agent_name),
            info=HKDF_INFO,
        ).derive(self._passphrase.encode("utf-8"))

    def encrypt(self, private_key: Ed25519PrivateKey, org_code: str, agent_name: str) -> str:
        """``b64(iv):b64(ct)``. AAD binds the blob to this agent's handle."""
        raw = private_key.private_bytes_raw()
        iv = os.urandom(IV_LEN)
        ct = AESGCM(self._unwrap_key(org_code, agent_name)).encrypt(
            iv, raw, handle(org_code, agent_name),
        )
        return base64.b64encode(iv).decode() + ":" + base64.b64encode(ct).decode()

    def decrypt(self, blob: str, org_code: str, agent_name: str) -> Ed25519PrivateKey:
        """Raises :class:`InvalidTag` on a wrong passphrase or a foreign blob."""
        iv_b64, ct_b64 = blob.split(":", 1)
        raw = AESGCM(self._unwrap_key(org_code, agent_name)).decrypt(
            base64.b64decode(iv_b64),
            base64.b64decode(ct_b64),
            handle(org_code, agent_name),
        )
        return Ed25519PrivateKey.from_private_bytes(raw)

    # ── transport ────────────────────────────────────────────────────────────

    def _headers(self) -> dict[str, str]:
        return {"X-AGT-Token": self._api_token, **self._extra_headers}

    async def backup(
        self, private_key: Ed25519PrivateKey, *, org_code: str, agent_name: str, key_id: str,
        expected_did: str | None = None,
    ) -> bool:
        """Store the ciphertext. **Fail-open** — never blocks the agent.

        A failed backup costs the *next* restart a new DID. A failed startup
        costs the agent entirely. The first is recoverable, so this returns
        False rather than raising.

        ``expected_did`` guards against escrowing a key that no longer *is* the
        agent's identity. A DID is ``sha256(public_key)[:24]``, so a key that does
        not hash to the agent's DID cannot restore that agent: on the next start
        the recovered key derives a different DID, the control plane sees an
        identity it has never met, and opens a new epoch — trust score, drift
        history and policy bindings gone, presenting as a clean start.

        Storing such a key is therefore strictly worse than storing nothing, and
        it is the one case where refusing to back up is the *safe* action: the
        previous blob stays current, still matches the DID, and the agent
        restarts as itself. See §3.6 — pass this from any caller that rotates
        keys.
        """
        if expected_did is not None:
            actual = derive_did(private_key)
            if actual != expected_did:
                # Loud, and not a warning: nothing about this is recoverable by
                # retrying, and the operator needs to know the rotation did not
                # persist rather than discovering it at the next restart.
                logger.error(
                    "key escrow: REFUSING to store a key that does not match the "
                    "agent's DID (expected %s, key derives %s) for %s|%s. A DID is "
                    "sha256(public_key), so this key cannot restore this agent — "
                    "storing it would replace the identity at the next restart. "
                    "The previous blob is left current and the agent will restart "
                    "as itself.",
                    expected_did, actual, org_code, agent_name,
                )
                return False

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                r = await client.put(
                    f"{self._cp_url}/api/v1/orgs/{org_code}/agent-internal/keys",
                    json={
                        "name": agent_name,
                        "ciphertext_b64": self.encrypt(private_key, org_code, agent_name),
                        "key_id": key_id,
                        "kdf": KDF_LABEL,
                    },
                    headers=self._headers(),
                )
                r.raise_for_status()
            logger.info(
                "key escrow: stored for %s|%s key_id=%s", org_code, agent_name, key_id,
            )
            return True
        except Exception as exc:                       # noqa: BLE001 — fail-open
            logger.warning(
                "key escrow: BACKUP FAILED for %s|%s (%s). The agent continues, but "
                "its next restart will mint a NEW DID unless this succeeds first.",
                org_code, agent_name, exc,
            )
            return False

    async def recover(self, *, org_code: str, agent_name: str) -> Ed25519PrivateKey | None:
        """Fetch and decrypt this agent's key. ``None`` when nothing is escrowed.

        The request carries **no name and no DID** — the CP resolves the caller
        through its credential binding and returns that agent's blob. There is no
        parameter with which to ask for somebody else's (spec §2.4). ``agent_name``
        is used only for the local derivation.

        Raises:
            KeyRecoveryError: a blob exists but will not decrypt. **Fail-closed.**
        """
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                r = await client.get(
                    f"{self._cp_url}/api/v1/orgs/{org_code}/agent-internal/keys",
                    headers=self._headers(),
                )
                if r.status_code == 404:
                    logger.info(
                        "key escrow: nothing stored for %s|%s — first boot",
                        org_code, agent_name,
                    )
                    return None
                r.raise_for_status()
                payload: Any = r.json()
                blob = (payload.get("data") or payload)["ciphertext_b64"]
        except KeyRecoveryError:
            raise
        except Exception as exc:                       # noqa: BLE001
            # Transport failure is NOT the same as a bad passphrase. Returning
            # None here would generate a new identity every time the CP blipped,
            # so this raises too — the caller decides, and the message says which.
            raise KeyRecoveryError(
                f"key escrow: could not reach the control plane for "
                f"{org_code}|{agent_name} ({exc}). Refusing to start with a new "
                f"identity; retry once the CP is reachable."
            ) from exc

        try:
            key = self.decrypt(blob, org_code, agent_name)
        except (InvalidTag, ValueError) as exc:
            raise KeyRecoveryError(
                f"key escrow: the stored key for {org_code}|{agent_name} could not "
                f"be decrypted — check {PASSPHRASE_ENV}. Refusing to start with a "
                f"new identity, which would silently replace this agent."
            ) from exc

        logger.info(
            "key escrow: RECOVERED for %s|%s — did=%s, no new epoch",
            org_code, agent_name, derive_did(key),
        )
        return key
