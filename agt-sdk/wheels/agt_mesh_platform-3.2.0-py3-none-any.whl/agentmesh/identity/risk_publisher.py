# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Pushes mesh-computed risk scores to the AGT control plane (IMPL-034).

Mirror of ``agentmesh.reward.publisher.CPTrustPublisher`` (IMPL-028) and
``agentmesh.reward.drift_publisher.CPDriftPublisher`` (IMPL-037) — same
shape, same fail-open posture, no engine modification beyond the
``RiskScorer.on_score_change`` hook (also additive).

Wire contract:
    POST {cp_url}/api/v1/agents/{agent_did}/risk/update
    Headers:
        X-AGT-Token: <api token with service role>
    Body (see app/schemas/agents.py:RiskUpdateIn):
        {
            "risk_score":  float,   # 0..100 higher-risk (CP scale)
            "risk_level":  str,     # critical | high | medium | low | minimal
            "factors":     [str],
            "components": {
                "identity":   int,  # 0..100
                "behavior":   int,
                "network":    int,
                "compliance": int,
            } | null,
            "source":      "agentmesh-risk-scorer",
            "observed_at": ISO8601,
        }

Wiring (in whatever future process hosts a RiskScorer instance):

    publisher = CPRiskPublisher("http://cp:8000", api_token=...)
    scorer = RiskScorer()
    scorer.on_score_change(
        lambda did, score: asyncio.create_task(publisher.publish_score(did, score))
    )

Per IMPL-034 § Open decisions Q5, the publisher does not debounce; the
scorer's ``UPDATE_INTERVAL = 30 s`` caps the rate naturally and critical
signals (which trigger immediate ``recalculate``) bypass the rate cap
without any debounce logic here.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Callable

import httpx

from .._paths import api_v1_url
from .risk import RiskScore

logger = logging.getLogger(__name__)


# Mesh `RiskScore.total_score` is 0..1000 higher-safer. CP `risk_score` is
# 0..100 higher-risk. The inversion: cp_risk = (1000 - total) / 10.
def _invert_score(mesh_total: int) -> int:
    cp_risk = round((1000 - int(mesh_total)) / 10)
    return max(0, min(100, cp_risk))


class CPRiskPublisher:
    """Posts mesh-computed risk state to the AGT CP ingest endpoint."""

    def __init__(
        self,
        cp_url: str,
        api_token: str,
        *,
        org_code: str = "",
        timeout: float = 5.0,
        source: str = "agentmesh-risk-scorer",
        extra_headers: dict[str, str] | None = None,
        token_provider: Callable[[], str] | None = None,
    ) -> None:
        self._cp_url = cp_url.rstrip("/")
        self._api_token = api_token
        self._extra_headers = dict(extra_headers or {})
        self._org_code = org_code
        self._timeout = timeout
        self._source = source
        # IMPL-078: called at REQUEST time for the token to present, so a host
        # that rotates short-lived credentials keeps this publisher on the
        # freshest one without reconstruction. Optional — absent means the
        # construction-time token, exactly the pre-IMPL-078 behaviour.
        self._token_provider = token_provider

    def _current_token(self) -> str:
        """The token to present NOW: the provider's answer, else the static one.

        A broken or empty provider falls back — a rotation convenience must
        never be able to stop publishing.
        """
        if self._token_provider is not None:
            try:
                return self._token_provider() or self._api_token
            except Exception:  # noqa: BLE001
                return self._api_token
        return self._api_token

    async def publish_score(self, agent_did: str, score: RiskScore) -> bool:
        """POST one risk update. Returns True on 2xx, False otherwise.

        Fail-open: any exception (network, JSON, etc.) is caught and
        logged; the caller is never blocked on publish.
        """
        url = api_v1_url(self._cp_url, f"/agents/{agent_did}/risk/update", self._org_code)
        body = self._build_body(score)
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(
                    url,
                    json=body,
                    headers={"X-AGT-Token": self._current_token(), **self._extra_headers},
                )
        except Exception as exc:
            logger.warning("risk publish failed for %s: %s", agent_did, exc)
            return False

        if not (200 <= resp.status_code < 300):
            logger.warning(
                "risk publish %s returned %s for %s",
                self._cp_url, resp.status_code, agent_did,
            )
            return False
        return True

    def _build_body(self, score: RiskScore) -> dict[str, Any]:
        """Map mesh ``RiskScore`` (0..1000 higher-safer) → CP contract (0..100 higher-risk)."""
        return {
            "risk_score":  float(_invert_score(score.total_score)),
            "risk_level":  score.risk_level,
            # Factors are populated by the caller if signal types are
            # tracked separately; the publisher keeps the contract simple.
            "factors":     [],
            "components": {
                "identity":   int(score.identity_score),
                "behavior":   int(score.behavior_score),
                "network":    int(score.network_score),
                "compliance": int(score.compliance_score),
            },
            "source":      self._source,
            "observed_at": (score.calculated_at or datetime.now(timezone.utc)).isoformat(),
        }
