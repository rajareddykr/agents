# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""
Stateful session context for policy evaluation (R13).

SessionContext tracks the sequence of events that have occurred within an
agent's current session and projects them into a flat ``session_*`` key
namespace that the standard PolicyEvaluator can query without modification.

Usage
-----
::

    from agent_os.policies.session_context import SessionContext
    from agent_os.policies.evaluator import PolicyEvaluator
    from agent_os.policies.schema import PolicyDocument

    ctx = SessionContext("session-xyz", window_seconds=3600)
    ctx.record("tool_call",  tool_name="execute_code", outcome="allow")
    ctx.record("tool_call",  tool_name="execute_code", outcome="allow")
    ctx.record("policy_hit", outcome="deny", rule="block_secret_access")

    # Merge session facts into the per-request context before evaluation
    request_ctx = {"tool_name": "execute_code", "token_count": 1200}
    full_ctx = {**request_ctx, **ctx.as_dict()}

    evaluator = PolicyEvaluator()
    evaluator.load_policies("./policies")
    decision = evaluator.evaluate(full_ctx)

Policy YAML can then reference session facts with standard operators::

    rules:
      - name: block_repeated_code_exec
        condition:
          field: session_tool_execute_code_count
          operator: gte
          value: 5
        action: block
        message: "Agent executed code ≥5 times this session window."

      - name: flag_repeated_denials
        condition:
          field: session_deny_count
          operator: gte
          value: 3
        action: audit
        message: "Three or more denials in the session window — escalate."
"""

from __future__ import annotations

import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SessionEvent:
    """A single recorded event within a session."""

    event_type: str
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


class SessionContext:
    """
    Accumulates events for one agent session and exposes derived counters
    as a flat ``session_*`` dict for use in policy conditions.

    Parameters
    ----------
    session_id : str
        Opaque identifier for the session.
    window_seconds : int
        Rolling window (in seconds) over which counts are aggregated.
        Defaults to 3 600 s (1 hour).
    """

    def __init__(self, session_id: str, window_seconds: int = 3_600) -> None:
        self.session_id = session_id
        self.window_seconds = window_seconds
        self._events: list[SessionEvent] = []

    # ------------------------------------------------------------------
    # Event recording
    # ------------------------------------------------------------------

    def record(self, event_type: str, **metadata: Any) -> None:
        """Append an event to the session log.

        Parameters
        ----------
        event_type : str
            Semantic label, e.g. ``"tool_call"``, ``"policy_hit"``,
            ``"memory_write"``, ``"external_api"``.
        **metadata
            Arbitrary key-value pairs stored with the event.  Common keys:

            - ``tool_name`` — name of the tool that was called
            - ``outcome``   — ``"allow"`` / ``"deny"`` / ``"audit"`` / ``"block"``
            - ``rule``      — matched policy rule name
            - ``tokens``    — token count for this call
        """
        self._events.append(SessionEvent(event_type=event_type, metadata=metadata))

    # ------------------------------------------------------------------
    # Context projection
    # ------------------------------------------------------------------

    def as_dict(self, now: float | None = None) -> dict[str, Any]:
        """Return a flat ``session_*`` dict suitable for policy evaluation.

        All counters are computed over the rolling ``window_seconds``
        window.  The full (unwindowed) totals are also included under
        ``session_total_*`` keys.

        Keys emitted
        ~~~~~~~~~~~~
        ``session_id``
            The session identifier.
        ``session_event_count``
            Total events in the current window.
        ``session_total_event_count``
            Total events since session start (unwindowed).
        ``session_deny_count``
            Policy deny/block outcomes in the window.
        ``session_block_count``
            Policy block outcomes in the window.
        ``session_audit_count``
            Policy audit outcomes in the window.
        ``session_tool_call_count``
            All tool-call events in the window.
        ``session_tool_{name}_count``
            Per-tool call count in the window (name is lowercased,
            spaces replaced with underscores).
        ``session_unique_tool_count``
            Number of distinct tools called in the window.
        ``session_event_{type}_count``
            Per-event-type count in the window.
        ``session_deny_ratio``
            Fraction of tool calls that resulted in deny/block (0.0–1.0).
        """
        now = now or time.time()
        cutoff = now - self.window_seconds

        windowed = [e for e in self._events if e.timestamp >= cutoff]

        # Outcome counters
        outcomes = [e.metadata.get("outcome", "") for e in windowed]
        deny_count = sum(1 for o in outcomes if o in ("deny", "block"))
        block_count = sum(1 for o in outcomes if o == "block")
        audit_count = sum(1 for o in outcomes if o == "audit")

        # Tool call counters
        tool_calls = [
            e.metadata["tool_name"]
            for e in windowed
            if e.event_type == "tool_call" and "tool_name" in e.metadata
        ]
        tool_counter = Counter(tool_calls)
        tool_call_count = len(tool_calls)

        # Event type counters
        event_type_counter = Counter(e.event_type for e in windowed)

        ctx: dict[str, Any] = {
            "session_id": self.session_id,
            "session_event_count": len(windowed),
            "session_total_event_count": len(self._events),
            "session_deny_count": deny_count,
            "session_block_count": block_count,
            "session_audit_count": audit_count,
            "session_tool_call_count": tool_call_count,
            "session_unique_tool_count": len(tool_counter),
            "session_deny_ratio": deny_count / tool_call_count if tool_call_count > 0 else 0.0,
        }

        # Per-tool counts  e.g.  session_tool_execute_code_count
        for tool_name, count in tool_counter.items():
            safe = tool_name.lower().replace(" ", "_").replace("-", "_")
            ctx[f"session_tool_{safe}_count"] = count

        # Per-event-type counts  e.g.  session_event_memory_write_count
        for event_type, count in event_type_counter.items():
            safe = event_type.lower().replace(" ", "_").replace("-", "_")
            ctx[f"session_event_{safe}_count"] = count

        return ctx

    # ------------------------------------------------------------------
    # Inspection helpers
    # ------------------------------------------------------------------

    @property
    def event_count(self) -> int:
        """Total number of events recorded (unwindowed)."""
        return len(self._events)

    def events_in_window(self, now: float | None = None) -> list[SessionEvent]:
        """Return events within the current rolling window."""
        now = now or time.time()
        cutoff = now - self.window_seconds
        return [e for e in self._events if e.timestamp >= cutoff]

    def clear(self) -> None:
        """Discard all recorded events (e.g. at session end)."""
        self._events.clear()

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"SessionContext(session_id={self.session_id!r}, "
            f"events={self.event_count}, window={self.window_seconds}s)"
        )
