# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Remote policy provider — fetches and caches policies from agentmesh policy-server."""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable

import httpx

logger = logging.getLogger(__name__)


class RemotePolicyProvider:
    """Fetches the policy bundle from the agentmesh policy-server and caches it
    locally with a configurable TTL.

    Thread-safe: uses asyncio.Lock for cache updates.
    Fail-open: if the server is unreachable the last known cache is used.
    If no cache exists yet (cold-start failure) an empty list is returned
    and a WARNING is logged.

    Usage::

        provider = RemotePolicyProvider("http://agentmesh:8444", ttl=60)
        await provider.start()
        policies = await provider.get_policies()

    Bundle delivery: by default the bundle is cached for callers that poll
    via :meth:`get_policies`. Callers wanting push-style updates pass an
    ``on_refresh`` callback to the constructor (or via
    :meth:`set_on_refresh`); it fires with the parsed bundle on every
    successful fetch. ``StatelessKernel.set_policy_server`` uses this to
    merge fetched policies into its ``self.policies`` dict so the
    bundle is actually applied at enforcement time (closing the gap
    where remote-policy was fetched but never enforced).
    """

    def __init__(
        self,
        policy_server_url: str,
        ttl: int = 60,
        token: str = "",
        on_refresh: Callable[[list[dict[str, Any]]], None] | None = None,
    ) -> None:
        self._url = policy_server_url.rstrip("/")
        self._ttl = ttl
        self._token = token
        self._cache: list[dict[str, Any]] = []
        self._fetched_at: float = 0.0
        self._lock = asyncio.Lock()
        self._task: asyncio.Task[None] | None = None
        self._on_refresh: Callable[[list[dict[str, Any]]], None] | None = on_refresh

    def set_on_refresh(self, callback: Callable[[list[dict[str, Any]]], None]) -> None:
        """Register / replace the refresh callback. Fires after every successful fetch."""
        self._on_refresh = callback

    async def start(self) -> None:
        """Fetch once immediately (logs warning on failure), then start refresh loop."""
        await self._fetch()
        self._task = asyncio.create_task(self._refresh_loop())

    async def stop(self) -> None:
        """Cancel the background refresh loop."""
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def get_policies(self) -> list[dict[str, Any]]:
        """Return cached policies. Re-fetches inline if TTL has expired."""
        if time.monotonic() - self._fetched_at > self._ttl:
            await self._fetch()
        return self._cache

    async def _fetch(self) -> None:
        headers: dict[str, str] = {}
        if self._token:
            # CP API tokens (prefix ``agt_``) authenticate via the
            # ``X-AGT-Token`` header — the auth middleware tries this
            # before falling back to ``Authorization: Bearer <JWT>``.
            # Sending an ``agt_*`` token as a Bearer credential makes
            # the JWT decoder reject it and yields a 401. JWTs sit in
            # the Authorization header as before.
            if self._token.startswith("agt_"):
                headers["X-AGT-Token"] = self._token
            else:
                headers["Authorization"] = f"Bearer {self._token}"
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{self._url}/api/v1/policies/bundle",
                    headers=headers,
                )
                resp.raise_for_status()
                data = resp.json()
                async with self._lock:
                    self._cache = data.get("policies", [])
                    self._fetched_at = time.monotonic()
                logger.debug(
                    "Fetched %d policies from %s", len(self._cache), self._url
                )
                # Fire the refresh callback OUTSIDE the lock so the
                # callback can re-enter the provider without deadlocking
                # (e.g. read self._cache via get_policies).
                if self._on_refresh is not None:
                    try:
                        self._on_refresh(list(self._cache))
                    except Exception:
                        logger.warning(
                            "Policy bundle on_refresh callback raised — ignoring",
                            exc_info=True,
                        )
        except Exception as exc:
            if self._cache:
                logger.warning(
                    "Remote policy fetch failed (%s) — using %d cached policies",
                    exc,
                    len(self._cache),
                )
            else:
                logger.warning(
                    "Remote policy fetch failed (%s) — no cache, using empty policy set",
                    exc,
                )

    async def _refresh_loop(self) -> None:
        while True:
            await asyncio.sleep(self._ttl)
            await self._fetch()
