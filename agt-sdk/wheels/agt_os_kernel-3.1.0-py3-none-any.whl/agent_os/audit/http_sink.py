# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""HTTP audit sink — posts governance decisions to agentmesh audit-collector."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_OUTCOME_MAP: dict[str, str] = {
    "allow": "success",
    "block": "blocked",
    "audit": "warned",
    "deny":  "failure",
}


def _map_outcome(outcome: str) -> str:
    return _OUTCOME_MAP.get(outcome, "success")


class HTTPDecisionSink:
    """Posts governance decisions from the agent-os SDK to the agentmesh
    audit-collector, which bridges them to the control-plane dashboard.

    Non-blocking: :meth:`record` enqueues the payload and returns
    immediately. The background drain task delivers it with best-effort
    semantics — a full queue silently drops the oldest entry rather than
    blocking the governance hot path.

    Usage::

        sink = HTTPDecisionSink(
            "http://agentmesh:8445",
            agent_id="did:mesh:abc123",
            agent_name="my-langchain-agent",
        )
        await sink.start()
        await sink.record("db_query", "block", reason="data_integrity_policy")
    """

    def __init__(
        self,
        audit_collector_url: str,
        agent_id: str,
        agent_name: str,
        token: str = "",
        max_queue: int = 2000,
        *,
        # IMPL-035 cleanup 3: let callers override the hardcoded path + auth so
        # the agt-sdk can target /api/v1/governance/decisions/ingest with an
        # X-AGT-Token header without owning a parallel DecisionIngest workaround.
        # Defaults preserve the pre-IMPL-035 wire (POST /api/v1/audit/log,
        # Authorization: Bearer <token>).
        auth_header: str = "Authorization",
        auth_scheme: str = "Bearer ",
        path: str = "/api/v1/audit/log",
    ) -> None:
        self._url = f"{audit_collector_url.rstrip('/')}{path}"
        self._agent_id = agent_id
        self._agent_name = agent_name
        self._headers: dict[str, str] = {"Content-Type": "application/json"}
        if token:
            header_value = f"{auth_scheme}{token}" if auth_scheme else token
            self._headers[auth_header] = header_value
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=max_queue)
        self._task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        """Start the background drain loop."""
        self._task = asyncio.create_task(self._drain())

    async def stop(self) -> None:
        """Cancel the drain loop cleanly."""
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def record(
        self,
        action: str,
        outcome: str,
        reason: str = "",
        latency_ms: float = 0.0,
        matched_rule: str = "",
        context: dict[str, Any] | None = None,
    ) -> None:
        """Enqueue a decision event. Never blocks the caller."""
        payload: dict[str, Any] = {
            "event_type": "policy_decision",
            "agent_did":  self._agent_id,
            "action":     action,
            "outcome":    _map_outcome(outcome),
            "data": {
                "agent_name":   self._agent_name,
                "reason":       reason,
                "matched_rule": matched_rule,
                "latency_ms":   latency_ms,
                "adapter":      "agent_os_sdk",
                **(context or {}),
            },
        }
        try:
            self._queue.put_nowait(payload)
        except asyncio.QueueFull:
            pass  # best-effort — never block the governance hot path

    async def _drain(self) -> None:
        async with httpx.AsyncClient(timeout=3.0) as client:
            while True:
                payload = await self._queue.get()
                try:
                    await client.post(self._url, json=payload, headers=self._headers)
                except Exception as exc:
                    logger.debug("Audit sink POST failed: %s", exc)
